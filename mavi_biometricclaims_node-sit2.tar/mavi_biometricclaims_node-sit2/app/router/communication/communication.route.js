const router = require("express").Router();
const { communicationCtrl } = require("../../controllers/communication/communication.controller");

router.post("/trigger", communicationCtrl.trigger);
module.exports = router;