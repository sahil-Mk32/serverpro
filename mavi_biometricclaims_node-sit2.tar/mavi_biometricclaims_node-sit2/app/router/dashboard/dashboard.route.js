const router = require("express").Router();
const dashboardCtrl = require("../../controllers/dashboard/dashboard.controller");
const middleware = require("../../middleware/verifyToken");
const middlewareapilog = require("../../middleware/ApilogCration");

router.post("/dashboardStatus",middlewareapilog.cratelogtable,middleware.verifyToken, dashboardCtrl.dashboard);
router.post("/pendingClaim",middlewareapilog.cratelogtable,middleware.verifyToken, dashboardCtrl.pendingClaimBucket);
router.post("/ageBucket",middlewareapilog.cratelogtable,middleware.verifyToken, dashboardCtrl.dashboardAgeBucket);
module.exports = router;
