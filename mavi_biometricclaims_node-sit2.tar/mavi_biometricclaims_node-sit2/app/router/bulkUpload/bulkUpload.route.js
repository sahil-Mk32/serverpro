const router = require("express").Router();
const { BulkUpload } = require("../../controllers/bulkUpload/bulkUpload.controller");
const middleware = require("../../middleware/verifyToken");
const middlewareapilog= require("../../middleware/ApilogCration");

router.post("/paymentbulkupload", middlewareapilog.cratelogtable, middleware.verifyToken, BulkUpload.paymentBulkUpload);
router.post("/paymentbulkupdate", BulkUpload.paymentBulkUpdateProcess);
router.post("/paymentbulkuploadformat", middlewareapilog.cratelogtable, middleware.verifyToken, BulkUpload.paymentBulkUploadFormat);
router.post("/paymentbulkuploadlist", middlewareapilog.cratelogtable, middleware.verifyToken, BulkUpload.paymentBulkUploadList);
router.post("/paymentbulkuploadReport", middlewareapilog.cratelogtable, middleware.verifyToken, BulkUpload.paymentBulkUploadReport);

module.exports = router;

