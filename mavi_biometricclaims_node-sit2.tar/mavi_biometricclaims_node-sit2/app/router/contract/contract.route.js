const router = require("express").Router();
const contractCtrl = require("../../controllers/contract/contract.controller");

router.post("/list", contractCtrl.list);
router.post("/detail", contractCtrl.detail);
module.exports = router;
