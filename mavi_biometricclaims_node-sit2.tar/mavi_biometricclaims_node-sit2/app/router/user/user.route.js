const router = require("express").Router();
const userFormCtrl = require("../../controllers/users/userformrender.controller");
const usertCtrl = require("../../controllers/users/user.controller");
const {verifyToken} = require("../../middleware/verifyToken")
const middleware= require("../../middleware/ApilogCration");

router.post("/login", usertCtrl.logIn);
router.post("/verifyOTP", usertCtrl.verifyOTP);
router.post("/forgotpassword", usertCtrl.forgotPassword);
router.post("/forgotpassword_validate", usertCtrl.forgotPasswordValidation);
router.post("/changepassword", usertCtrl.changePassword);
router.post("/logout",middleware.cratelogtable,[verifyToken], usertCtrl.logOut);
router.post("/profile",middleware.cratelogtable , [verifyToken],userFormCtrl.getProfile);
router.post("/createformrender",middleware.cratelogtable,[verifyToken],userFormCtrl.getUserCreateFormRender);
router.post("/create",middleware.cratelogtable,[verifyToken],usertCtrl.userCreate);
router.post("/detail",middleware.cratelogtable,[verifyToken],usertCtrl.getUserDetails);
router.post("/list",middleware.cratelogtable,[verifyToken],usertCtrl.getUserList);
router.post("/usercreationcallback",middleware.cratelogtable,[verifyToken],userFormCtrl.userCreationCallback);
router.post("/resendotp",middleware.cratelogtable, usertCtrl.resendUserOtp);
router.post("/test",usertCtrl.checkFun);
module.exports = router;
