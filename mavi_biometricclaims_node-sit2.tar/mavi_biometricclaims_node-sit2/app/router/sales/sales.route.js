const router = require("express").Router();
const salesCtrl = require("../../controllers/sales/salesMaster.controller");

router.post("/salesbusiness", salesCtrl.salesBusiness);
router.post("/salesclient", salesCtrl.salesClient);
router.post("/salesclientprogram", salesCtrl.salesClientProgram);
router.post("/salesoperationalcountry", salesCtrl.salesOperationalCountry);
router.post("/salesplan", salesCtrl.salesPlan);
router.post("/salesprogram", salesCtrl.salesProgram);
router.post("/salesprogramplan", salesCtrl.salesProgramPlan);

module.exports = router;