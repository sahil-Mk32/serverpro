const { Sequelize, DataTypes } = require("sequelize");
const env = process.env.ENV.toUpperCase();

const sequelize = new Sequelize(
  process.env["DB_DATABASE_" + env],
  process.env["DB_USERNAME_" + env],
  process.env["DB_PASSWORD_" + env],
  {
    port: process.env["DB_PORT_" + env],
    host: process.env["DB_HOST_" + env],
    dialect: "mysql",
    logging: console.log,
    timezone: '+05:30', // for writing to database
  },
);

try {
  sequelize.authenticate();
  console.log("connection has been established successfully");
} catch (error) {
  console.error("enable to connect to database", error);
}
const db = {};
db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.user = require("./user/user")(sequelize, DataTypes);
db.oneTimeToken = require("./user/userOnetimeToken")(sequelize, DataTypes);
db.otpLog = require("./otpLogs/otpLog")(sequelize, DataTypes);
db.emailTemplate = require("./email/emailTemplate")(sequelize, DataTypes);
db.smsTemplate = require("./sms/smsTemplate")(sequelize, DataTypes);
db.salesBusiness = require("./sales/salesBusiness")(sequelize, DataTypes);
db.salesClient = require("./sales/salesClient")(sequelize, DataTypes);
db.salesClientprogram = require("./sales/salesClientprogram")(sequelize, DataTypes);
db.salesOperationalCountry = require('./sales/salesOperationalcountry')(sequelize, DataTypes);
db.salesPlan = require('./sales/salesPlan')(sequelize, DataTypes);
db.salesProgram = require('./sales/salesProgram')(sequelize, DataTypes);
db.salesProgramplan = require('./sales/salesProgramplan')(sequelize, DataTypes);
db.passwordPolicy = require('./user/passwordPolicy')(sequelize, DataTypes);
db.apiLogs = require('./apis/apiLogs')(sequelize, DataTypes);
db.moduleApiRegister = require('./module/moduleApiRegistration')(sequelize, DataTypes);
db.module = require('./module/module')(sequelize, DataTypes);
db.moduleEntity = require('./module/clm_module_entity_num')(sequelize, DataTypes);
db.bitlyLink = require('./module/clm_bitly_link')(sequelize, DataTypes);
db.userClientProgram = require('./user/userClientProgram')(sequelize, DataTypes);
db.menuNavigation = require('./menu/menuNavigation')(sequelize, DataTypes);
db.claimsModel = require('./claim/claim')(sequelize, DataTypes);
db.claimDisabilitiesModel = require('./claim/claimDisabilities')(sequelize, DataTypes);
db.claimStatus = require('./claim/claimStatus')(sequelize, DataTypes);
db.claimStatusHistory = require('./claim/claimStatusHistory')(sequelize, DataTypes);
db.claimSubStatus = require('./claim/claimSubStatus')(sequelize, DataTypes);
db.userPasswordHistory = require('./user/userPasswordHistory')(sequelize, DataTypes);
db.userWrongPwdAttempts = require('./user/userWrongPwdAttempts')(sequelize, DataTypes);
db.claimSection = require('./section/section')(sequelize, DataTypes);
db.field = require('./field/field')(sequelize, DataTypes);
db.uiType = require('./uitype/uitype')(sequelize, DataTypes);
db.loginHistory = require('./user/loginHistory')(sequelize, DataTypes);
db.document = require('./document/document')(sequelize, DataTypes);
db.comments = require('./claim/comments')(sequelize, DataTypes);
db.reviewSchedule = require("./reviewSchedule/reviewSchedule")(sequelize, DataTypes);
db.picklistReviewMode = require("./picklistReviewMode/picklistReviewMode")(sequelize, DataTypes);
db.paymentSchedule = require('./paymentSchedule/paymentSchedule')(sequelize, DataTypes);
db.modtrackerBasic = require("./modeTracker/mode_tracker_basic")(sequelize, DataTypes);
db.modtrackerDetail = require("./modeTracker/modtrackerDetail")(sequelize, DataTypes);
db.bulkCronJob = require("./bulkCronJob/bulkCronJob")(sequelize, DataTypes);
db.bulkTempDataImport = require("./bulkTempDataImport/bulkTempDataImport")(sequelize, DataTypes);
db.roleWiseStatus = require("./roleWiseStatus/roleWiseStatus")(sequelize, DataTypes);
db.role = require("./role/role")(sequelize, DataTypes);
db.clmDashboardBox = require("./claim/claimDashboardBox")(sequelize, DataTypes);
db.communication = require("./communication/communication")(sequelize, DataTypes);
db.commQueue = require("./communication/commQueue")(sequelize, DataTypes);
// db.sequelize.sync({ force: false });

/* Table associations for joining */
// db.uiType.hasMany(db.field);
db.field.belongsTo(db.uiType, {
  foreignKey: "uitype"
});
db.reviewSchedule.belongsTo(db.claimsModel, {
  foreignKey: "claim_number",
  targetKey: "claim_number",
});
db.reviewSchedule.belongsTo(db.picklistReviewMode, {
  foreignKey: "review_mode_id",
  targetKey: "id",
});
db.bulkCronJob.belongsTo(db.module, {
  foreignKey: "module_id",
  targetKey: "id",
});
db.bulkTempDataImport.belongsTo(db.bulkCronJob, {
  foreignKey: "job_id",
  targetKey: "id",
});
/* db.roleWiseStatus.belongsTo(db.role, {
  foreignKey: "role_id",
  targetKey: "id",
}); */
db.user.hasOne(db.role, {
  foreignKey: "default_user_id_str",
  targetKey: "id_str",
});
db.role.belongsTo(db.user, {
  foreignKey: "default_user_id_str",
  targetKey: "id_str",
})


module.exports = db;
