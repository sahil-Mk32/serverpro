module.exports = (sequelize, DataTypes) => {
  const field = sequelize.define(
    "clm_field",
    {
      field_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      module_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      type: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      icon: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      uitype: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      fieldname: {
        type: DataTypes.STRING(70),
        allowNull: true,
      },
      fieldlabel: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      mandatory: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      placeholder: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      minimumlength: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      maximumlength: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      readonly: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      disabled: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        default: 0,
      },
      hidden: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        default: 0,
      },
      pattern: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      validations: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      styles: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      callbacks: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      options: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      generatedtype: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0,
      },
      presence: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 1,
      },
      sequence: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      section: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      columnname: {
        type: DataTypes.STRING(70),
        allowNull: false,
      },
      tablename: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      displaytype: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      typeofdata: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      info_type: {
        type: DataTypes.STRING(20),
        allowNull: true,
      },
      helpinfo: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      is_encrypted: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        defaultValue: 0,
      },
      is_mask: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0,
      },
      mappedFields: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      customerform_view: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return field;
};
