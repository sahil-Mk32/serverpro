module.exports = (sequelize, DataTypes) => {
  const document = sequelize.define(
    "clm_document",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      ds_refid: {
        type: DataTypes.STRING(100),
        allowNull: false,
        unique: true,
      },
      pid: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0,
      },
      module_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      claim_number: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      type: {
        type: DataTypes.ENUM(
          "claimants_statement",
          "clinical_abstract_form",
          "doctors_statement_or_attending_physician_statement",
          "medical_reports",
          "police_report",
          "deputy_appointment",
          "salary_slips",
          "other_documents"
        ),
        allowNull: false,
      },
      filename: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      original_filename: {
        type: DataTypes.STRING(150),
        allowNull: false,
      },
      filepath: {
        type: DataTypes.STRING(150),
        allowNull: true,
      },
      filesize: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      extension: {
        type: DataTypes.STRING(20),
        allowNull: true,
      },
      assigned_to: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      status: {
        type: DataTypes.ENUM("active", "inactive"),
        allowNull: false,
        default: "active",
      },
      springcm_status: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        default: 0,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return document;
};
