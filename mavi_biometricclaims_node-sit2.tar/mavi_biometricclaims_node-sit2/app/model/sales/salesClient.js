module.exports = (sequelize, DataTypes) => {
  const salesClient = sequelize.define(
    "clm_sales_client",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      client_code: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      operationcountryid: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      businessid: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      client_display_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      client_agreement_status: {
        type: DataTypes.STRING,
      },
      source: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return salesClient;
};
