module.exports = (sequelize, DataTypes) => {
  const salesProgramplan = sequelize.define(
    "clm_sales_programplan",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      programplan_code: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      program_code: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      programname: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      plan_code: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      plan_name: {
        type: DataTypes.STRING,
      },
      programplan_status: {
        type: DataTypes.STRING,
      },
      source: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
      source: {
        type: DataTypes.STRING,
      },
      sum_insured_percentage: {
        type: DataTypes.STRING,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return salesProgramplan;
};
