module.exports = (sequelize, DataTypes) => {
  const salesOperationalCountry = sequelize.define(
    "clm_sales_operationalcountry",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      country_id: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      country_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      currency: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      postalcode: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      accounting_date: {
        type: DataTypes.STRING,
      },
      dateformat: {
        type: DataTypes.STRING,
      },
      timezone: {
        type: DataTypes.STRING,
      },
      region: {
        type: DataTypes.STRING,
      },
      mobile_regex: {
        type: DataTypes.STRING,
      },
      pincode_regex: {
        type: DataTypes.STRING,
      },
      status: {
        type: DataTypes.STRING,
      },
      source: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return salesOperationalCountry;
};
