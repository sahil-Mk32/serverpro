module.exports = (sequelize, DataTypes) => {
    const module_entity = sequelize.define(
      "clm_bitly_link",
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          allowNull: false,
          autoIncrement: true,
        },
        ref_module: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        ref_id: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        token: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        bitly_link: {
            type: DataTypes.STRING,
            allowNull: false,
          },
        emailid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        mobileno: {
          type: DataTypes.STRING,
          allowNull: false,
      },
        expiry_datetime: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        source: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        created: {
          type: DataTypes.DATE,
        },
        modified: {
          type: DataTypes.DATE,
        },
        created_by: {
          type: DataTypes.INTEGER,
        },
        modified_by: {
          type: DataTypes.INTEGER,
        },
        deleted: {
          type: DataTypes.TINYINT(1),
          defaultValue: 0,
        },
        status: {
          type: DataTypes.ENUM,
          values: ["send", "expire", "verified", "resend"],
          defaultValue: "send",
        },
        otp_status: {
          type: DataTypes.ENUM,
          values: ["send", "expire", "verified", "resend"],
          defaultValue: "send",
        },
        verify_token: {
          type: DataTypes.STRING,
        },
      },
      {
        freezeTableName: true,
        timestamps: false,
      }
    );
    return module_entity;
  };
  