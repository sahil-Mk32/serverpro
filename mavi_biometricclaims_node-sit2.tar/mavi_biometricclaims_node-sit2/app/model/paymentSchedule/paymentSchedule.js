module.exports = (sequelize, DataTypes) => {
  const paymentSchedule = sequelize.define(
    "clm_payment_schedule",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      payment_number: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      payment_serial: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      claim_number: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      payment_serial: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      amount: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      payment_due_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      utr_no: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      bank_name: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      account_number: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      payment_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      tat: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      payment_status: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      remarks: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      account_holder_name: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      bank_account_number: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      bank_branch_code: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      source: {
        type: DataTypes.ENUM,
        values: ["API","WEB"],
        defaultValue: "WEB",
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return paymentSchedule;
};
