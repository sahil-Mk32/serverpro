module.exports = (sequelize, DataTypes) => {
  const user = sequelize.define(
    "clm_user",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      id_str: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
      },
      role_id: {
        type: DataTypes.INTEGER,
      },
      repairer_id: {
        type: DataTypes.INTEGER,
      },
      username: {
        type: DataTypes.STRING,
        unique: true,
      },
      first_name: {
        type: DataTypes.STRING,
      },
      middle_name: {
        type: DataTypes.STRING,
      },
      last_name: {
        type: DataTypes.STRING,
      },
      email: {
        type: DataTypes.STRING,
      },
      mobile: {
        type: DataTypes.STRING,
      },
      password: {
        type: DataTypes.STRING,
      },
      reports_to: {
        type: DataTypes.INTEGER,
      },
      status: {
        type: DataTypes.ENUM,
        values: ["active", "inactive"],
        defaultValue: "active",
      },
      is_admin: {
        type: DataTypes.ENUM,
        values: ["on", "off"],
        defaultValue: "off",
      },
      web_access: {
        type: DataTypes.ENUM,
        values: ["yes", "no"],
        defaultValue: "no",
      },
      mobile_access: {
        type: DataTypes.ENUM,
        values: ["yes", "no"],
        defaultValue: "no",
      },
      last_password_change: {
        type: DataTypes.DATE,
      },
      modified: {
        type: DataTypes.DATE,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: "0",
      },
      time_zone: {
        type: DataTypes.STRING,
      },
      time_zone_name: {
        type: DataTypes.STRING,
      },
      currency: {
        type: DataTypes.STRING,
      },
      date_format: {
        type: DataTypes.STRING,
      },
      profile_image: {
        type: DataTypes.STRING,
      },
      salutation: {
        type: DataTypes.STRING,
      },
      dob: {
        type: DataTypes.DATE,
      },
      gender: {
        type: DataTypes.ENUM,
        values: ["male", "female"],
        defaultValue: "male",
      },
      latitude: {
        type: DataTypes.STRING,
      },
      longitude: {
        type: DataTypes.STRING,
      },
      rating: {
        type: DataTypes.TINYINT(1),
        defaultValue: "0",
      },
      created: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW,
      },
      login_token: {
        type: DataTypes.STRING,
      },
      ip: {
        type: DataTypes.STRING,
      },
      user_agent: {
        type: DataTypes.STRING,
      },
      source: {
        type: DataTypes.STRING,
      },
      timeslot_flag: {
        type: DataTypes.ENUM,
        values: ["0", "1"],
        defaultValue: "0",
      },
      forget_password_token: {
        type: DataTypes.STRING,
      },
      last_attempt: {
        type: DataTypes.DATE
      },
      wrong_attempt: {
        type: DataTypes.INTEGER,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return user;
};
