module.exports = (sequelize, DataTypes) => {
  const passwordPolicy = sequelize.define(
    "clm_password_policy_settings_options",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      option_label: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      option_column: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      option_type: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      option_value: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      created_date: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      status: {
        type: DataTypes.ENUM,
        values: ["0", "1"],
        default: "1",
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return passwordPolicy;
};
