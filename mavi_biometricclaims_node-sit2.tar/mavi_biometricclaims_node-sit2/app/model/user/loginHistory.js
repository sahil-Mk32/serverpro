module.exports = (sequelize, DataTypes) => {
  const loginHistory = sequelize.define(
    "clm_login_history",
    {
      login_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      username: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      user_ip: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      logout_time: {
        type: "TIMESTAMP",
        defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
        onUpdate: sequelize.literal("CURRENT_TIMESTAMP"),
        allowNull: false,
      },
      login_time: {
        type: "TIMESTAMP",
        defaultValue: '0000-00-00 00:00:00',
        allowNull: false,
      },
      status: {
        type: DataTypes.STRING,
      },
      source: {
        type: DataTypes.STRING,
      },
      user_agent: {
        type: DataTypes.STRING,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return loginHistory;
};
