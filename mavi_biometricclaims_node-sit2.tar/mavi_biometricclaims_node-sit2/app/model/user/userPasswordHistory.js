module.exports = (sequelize, DataTypes) => {
  const userPasswordHistory = sequelize.define(
    "clm_user_password_history",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      uid_str: {
        type: DataTypes.STRING,
      },
      password: {
        type: DataTypes.STRING,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return userPasswordHistory;
};
