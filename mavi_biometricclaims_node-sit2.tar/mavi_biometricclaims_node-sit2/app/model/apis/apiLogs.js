module.exports = (sequelize, DataTypes) => {
  const apiLogs = sequelize.define(
    "clm_api_log",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      api_name: {
        type: DataTypes.STRING,
      },
      api_url: {
        type: DataTypes.STRING,
      },
      method: {
        type: DataTypes.STRING,
      },
      user_id: {
        type: DataTypes.INTEGER,
      },
      api_data_key: {
        type: DataTypes.STRING,
      },
      api_type: {
        type: DataTypes.ENUM,
        values: ["incoming", "outgoing"],
        defaultValue: "incoming",
      },
      expose: {
        type: DataTypes.ENUM,
        values: [
          "aiz",
          "node",
          "python",
          "mobile",
          "web",
          "php",
          "ps",
          "ds",
          "cpp",
        ],
        defaultValue: "node",
      },
      consume: {
        type: DataTypes.ENUM,
        values: [
          "aiz",
          "node",
          "python",
          "mobile",
          "web",
          "php",
          "ps",
          "ds",
          "cpp",
        ],
        defaultValue: "aiz",
      },
      req_body: {
        type: DataTypes.TEXT,
      },
      req_header: {
        type: DataTypes.TEXT,
      },
      response: {
        type: DataTypes.TEXT,
      },
      created_date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      status: {
        type: DataTypes.ENUM,
        values: ["Requested", "Failed", "Success"],
        defaultValue: "Requested",
      },
      error_type: {
        type: DataTypes.STRING,
      },
      ip: {
        type: DataTypes.STRING,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return apiLogs;
};
