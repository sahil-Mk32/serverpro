module.exports = (sequelize, DataTypes) => {
  const otpLog = sequelize.define(
    "clm_otp_log",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      record_id: {
        type: DataTypes.INTEGER,
      },
      templateid: {
        type: DataTypes.INTEGER,
      },
      record_type: {
        type: DataTypes.ENUM,
        values: ["user", "case"],
      },
      mobile: {
        type: DataTypes.STRING,
      },
      emailid: {
        type: DataTypes.STRING,
      },
      otp: {
        type: DataTypes.STRING,
      },
      expirytime: {
        type: DataTypes.DATE,
      },
      otp_status: {
        type: DataTypes.ENUM,
        values: ["send", "expire", "verified", "resend"],
        defaultValue: "send",
      },
      created: {
        type: DataTypes.DATE,
      },
      modified: {
        type: DataTypes.DATE,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return otpLog;
};
