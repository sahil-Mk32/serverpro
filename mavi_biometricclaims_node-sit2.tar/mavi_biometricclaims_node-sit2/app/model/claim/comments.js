module.exports = (sequelize, DataTypes) => {
  const comments = sequelize.define(
    "clm_comments",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      module_id: {
        type: DataTypes.INTEGER,
      },
      ref_id: {
        type: DataTypes.INTEGER,
      },
      parrentid: {
        type: DataTypes.INTEGER,
      },
      comments: {
        type: DataTypes.TEXT,
      },
      created: {
        type: DataTypes.DATE,
      },
      modified: {
        type: DataTypes.DATE,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: "0",
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return comments;
};
