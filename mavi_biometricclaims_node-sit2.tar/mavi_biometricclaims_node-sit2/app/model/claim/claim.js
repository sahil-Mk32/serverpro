
module.exports = (sequelize, DataTypes) => {
  const claims = sequelize.define(
    "clm_claim",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      id_str: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      client_program_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      claim_number: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: false,
      },
      policy_no: {
        type: DataTypes.STRING,
        allowNull: false,
      },        
      policyholder_full_name: {
        type: DataTypes.STRING,
      },
      plan_name: {
          type: DataTypes.STRING,
        },
      policy_start_date: {
          type: DataTypes.DATE,
      },
      policy_end_date: {
          type: DataTypes.DATE
        },
      benefit_period: {
          type: DataTypes.STRING,
      },
      sum_insured: {
          type: DataTypes.DECIMAL(15,2),
        },
      reserve_amount: {
        type: DataTypes.DECIMAL(15,2),
      },
      deferment_payment_period: {
      type: DataTypes.STRING,
      },
      qualifying_period_start_date: {
      type: DataTypes.DATE,
      },
      qualifying_period_end_date: {
          type: DataTypes.DATE,
      },
      policy_issue_date: {
        type: DataTypes.DATE,
      },
      insured_full_name: {
          type: DataTypes.STRING
      },
      nric_fin_no: {
          type: DataTypes.STRING,
      },
      email_id: {
          type: DataTypes.STRING,
      },
      mobile_no: {
      type: DataTypes.STRING,
      },
      address_1: {
      type: DataTypes.STRING,
      },
      address_2: {
      type: DataTypes.STRING,
      },
      pin_zip_code: {
          type: DataTypes.STRING,
      },
      city: {
          type: DataTypes.STRING,
      },
      state: {
          type: DataTypes.STRING
      },
      country: {
          type: DataTypes.STRING,
      },
      account_holder_name: {
          type: DataTypes.STRING,
      },
      bank_name: {
      type: DataTypes.STRING,
      },
      branch_code: {
      type: DataTypes.STRING,
      },
      account_no: {
      type: DataTypes.STRING,
      },
      same_account_details: {
          type: DataTypes.TINYINT(1),
      }, 
      account_holder: {
          type: DataTypes.STRING,
      },
      relation_with_insured: {
        type: DataTypes.STRING,
      },
      specify_relationship: {
        type: DataTypes.STRING,
      },
      name_of_next_of_kin: {
          type: DataTypes.STRING,
      },
      status: {
          type: DataTypes.STRING,
      },
      substatus: {
          type: DataTypes.STRING,
      },
      source: {
          type: DataTypes.ENUM,
          values: ["API","WEB"],
          defaultValue: "WEB",
      },
      updt_mobile_no: {
        type: DataTypes.STRING,
      },
      updt_bank_name: {
        type: DataTypes.STRING,
      },
      updt_account_no: {
        type: DataTypes.STRING,
      },
      updt_branch_code: {
        type: DataTypes.STRING,
      },
      updt_email_id: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
      },        
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      assigned_to: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.ENUM,
        values: ["0", "1"],
        defaultValue: "0",
      },
      disability_type: {
        type: DataTypes.TEXT
      },
      payment_start_waiting_period_in_days: {
        type: DataTypes.INTEGER
      },
      max_number_of_payment_as_per_plan: {
        type: DataTypes.INTEGER
      },
      max_number_of_payment_availability: {
        type: DataTypes.INTEGER
      },
      payment_frequency_in_days: {
        type: DataTypes.INTEGER
      },
      reserved_amount: {
        type: DataTypes.DECIMAL(10,2)
      },
      max_number_of_review_as_per_plan: {
        type: DataTypes.INTEGER
      },
      review_frequency_in_days: {
        type: DataTypes.INTEGER
      },
      payment_installment: {
        type: DataTypes.DECIMAL(10,2)
      },
      number_of_payment: {
        type: DataTypes.INTEGER
      },
      payment_start_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      payment_end_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      remarks: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      payment_due: {
        type: DataTypes.STRING,
      },
      review_due: {
        type: DataTypes.STRING,
      },
      claim_approved_date:{
        type: DataTypes.DATE,
        allowNull: true, 
      },

    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return claims;
};


