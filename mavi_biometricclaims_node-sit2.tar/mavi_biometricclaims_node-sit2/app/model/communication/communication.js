module.exports = (sequelize, DataTypes) => {
  const communication = sequelize.define(
    "clm_communication",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      type: {
        type: DataTypes.ENUM,
        values: ["email", "sms"],
      },
      pid: {
        type: DataTypes.INTEGER,
      },
      subject: {
        type: DataTypes.STRING,
      },
      body: {
        type: DataTypes.TEXT,
      },
      to: {
        type: DataTypes.STRING,
      },
      cc: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      status: {
        type: DataTypes.ENUM,
        values: ["pending", "send", "delivered"],
        defaultValue: "pending",
      },
      response: {
        type: DataTypes.STRING,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return communication;
};
