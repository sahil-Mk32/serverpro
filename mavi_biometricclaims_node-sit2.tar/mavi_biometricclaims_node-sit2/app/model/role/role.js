module.exports = (sequelize, DataTypes) => {
  const role = sequelize.define(
    "clm_role",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      rolename: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      pid: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      status: {
        type: DataTypes.ENUM("active", "inactive"),
        allowNull: false,
        defaultValue: "active",
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      token_expiry: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: 24,
      },
      otp_expiry: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: 5,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return role;
};
