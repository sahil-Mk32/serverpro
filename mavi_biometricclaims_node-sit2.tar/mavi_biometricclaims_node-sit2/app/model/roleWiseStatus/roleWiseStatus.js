module.exports = (sequelize, DataTypes) => {
  const roleWiseStatus = sequelize.define(
    "clm_role_wise_status",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      client_program_id: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
      },
      actionby_role: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      claim_sub_status_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      assignto_role: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      assignto_flag: {
        type: DataTypes.ENUM('NA','P','R'),
        allowNull: false,
        defaultValue: 'NA'
      },
      status_comment: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      status: {
        type: DataTypes.ENUM("active", "inactive"),
        allowNull: false,
        defaultValue: "active",
      },
      document_upload: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        defaultValue: 0,
      }
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return roleWiseStatus;
};
