module.exports = (sequelize, DataTypes) => {
  const bulkCronJob = sequelize.define(
    "clm_bulk_cron_job",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      type: {
        type: DataTypes.ENUM("nr", "ps", "l", "af"),
        allowNull: true,
        default: "ps",
      },
      file_id: {
        type: DataTypes.BIGINT,
        allowNull: true,
      },
      total_records: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0,
      },
      uploaded_records: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0,
      },
      skipped_records: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0,
      },
      error_records: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0,
      },
      cron_start_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      cron_end_date: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      error_csv_name: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      status: {
        type: DataTypes.ENUM("open", "completed", "processing", "aborted",  "error"),
        allowNull: true,
        default: "open",
      },
      assigned_to: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    },
  );
  return bulkCronJob;
};

