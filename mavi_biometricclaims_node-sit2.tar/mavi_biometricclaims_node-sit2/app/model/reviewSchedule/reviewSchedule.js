module.exports = (sequelize, DataTypes) => {
  const reviewSchedule = sequelize.define(
    "clm_review_schedule",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      review_number: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      review_serial: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      review_due_date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      review_type: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      review_done_by: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      actual_review_date: {
        type: DataTypes.DATEONLY,
        allowNull: true,
      },
      tat: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      review_status: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      remarks: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      source: {
        type: DataTypes.ENUM("API", "WEB"),
        allowNull: false,
        default: "WEB",
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return reviewSchedule;
};
