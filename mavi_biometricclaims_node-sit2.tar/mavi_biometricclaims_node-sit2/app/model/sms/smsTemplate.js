module.exports = (sequelize, DataTypes) => {
    const smsTemplate = sequelize.define(
      "clm_sms_template",
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          allowNull: false,
          autoIncrement: true,
        },
        template_id: {
            type: DataTypes.STRING,
        },
        template_name: {
            type: DataTypes.STRING,
        },
        case_substatus_id: {
          type: DataTypes.INTEGER,
        },
        otp: {
            type: DataTypes.TINYINT(1),
        },
        bitly_link_type: {
            type: DataTypes.ENUM,
            values: ["no", "cd", "cf", "cpl", "cdfl", "cdrcl"],
            defaultValue: "no",
        },
        programe_id: {
          type: DataTypes.INTEGER,
        },
        description: {
          type: DataTypes.STRING,
        },
        client_code: {
          type: DataTypes.STRING,
        },
        template: {
          type: DataTypes.TEXT,
        },
        created: {
          type: DataTypes.DATE,
        },
        modified: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        created_by: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        modified_by: {
          type: DataTypes.INTEGER,
        },
        deleted: {
          type: DataTypes.ENUM,
          values: ["0", "1"],
          defaultValue: "0",
        },
      },
      {
        freezeTableName: true,
        timestamps: false,
      }
    );
    return smsTemplate;
  };
  