const claimViewStyle = [
  {
    css: {
      backgroundColor: "#FFFFFF;",
      marginBottom: "15px",
      fontWeight: "500",
      fontSize: "medium",
    },
  },
];

const claimDetailsStyles = {
  css: {
    backgroundColor: "#FFFFFF;",
    marginBottom: "15px",
    fontWeight: "500",
    fontSize: "14px",
  },
};

const claimViewRendering = [
  {
    policy_no: {
      options: [],
    },
    policyholder_full_name: {
      options: [],
    },
    plan_name: {
      maxlength: 15,
    },
    disability: {
      maxlength: 15,
      callbacks: [],
    },
    ICD_code: {
      maxlength: 15,
    },
  },
];

const claimViewRenderingassign_to = [
  {
    id: "8",
    type: "input",
    icon: "",
    inputType: "text",
    name: "assign_to",
    label: "Assign To",
    required: true,
    value: "",
    placeholder: "Enter Assign To",
    minlength: 0,
    maxlength: 15,
    readonly: false,
    disabled: true,
    hidden: false,
    pattern: null,
    validations: [
      {
        name: "required",
        validator: "required",
        message: "Assign To Required",
      },
    ],
    styles: {
      class: ["full-width", "col3", "input-selectbox"],
      appearance: "outline",
    },
    callbacks: [],
  },
];

const claimViewRenderingCreated_by = [
  {
    id: "7",
    type: "input",
    icon: "",
    inputType: "text",
    name: "created_by",
    label: "Created By",
    required: true,
    value: "",
    placeholder: "Enter Created By",
    minlength: 0,
    maxlength: 15,
    readonly: false,
    disabled: true,
    hidden: false,
    pattern: null,
    validations: [
      {
        name: "required",
        validator: "required",
        message: "Created by is Required",
      },
    ],
    styles: {
      class: ["full-width", "col3", "input-selectbox"],
      appearance: "outline",
    },
    callbacks: [],
  },
];

const claimViewRenderingClaim_no = [
  {
    id: "6",
    type: "input",
    icon: "",
    inputType: "text",
    name: "claim_no",
    label: "Claim No.",
    required: true,
    value: "",
    placeholder: "Enter Claim No.",
    minlength: 0,
    maxlength: 15,
    readonly: false,
    disabled: true,
    hidden: false,
    pattern: null,
    validations: [
      {
        name: "required",
        validator: "required",
        message: "Claim No. is Required",
      },
    ],
    styles: {
      class: ["full-width", "col3", "input-selectbox"],
      appearance: "outline",
    },
    callbacks: [],
  },
];

const claimDetailsRendering = [
  {
    bank_account_details: {
      content:
        "Please provide your bank details for us to accelerate your claims payment process by direct transfer to your bank account.",
    },
    "illness_&_injury_details": { content: "" },
  },
];

const claimDetailsRenderingField = [
  {
    plan_name: { maxlength: 15 },
    deferment_payment_period: { maxlength: 15 },
    illness: { disabled: true },
    accident: { required: false, disabled: true },
    disability: { disabled: true },
    icd_code: { disabled: true },
    doctor_confirmed_disability_date: { disabled: true },
    details_the_nature: { hidden: false },
    have_you_suffered_previuos_illnes_or_injury: { disabled: true },
    date_of_first_consultation_of_injury_illness: { disabled: true },
    date_of_noticed_symptoms_condition: { disabled: true },
    job_related_injury: { required: false, disabled: true },
    claim_against_other_party: { required: false, disabled: true },
    same_account_details: { required: false, disabled: true },
    account_holder: { required: true },
    updt_mobile_no: { required: true },
  },
];

module.exports = {
  claimViewStyle,
  claimViewRendering,
  claimViewRenderingassign_to,
  claimViewRenderingCreated_by,
  claimViewRenderingClaim_no,
  claimDetailsStyles,
  claimDetailsRendering,
  claimDetailsRenderingField,
};
