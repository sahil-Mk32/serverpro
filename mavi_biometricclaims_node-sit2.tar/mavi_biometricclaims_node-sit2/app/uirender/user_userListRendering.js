const UserListRenderHeaderData = [{
    "key": "username",
    "searchKey": "username__search",
    "value": "User Name.",
    "type": "input",
    "inputType": "text",
    "sticky": false,
    "isSearchAvailable": true
}, {
    "key": "first_name",
    "searchKey": "first_name__search",
    "value": "First Name",
    "type": "input",
    "inputType": "text",
    "sticky": false,
    "isSearchAvailable": true
},
{
    "key": "last_name",
    "searchKey": "last_name__search",
    "value": "Last Name",
    "type": "input",
    "inputType": "text",
    "sticky": false,
    "isSearchAvailable": true
}, {
    "key": "email",
    "searchKey": "email__search",
    "value": "Email",
    "type": "input",
    "inputType": "text",
    "sticky": false,
    "isSearchAvailable": true
}, {
    "key": "mobile",
    "searchKey": "mobile__search",
    "value": "Mobile",
    "type": "input",
    "inputType": "text",
    "sticky": false,
    "isSearchAvailable": true
}, {
    "key": "role_id",
    "searchKey": "role_id__search",
    "value": "Role Name",
    "type": "input",
    "inputType": "text",
    "sticky": false,
    "isSearchAvailable": true,
    "options":[]
}, {
    "key": "status",
    "searchKey": "status__search",
    "value": "Status",
    "type": "input",
    "inputType": "text",
    "sticky": false,
    "isSearchAvailable": true
}, {
    "key": "action",
    "searchKey": "action__search",
    "value": "Actions",
    "type": "button",
    "inputType": "button",
    "sticky": true,
    "isSearchAvailable": true,
    "options": {
        "edit": {
            "title": "Click here to edit User",
            "action": "users/edit",
            "fieldId": "id_str",
            "fieldData": null,
            "method": "edit_user",
            "type": "edit"
        },
        "view": {
            "title": "Click here to view User",
            "action": "myprofile/view",
            "fieldId": "id_str",
            "fieldData": null,
            "method": "view_user",
            "type": "view"
        },
        "delete": {
            "title": "Click here to delete Contract",
            "action": "",
            "fieldId": "id",
            "fieldData": null,
            "method": "delete_user",
            "type": "delete"
        }
    }
}];

module.exports = {
UserListRenderHeaderData
};