const PaymentTabData = {
    name: "payment_schedule_tab",
	title: "Payment Schedule Tab",
	styles: {
		id: "paymentSchedule",
		class: ["dynmaic-form"]
	},
    tabs: [{
		"type": "tab",
		"title": "Upcoming",
		"name": "upcoming_payment",
		"icon": "",
		"displayType": "table",
		"fields": [],
			"callbacks": [{
				"method": "upcoming_payment",
				"action": "api/paymentSchedule/list",
				"type": "table",
				"fieldData": null
			}]
		},
		{
			"type": "tab",
			"title": "Completed",
			"name": "completed_payment",
			"icon": "",
			"displayType": "table",
			"fields": [],
			"callbacks": [{
				"method": "completed_payment",
				"action": "api/paymentSchedule/list",
				"type": "table",
				"fieldData": null
			}]
		},
		{
			"type": "tab",
			"title": "Summary",
			"name": "summary_payment",
			"icon": "",
			"displayType": "table",
			"fields": [],
			"callbacks": [{
				"method": "summary_payment",
				"action": "api/paymentSchedule/list",
				"type": "table",
				"fieldData": null
			}]
		}
	],
};

module.exports = {
	PaymentTabData
}
