const sectionData = {
  actions: {
    type: "button",
    name: "action",
    inputType: "button",
    displayType: "default",
    styles: {},
    options: [
      {
        type: "button",
        name: "button",
        inputType: "button",
        label: "Save",
        icon: "",
        disabled: false,
        styles: {
          color: "primary",
          css: {
            background: "rgb(4, 171, 233)",
          },
        },
        callbacks: [
          {
            redirectURL: "claims/view",
            method: "review_edit",
            action: "api/reviewSchedule/update",
            type: "submit",
            fieldData: null,
          },
        ],
        action: "submit",
      },
    ],
  },
};

module.exports = { sectionData };
