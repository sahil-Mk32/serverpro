const PaymentListRenderHeaderData = [{
		"key": "payment_number",
		"searchKey":"payment_number__search",
		"value": "Payment Number",
		"type": "input",
		"inputType":"text",
		"sticky":false,
		"isSearchAvailable": false,
		"isSoring": true
	},
	{
		"key": "amount",
		"searchKey":"amount__search",
		"value": "Amount",
		"type": "input",
		"inputType":"text",
		"sticky":false,
		"isSearchAvailable": false,
		"isSoring": true
	},
	{
		"key": "payment_due_date",
		"searchKey":"payment_due_date__search",
		"value": "Due Date",
		"type": "input",
		"inputType":"text",
		"sticky":false,
		"isSearchAvailable": false,
		"isSoring": true
	},
	{
		"key": "utr_no",
		"searchKey":"utr_no__search",
		"value": "UTR No.",
		"type": "input",
		"inputType":"text",
		"sticky":false,
		"isSearchAvailable": false,
		"isSoring": true
	},
	{
		"key": "bank_name",
		"searchKey":"bank_name__search",
		"value": "Bank Name",
		"type": "input",
		"inputType":"text",
		"sticky":false,
		"isSearchAvailable": false,
		"isSoring": true
	},
	{
		"key": "payment_date",
		"searchKey":"payment_date__search",
		"value": "Pay Date",
		"type": "input",
		"inputType":"text",
		"sticky":false,
		"isSearchAvailable": false,
		"isSoring": true
	},
	{
		"key": "tat",
		"searchKey":"tat__search",
		"value": "Tat",
		"type": "input",
		"inputType":"text",
		"sticky":false,
		"isSearchAvailable": false,
		"isSoring": true
	},
	{
		"key": "status",
		"searchKey":"status__search",
		"value": "Status",
		"type": "input",
		"inputType":"text",
		"sticky":false,
		"isSearchAvailable": false,
		"isSoring": true
	},
	{
		"key": "action",
		"searchKey": "action__search",
		"value": "Action",
		"type": "button",
		"inputType": "button",
		"sticky": true,
		"align": "right",
		"isSearchAvailable": true,
		"isSorting": false,
		"options": {
			"edit": {
				"title":"Click here to edit Payment",
				"action": "paymentschedule/edit",
				"fieldId": "payment_number",
				"fieldData": null,
				"method": "edit_claim",
				"type": "edit"
			},
			"view": {
				"title":"Click here to view Payment",
				"action": "paymentschedule/view",
				"fieldId": "payment_number",
				"fieldData": null,
				"method": "view_claim",
				"type": "view"
			}
		}
	}];

module.exports = {
	PaymentListRenderHeaderData
};