
const disabilityValidationRes = [[
  {
    fieldname: "details_the_nature",
    fieldtype: "input",
    defaultvalue: "",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: false,
      },
      {
        action: "disabled",
        value: false,
      },
      {
        action: "required",
        value: true,
      },
    ],
  }],[
  {
    fieldname: "details_the_nature",
    fieldtype: "input",
    defaultvalue: "",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: true,
      },
      {
        action: "disabled",
        value: true,
      },
    ],
  },
]]

const previousIllnessInjuryValidationRes = [
  [{
    fieldname: "specify",
    fieldtype: "textarea",
    defaultvalue: "",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: false,
      },
      {
        action: "disabled",
        value: false,
      },
      {
        action: "required",
        value: true,
      },
    ],
  }],[
  {
    fieldname: "specify",
    fieldtype: "textarea",
    defaultvalue: "",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: true,
      },
      {
        action: "disabled",
        value: true,
      },
    ],
  }]
];

const claimAgainstOtherPartyValidationRes = [
  [
    {
      fieldname: "another_party_or_insurance_company_name",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "description_of_claim",
      fieldtype: "textarea",
      defaultvalue: "",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "claimed_amount",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
  ],
  [
    {
      fieldname: "another_party_or_insurance_company_name",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "description_of_claim",
      fieldtype: "textarea",
      defaultvalue: "",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "claimed_amount",
      fieldtype: "input",
      defaultvalue: "",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: true,
        },
        {
          action: "disabled",
          value: true,
        },
      ],
    },
  ],
  [
    {
      fieldname: "another_party_or_insurance_company_name",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: true,
        },
        {
          action: "disabled",
          value: true,
        },
      ],
    },
    {
      fieldname: "description_of_claim",
      fieldtype: "textarea",
      defaultvalue: "",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: true,
        },
        {
          action: "disabled",
          value: true,
        },
      ],
    },
    {
      fieldname: "claimed_amount",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: true,
        },
        {
          action: "disabled",
          value: true,
        },
      ],
    },
  ],
];

const dateRelatedValidationRes = [
  {
    fieldname: "date_of_first_consultation_of_injury_illness",
    fieldtype: "date",
    defaultvalue: "",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: false,
      },
      {
        action: "disabled",
        value: false,
      },
      {
        action: "min",
        value: -10,
      },
      {
        action: "max",
        value: 0,
      },
      {
        action: "required",
        value: true,
      },
    ],
  },
  {
    fieldname: "date_of_noticed_symptoms_condition",
    fieldtype: "date",
    defaultvalue: "",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: false,
      },
      {
        action: "disabled",
        value: false,
      },
      {
        action: "min",
        value: -30,
      },
      {
        action: "max",
        value: 0,
      },
      {
        action: "required",
        value: true,
      },
    ],
  },
];

const sameAccountDetailsValidationRes = [
  {
    fieldname: "account_holder",
    fieldtype: "select",
    defaultvalue: "",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: true,
      },
      {
        action: "disabled",
        value: true,
      },
    ],
  },
  {
    fieldname: "name_of_next_of_kin",
    fieldtype: "input",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: true,
      },
      {
        action: "disabled",
        value: true,
      },
    ],
  },
  {
    fieldname: "updt_mobile_no",
    fieldtype: "input",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: true,
      },
      {
        action: "disabled",
        value: true,
      },
    ],
  },
  {
    fieldname: "updt_bank_name",
    fieldtype: "input",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: false,
      },
      {
        action: "disabled",
        value: false,
      },
    ],
  },
  {
    fieldname: "updt_account_no",
    fieldtype: "input",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: false,
      },
      {
        action: "disabled",
        value: false,
      },
    ],
  },
  {
    fieldname: "updt_branch_code",
    fieldtype: "input",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: false,
      },
      {
        action: "disabled",
        value: false,
      },
    ],
  },
];

const noSameAccountDetailsValidationRes = [
  [
    {
      fieldname: "updt_bank_name",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "updt_account_no",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "updt_branch_code",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
  ],
  [
    {
      fieldname: "name_of_next_of_kin",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
      ],
    },
    {
      fieldname: "updt_mobile_no",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "updt_email_id",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "updt_bank_name",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "updt_account_no",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
    {
      fieldname: "updt_branch_code",
      fieldtype: "input",
      fieldvalue: "",
      validations: [
        {
          action: "hidden",
          value: false,
        },
        {
          action: "disabled",
          value: false,
        },
        {
          action: "required",
          value: true,
        },
      ],
    },
  ],
];

const AccountDetailsoptions = [
  {
    fieldname: "account_holder",
    fieldtype: "select",
    defaultvalue: "",
    fieldvalue: [
      {
        key: "Insured’s Bank Details",
        value: "Insured’s Bank Details",
        selected: false,
      },
      {
        key: "Next-of-kin/Guardian",
        value: "Next-of-kin/Guardian",
        selected: false,
      },
    ],
    validations: [
      {
        action: "hidden",
        value: false,
      },
      {
        action: "disabled",
        value: false,
      },
      {
        action: "required",
        value: true,
      },
    ],
  },
  {
    fieldname: "updt_bank_name",
    fieldtype: "input",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: true,
      },
      {
        action: "disabled",
        value: true,
      },
    ],
  },
  {
    fieldname: "updt_account_no",
    fieldtype: "input",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: true,
      },
      {
        action: "disabled",
        value: true,
      },
    ],
  },
  {
    fieldname: "updt_branch_code",
    fieldtype: "input",
    fieldvalue: "",
    validations: [
      {
        action: "hidden",
        value: true,
      },
      {
        action: "disabled",
        value: true,
      },
    ],
  }
];

module.exports = {
  disabilityValidationRes,
  previousIllnessInjuryValidationRes,
  claimAgainstOtherPartyValidationRes,
  dateRelatedValidationRes,
  sameAccountDetailsValidationRes,
  noSameAccountDetailsValidationRes,
  AccountDetailsoptions
};
