const responseCode = {
    uploaded_records: "completed",
    skipped_records: "aborted",
    error_records: "error",
};
module.exports = responseCode;
