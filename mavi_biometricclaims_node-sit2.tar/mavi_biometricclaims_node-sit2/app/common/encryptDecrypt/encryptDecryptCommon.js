var CryptoJS = require("crypto-js");
const env = process.env.ENV.toUpperCase();

module.exports.decryptStr = (value) => {
  try {
    const decryptres = value
      ? CryptoJS.AES.decrypt(
          value,
          process.env["ENCRYPT_COLUMN_SECRET_KEY_" + env]
        ).toString(CryptoJS.enc.Utf8)
      : value;
    return decryptres;
  } catch (err) {
    throw err;
  }
};

module.exports.encryptStr = (value) => {
  try {
    const encrypt = value
      ? CryptoJS.AES.encrypt(
          value,
          process.env["ENCRYPT_COLUMN_SECRET_KEY_" + env]
        ).toString()
      : value;
    return encrypt;
  } catch (err) {
    throw err;
  }
};
