const Utils = require("./encryptDecryptCommon");

module.exports.encryptColumn = (column) => {
  return {
    type: column.type,
    allowNull: column.allowNull,
    set(value) {
      const encryptValue = value ? Utils.encryptStr(value) : value;
      this.setDataValue(column.field, encryptValue);
    },
    get(value) {
      const encryptedData = this.getDataValue(value);
      const decypteValue = encryptedData
        ? Utils.decryptStr(encryptedData)
        : encryptedData;
      return decypteValue;
    },
    ...column,
  };
};
