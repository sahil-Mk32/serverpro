const crypto = require("crypto");
const env = process.env.ENV.toUpperCase();

const encryptText = (text,secretKey) => {
    let md5Value, iv, cipher;
    md5Value = crypto.createHash("md5").update(secretKey).digest("hex");
    iv = crypto.createHash("sha256").update(md5Value).digest("hex").substring(0, 16);
    cipher = crypto.createCipheriv("AES-256-CBC", secretKey, iv);
    return cipher.update(text, "utf8", "base64") + cipher.final("base64");
};

const decryptText = (text,secretKey) => {
    let md5Value, iv, decipher;
    md5Value = crypto.createHash("md5").update(secretKey).digest("hex");
    iv = crypto.createHash("sha256").update(md5Value).digest("hex").substring(0, 16);
    decipher = crypto.createDecipheriv("AES-256-CBC", secretKey, iv); 
    return decipher.update(text, "base64","utf8") + decipher.final("utf8");
};

const encrypt = (text) => {
    let secretKey;
    secretKey = process.env[`DATA_ENCRYPT_SECRET_KEY_${env}`];
    return encryptText(text,secretKey);
};

const decrypt = (text) => {
    let secretKey;
    secretKey = process.env[`DATA_ENCRYPT_SECRET_KEY_${env}`];
    return decryptText(text,secretKey);
};


module.exports = {
    encrypt,
    decrypt
};