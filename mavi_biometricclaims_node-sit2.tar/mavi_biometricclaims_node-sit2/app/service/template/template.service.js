const db = require("../../model");
const sequelize = db.sequelize;
const emailTemplate = db.emailTemplate;
const smsTemplate = db.smsTemplate;
const bitlyTable = db.bitlyLink


exports.emailTemplate = async (whereCondition) => {
    try {
      return await emailTemplate.findOne({
        where: whereCondition,
        raw: true,
      });
    } catch (error) {
      throw error;
    }
  };

  exports.smsTemplate = async (whereCondition) => {
    try {
      return await smsTemplate.findOne({
        where: whereCondition,
        raw: true,
      });
    } catch (error) {
      throw error;
    }
  };
  
  exports.bitlyDetail = async (whereCondition) => {
    try {
      return await bitlyTable.findOne({
        where: whereCondition,
        raw: true,
      });
    } catch (error) {
      throw error;
    }
  };