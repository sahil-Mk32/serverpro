const db = require("../../model");
const moment = require("moment");
class BulkCronJobService {
  constructor() {}

  createBulkCronJob = async (data) => {
    try {
      return await db.bulkCronJob.create(data);
    } catch (error) {
      throw error;
    }
  };

  updateBulkCronJob = async (data, whereCondition) => {
    try {
      return await db.bulkCronJob.update(
        data, 
        {
          where: whereCondition,
        }
      );
    } catch (error) {
      throw error;
    }
  }

  getCronJobList = async (whereCondition) => {
    try {
      return await db.bulkCronJob.findAll({
        where: whereCondition,
        include: {
          model: db.module,
          required: false,
        },
      });
    } catch (error) {
      throw error;
    }
  }

  getCronJobCount = async (whereCondition) => {
    try {
      return await db.bulkCronJob.count({
        where: whereCondition
      });
    } catch (error) {
      throw error;
    }
  }

  getCronJob = async (whereCondition) => {
    try {
      return await db.bulkCronJob.findOne({
        where: whereCondition,
      })
    } catch (error) {
      throw error;
    }
  }

  resetProcessingStuckJobs = async (whereCondition) => {
    try {
      let jobs = await this.getCronJobList(whereCondition);
      for (let job of jobs) {
        if (moment.utc().diff(moment.utc(job.cron_start_date), 'minutes') > 30) {
          await this.updateBulkCronJob(
            {status: 'open'},
            {status: 'processing'},
          );
        }
      }
    } catch (error) {
      throw error;
    }
  }
}

exports.BulkCronJobService = new BulkCronJobService();
