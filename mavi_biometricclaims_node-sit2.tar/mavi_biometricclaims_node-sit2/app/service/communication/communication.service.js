const db = require("../../model");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");
const nodemailer = require("nodemailer");
const { template } = require("lodash");
const utils = require("../../common/utils");
const env = process.env.ENV.toUpperCase();
const commQueue = db.commQueue;
const communication = db.communication;
const emailTemplate = db.emailTemplate;
const email_t_table = "clm_email_template";
const smsTemplate = db.smsTemplate;
const sms_t_table = "clm_sms_template";
const axios= require('axios');

exports.getEmailTemplate = async (whereCondition) => {
  try {
    return await emailTemplate.findAll({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};


exports.getSmsTemplate = async (whereCondition) => {
  try {
    return await smsTemplate.findAll({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.createCommunication = async (data) => {
  try {
    return await communication.create(data, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getAllCommQueueData = async (whereCondition) => {
  try {
    return await commQueue.findAll({
      where: whereCondition,
      limit:200,
      order: [
        ['id', 'ASC']
      ],
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.createCommQueue = async (data) => {
  try {
    return await commQueue.create(data, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.updatecommQueue = async (updateData, whereCondition) => {
  try {
    await commQueue.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};

exports.dataMappingWithVariables = async (template,objectData) => {
  try {
    for (const key in objectData) {
      template = template? template.replace(new RegExp(`{${key}}`, "g"), `${objectData[key]}`): null;
    }
    return template;
  } catch (error) {
    throw error;
  }
};

exports.emailTrigger = async (ele) => {
  try { 
    let recipient = ele.data.TO;
    let subject = ele.data.SUBJECT.SUBJECT;
    let objectData = ele.data.BODY;
    let data = await this.getEmailTemplate({
			id: ele.templateid
		});
    let templateBody = data[0].body;
    if(recipient.length>0){
      let template = await this.dataMappingWithVariables(templateBody,objectData);
      this.sendMail(recipient, subject, template, ele);
    }
  } catch (error) {
    throw error;
  }
};

exports.sendMail = async (to, subject, html, optional = null) => {
  let status = 'send';
  let mailTransporter = nodemailer.createTransport({
    host: process.env["MAIL_HOST_" + env],
    port: process.env["MAIL_PORT_" + env],
    secure: false,
    auth: {
      user: process.env["MAIL_USERNAME_" + env],
      pass: process.env["MAIL_PASSWORD_" + env],
    },
  });

  let mailDetails = {
    from: process.env["MAIL_FROM_MAIL_" + env], to, subject, html
  };

  mailTransporter.sendMail(mailDetails, function (err, data) {
    if (err) { status = 'failed'} 
  });

  // insert data in communication table
  let communication = await this.createCommunication({
    type: "email",
    subject: subject,
    body: html,
    to: to.toString(),
    created: utils.getUTCDateTime(),
    modified: utils.getUTCDateTime(),
    status
  });

  // update comm_queue table
  if(optional){
    await this.updatecommQueue(
      { commid: communication.dataValues.id, status: "processed" },
      { id: optional.id }
    );
  }
};

exports.smsTrigger= async (ele)=>{
  try{
    let status = 'send';
    let recipient=ele.data.CUSTOMER_NAME;
    let mobile=ele.data.TO;
    //let template_id="1207169235398924255";
    let subject = ele.data.SUBJECT;
    let data = await this.getSmsTemplate({
			id: ele.templateid

		});
    let templateBody = data[0].template;
    objectData={
      "USER_FIRSTNAME" :ele.data.CUSTOMER_NAME,
      "CLAIM_NUMBER": ele.data.CLAIM_NUMBER,
      "CONSENT_PENDING_LINK": ele.data.CONSENT_PENDING_LINK,
      "POLICY_NUMBER": ele.data.POLICY_NUMBER,
      "PAYMENT_STOP_REASON": ele.data.PAYMENT_STOP_REASON,
			"CLAIM_REJECT_REASON": ele.data.CLAIM_REJECT_REASON,
      "CLAIM_APPROVED_AMOUNT":ele.data.CLAIM_APPROVED_AMOUNT,
      "AMOUNT":'',
      "A/C_NO":ele.data.CUSTOMER_ACCOUNT_NO,
    }
    if(recipient.length>0){
      let template = await this.dataMappingWithVariables(templateBody,objectData);
      this.sendSms(mobile,template,data[0].template_id);
    }
    let communication = await this.createCommunication({
      type: "sms",
      subject: subject,
      body: templateBody,
      to: mobile.toString(),
      created: utils.getUTCDateTime(),
      modified: utils.getUTCDateTime(),
      status
    });
    await this.updatecommQueue(
      { commid: communication.dataValues.id, status: "processed" },
      { id: ele.id }
    );


  }
  catch(err){
    console.log("error",err);
    return;
  }
}

//write sms send function here
exports.sendSms = async (mobile,smsBody,template_id) => {
  const username =process.env.SMS_USERNAME;
  const password = process.env.SMS_PASSWORD;
  const message = smsBody;
  const sender = process.env.SENDER;
  const mobileNumber = mobile;
  const templateId = template_id;
  const type='3';
  const apiUrl = `http://api.bulksmsgateway.in/sendmessage.php?user=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&mobile=${encodeURIComponent(mobileNumber)}&message=${encodeURIComponent(message)}&sender=${encodeURIComponent(sender)}&type=${encodeURIComponent(type)}&template_id=${encodeURIComponent(templateId)}`;
  let response =await axios.post(apiUrl);
  return response;
};