const { Op, fn, col } = require("sequelize");
const db = require("../../model");
const sequelize = db.sequelize;

class PicklistReviewModeServie {
  constructor() {}

  async getReviewMode(whereCondition) {
    try {
      return await db.picklistReviewMode.findOne({
        where: whereCondition,
      });
    } catch (error) {
      throw error;
    }
  }
}

exports.PicklistReviewModeServie = new PicklistReviewModeServie();
