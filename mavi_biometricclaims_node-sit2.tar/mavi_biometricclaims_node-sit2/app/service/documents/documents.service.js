const { Op } = require("sequelize");
const db = require("../../model");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");
const env = process.env.ENV.toUpperCase();
const utils = require("../../common/utils");
const { getUserName } = require("../../service/user/user.service");

exports.getDocumentsSectionData = async (sectionId) => {
  try {
    return await db.claimSection.findAll({
      where: { parent_section_id: sectionId, status: "Active", deleted: 0 },
    });
  } catch (error) {
    throw error;
  }
};
exports.getSectionData = async (whereCondition) => {
  try {
    return await db.claimSection.findOne({
      where: whereCondition,
      raw:true
    });
  } catch (error) {
    throw error;
  }
};

exports.getDocumentsFieldDataByFieldId = async (sectionFieldIds) => {
  try {
    /* return await sequelize.query(
      `SELECT 
        clm_field.field_id AS id,
        clm_field.type,
        clm_uitype_master.inputtype AS 'inputType',
        clm_field.fieldname AS 'name',
        clm_field.fieldlabel AS 'label',
        clm_field.mandatory AS 'required',
        clm_field.placeholder,
        clm_field.minimumlength,
        clm_field.maximumlength,
        clm_field.disabled,
        clm_field.readonly,
        clm_field.hidden,
        clm_field.pattern,
        clm_field.validations,
        clm_field.styles,
        clm_field.callbacks,
        clm_field.options
        FROM
        clm_field
            INNER JOIN
        clm_uitype_master ON clm_uitype_master.id = clm_field.uitype
        WHERE
            clm_field.field_id IN (` +
        sectionFieldIds +
        `)
        ORDER BY sequence`,
      {
        type: QueryTypes.SELECT,
      }
    ); */

    return await db.field.findAll({
      attributes: [
        ["field_id", "id"],
        "type",
        ["fieldname", "name"],
        ["fieldlabel", "label"],
        ["mandatory", "required"],
        "placeholder",
        "minimumlength",
        "maximumlength",
        "disabled",
        "readonly",
        "hidden",
        "pattern",
        "validations",
        "styles",
        "callbacks",
        "options",
      ],
      where: {
        field_id: {
          [Op.in]: sectionFieldIds.split(","),
        },
      },
      include: {
        model: db.uiType,
        required: true,
        attributes: [["inputtype", "inputType"]],
      },
    });
  } catch (error) {
    throw error;
  }
};

exports.createDocument = async (data) => {
  try {
    return await db.document.create(data);
  } catch(error) {
    throw error
  }
};

exports.getDocumentHistoryList = async (req,moduleId) => {
    let postReq = {};
    let totalClaimCount = 0;
    let dataRow = [];
    let data = {
      module: moduleId,
      application_id: process.env["DS_APPLICATION_ID_" + env],
      reference_id: req.body.id
    };

    let timestamp = Math.floor(Date.now()/1000);
    let headerToken = utils.createExposeHeaderToken(timestamp,'DS');			
    let baseUrl = process.env['BASE_URL_DS_' + env];
    postReq["api_name"] = "getDocumentList";
    postReq["api_data_key"] = 100005;
    postReq["expose"] = "node_ds";
    postReq["base_url"] = baseUrl;
    postReq["url"] = "/api/document/history";

    postReq["headers"] = {
      authorization: headerToken,
      ContentType: 'application/json',
      timestamp: timestamp
    };
    
    let response = await utils.postAPI(data, postReq);
    if(response.responseStatus == 'success') {
      
      let responseData = response.responseData;
      for(const row of responseData){
        let fieldObj = {};
        fieldObj["doc_type"] = row.type ? row.type : '';
        fieldObj["doc_name"] = {"name":row.original_filename ? row.original_filename : '', "path":row.filepath ? row.filepath : ''};
        fieldObj["doc_date"] = row.createdAt ? utils.getLocalDateTimeDMY(row.createdAt) : '';
        fieldObj["uploaded_by"] = row.createdBy ? await getUserName({ id: row.createdBy }) : '';
        fieldObj["updatedAt"] = row.updatedAt ? utils.getLocalDateTimeDMY(row.updatedAt) : '';
        fieldObj["updatedBy"] = row.updatedBy ?await getUserName({ id: row.updatedBy }): "";
        fieldObj["doc_deleted_status"] = (row.deleted == 1) ? "Yes" : "No";
        dataRow.push(fieldObj);
        totalClaimCount++;
      }
    }
    return [dataRow,totalClaimCount];
};
