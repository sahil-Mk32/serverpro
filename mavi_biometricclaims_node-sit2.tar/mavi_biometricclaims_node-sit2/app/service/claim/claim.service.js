const db = require("../../model");
const moment = require("moment");
const sequelize = db.sequelize;
const { QueryTypes,Op } = require("sequelize");
const salesClientprogramTable = db.salesClientprogram;
const userClientProgram = db.userClientProgram;
const commonSer = require("../../service/common/common.service");
const utils = require("../../common/utils");
const env = process.env.ENV.toUpperCase();
const moduleEntity = db.moduleEntity;
const bitlyLink = db.bitlyLink;
const clmClaim = db.claimsModel;
const clmClaimDisabilities = db.claimDisabilitiesModel;
const claimSubStatus = db.claimSubStatus;
const statusHistory = db.claimStatusHistory;
const modeTrackerBasic = db.modtrackerBasic;
const modtrackerDetail = db.modtrackerDetail;
const fieldData = db.field;
const paymentSchedule = db.paymentSchedule;


exports.getClientProgramId = async (whereCondition) => {
  try {
    return await salesClientprogramTable.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.isUserProgramExists = async (req, clientprogram_id) => {
  try {
    const program_data = await userClientProgram.findOne({
      where: { id_str: req.user.id_str, clientprogram_id: clientprogram_id },
      raw: true
    });
    if (program_data != null) {
      return true;
    } else {
      return false;
    }
  } catch (err) {
    throw (err);
  }
}

exports.getsubStatusDetails = async (whereCondition) => {
  try {
    return await claimSubstatus.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.moduleEntityNum = async (whereCondition) => {
  try {
    const result = await sequelize.transaction(async (t) => {
      const moduleEntityRow = await moduleEntity.findOne({
        where: whereCondition,
        raw: true,
      }, { transaction: t });

      curIdIncrease = moduleEntityRow.cur_id + 1;
      const moduleEntityUpdate = await moduleEntity.update({ cur_id: curIdIncrease }, {
        where: whereCondition,
        raw: true,
      }, { transaction: t });

      let claim_no = moduleEntityRow.prefix + '' + moduleEntityRow.cur_id;
      return claim_no;
    });
    return result;
  }
  catch (error) {
    throw error;
  }
};

exports.createBitlyLink = async (createData) => {
  try {
    return await bitlyLink.create(createData, {
      raw: true
    });
  } catch (error) {
    throw error;
  }
};

exports.getClaimFormSectionData = async (ref_module) => {

  try {

    return await sequelize.query(
      `SELECT 
      clm_section.page,
      clm_section.type,
      clm_section.title,
      clm_section.id,
      clm_section.content,
      clm_section.name,
      clm_section.displayType,
      clm_section.styles,
      clm_section.disabled,
      clm_section.hidden,
      clm_section.hidetoggle,
      clm_section.expanded,
      clm_section.fields
  FROM
      clm_section
          INNER JOIN
      clm_module ON clm_module.id = clm_section.module_id
  WHERE
      LOWER(clm_module.name) = '${ref_module}'
          AND clm_section.type = 'fieldset'
          AND clm_section.page = 'customer_confirm';
      `,
      {
        type: QueryTypes.SELECT,
      }
    );

  } catch (error) {
    throw error;
  }
};

exports.getCustomFieldDataByFieldId = async (sectionFieldIds) => {
  try {
    return await sequelize.query(
      `SELECT 
      clm_field.field_id AS id,
      clm_field.type,
      clm_uitype_master.inputtype AS 'inputType',
      clm_field.fieldname AS 'name',
      clm_field.fieldlabel AS 'label',
      clm_field.mandatory AS 'required',
      clm_field.disabled,
      clm_field.readonly,
      clm_field.hidden,
      clm_field.validations,
      clm_field.styles,
      clm_field.customerform_view
  FROM
      clm_field
          INNER JOIN
      clm_uitype_master ON clm_uitype_master.id = clm_field.uitype
  WHERE
      clm_field.field_id IN (` +
      sectionFieldIds +
      `)
  ORDER BY sequence`,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.getClmBitlyLink = async (token) => {
  try {
    return await sequelize.query(
      `SELECT 
      clm_bitly_link.ref_id, clm_claim.*
  FROM
      clm_claim
          INNER JOIN
      clm_bitly_link ON clm_bitly_link.ref_id = clm_claim.id
  WHERE
      clm_bitly_link.status = 'verified'
          AND clm_bitly_link.otp_status = 'verified'
          AND clm_bitly_link.token = '${token}';`,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.getToken = async (token) => {
  try {
    return await sequelize.query(
      `SELECT 
      clm_bitly_link.ref_id,
      clm_bitly_link.token,
      clm_claim.*
  FROM
      clm_claim
          INNER JOIN
      clm_bitly_link ON clm_bitly_link.ref_id = clm_claim.id
  WHERE
      clm_bitly_link.token = '${token}'
        `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};
exports.getuseridByTokendata = async (token) => {
  try {
    return await sequelize.query(
      `SELECT 
        created_by as id,mobileno as mobileNo,emailid as emailId 
      FROM clm_bitly_link 
    WHERE 
      token ='${token}';
        `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};
exports.getuserdata= async (id) => {
  try {
    return await sequelize.query(
      `SELECT 
        *
      FROM clm_user 
    WHERE 
      id ='${id}';
        `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};


exports.updateClaimData = async (updateData, whereCondition) => {
  try {
    await clmClaim.update(updateData, {
      where: whereCondition,
    });
    return await this.getClaimData(whereCondition)
  } catch (error) {
    throw error;
  }
};

exports.createClaim = async (data) => {
  try {
    return await clmClaim.create(data, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.createClaimDisablities = async (data) => {
  try {
    return await clmClaimDisabilities.bulkCreate(data, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getClaimDisabilitiesData = async (whereCondition, attributesCondition=null) => {
  try {
    return await clmClaimDisabilities.findAll({
      where: whereCondition,
      attributes: attributesCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getClaimDisabilitiesSingleRow = async (whereCondition) => {
  try {
    return await clmClaimDisabilities.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.updateClaimDisabilitiesData = async (updateData, whereCondition) => {
  try {
    await clmClaimDisabilities.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};

exports.createModeTrackerBasicData = async (data) => {
  try {
    return await modeTrackerBasic.create(data, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.createModtrackerDetailData = async (data) => {
  try {
    return await modtrackerDetail.create(data, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};
exports.getSubStatus = async (whereCondition) => {
  try {
    return await claimSubStatus.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};
exports.getNextPaymentDue = async (claim_number,payment_id) => {
  try {
    return await paymentSchedule.min('id',{
      where: {
        claim_number:claim_number,
        payment_status: {
          [Op.ne]: 'Payment Disbursed'
        },
        id: {
          [Op.ne]: payment_id
        },
      },
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getOnePaymentInfo = async (whereCondition) => {
  try {
    return await paymentSchedule.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};


exports.getFieldData = async (whereCondition) => {
  try {
    return await fieldData.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getDashboarBox = async () => {
  try {
    return await sequelize.query(
      `
      SELECT 
    cdb.dashboard_box
FROM
    clm_dashboard_box AS cdb
GROUP BY cdb.dashboard_box
ORDER BY 'dashboard_box' DESC;
        `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.createStatusHistoryData = async (createClaimStatus) => {
  try {
    await statusHistory.create(createClaimStatus);
  } catch (error) {
    throw error;
  }
};


exports.getBitlyLinkData = async (whereCondition) => {
  try {
    return await bitlyLink.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.updateBitlyLinkData = async (updateData, whereCondition) => {
  try {
    await bitlyLink.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};


exports.getClaimList = async (req, module_id) => {
  try {
    const decode = req.user;
    const role_id = decode.role_id;
    const userid = decode.id;

    const module_nm = req.body.module === "claims" ? "Claims" : "";

    let clientProgramCodeStr = decode.clientprogram_code.map(x => "'" + x + "'").toString();

    let subQuery = "";
    let obj = req.body.search;
    let listQuery = "";

    let keys = Object.keys(obj);
    if (keys.length > 0) {
      for (var i = 0; i < keys.length; i++) {
        if (obj[keys[i]] != '' && obj[keys[i]] != null) {
          if (keys[i] == 'created') {
            subQuery = subQuery + " AND DATE(clm_claim." + keys[i] + ") = '" + obj[keys[i]] + "'";
          } else if (keys[i] == 'substatus' && obj[keys[i]] == 'All') {
            subQuery = subQuery + "";
          }
          else {
            subQuery = subQuery + " AND clm_claim." + keys[i] + " LIKE '%" + obj[keys[i]] + "%'";
          }
        }
      }
    }

    let subQueryOrderBy = "";
    let sort = req.body.sort;
    if (sort != null && req.body.sort.key != '' && req.body.sort.value != '') {
      subQueryOrderBy = " ORDER BY " + req.body.sort.key + " " + req.body.sort.value;
    } else {
      subQueryOrderBy = " ORDER BY clm_claim.created desc ";
    }

    let page = parseInt(req.body.page);
    let size = parseInt(req.body.size);
    let limit_start = ((page * size) - size);
    let limit_end = size;
    let start_date_time = req.body.filter.start_date;
    let end_date_time = req.body.filter.end_date;

    const start_date = moment(start_date_time, "YYYY-MM-DD").format("YYYY-MM-DD");
    const end_date = moment(end_date_time, "YYYY-MM-DD").format("YYYY-MM-DD");
    if (role_id == 1 || role_id == 9 || role_id == 8) {
      listQuery = "";
    } else if (role_id == 6) {
      listQuery = " AND clm_claim.assigned_to IN (SELECT id from clm_user WHERE role_id = '7')";
    }
    else if (role_id == 4) {
      listQuery = " AND clm_claim.assigned_to IN (SELECT id from clm_user WHERE role_id = '5')";
    }
    else {
      listQuery = " AND clm_claim.assigned_to IN (SELECT id from clm_user WHERE role_id = '" + role_id + "')";
    }
    let whereCondition = " clm_claim.deleted = '0' AND clm_sales_clientprogram.clientprogram_code  IN (" + clientProgramCodeStr + ") AND DATE(clm_claim.created) BETWEEN '" + start_date + "'AND '" + end_date + "'" + subQuery + listQuery;

    const claimCount = await getClaimDataListCount(whereCondition, clientProgramCodeStr, start_date, end_date);
    const totalClaimCount = claimCount[0].total_count;



    const getClaimDataList = await sequelize.query(
      `SELECT 
        clm_claim.claim_number,
        clm_claim.policyholder_full_name,
        clm_claim.policy_no,
        DATE(clm_claim.created) AS created,
        DATE(clm_claim.modified) AS modified,
        CONCAT(clm_user.first_name,' ',clm_user.last_name) AS assigned_to,
        clm_claim.substatus,
        clm_claim.status,
        clm_claim.client_program_id,
        clm_claim.plan_name
        FROM 
        clm_claim
        INNER JOIN clm_sales_clientprogram
        ON clm_sales_clientprogram.id = clm_claim.client_program_id
        INNER JOIN  clm_user ON clm_claim.assigned_to = clm_user.id
        WHERE`+ whereCondition + subQueryOrderBy + " LIMIT " + limit_start + `,` + limit_end,
      {
        type: QueryTypes.SELECT,
      });
    let dataRow = []
    let editPermession = 0;

    for (const row of getClaimDataList) {
      const subStatusId = await commonSer.getSubstatusIdBystatusSubstatus(row.status, row.substatus);
      editPermession = await commonSer.getClaimStatusAndSubStatusWiseEditPermession(module_id, role_id, row.client_program_id, subStatusId);
      editPermession = editPermession === 1 ? true : false;
      let fieldObj = {};
      fieldObj["claim_number"] = row.claim_number ? row.claim_number : '';
      //fieldObj["policyholder_full_name"] = row.policyholder_full_name ? row.policyholder_full_name : '';
      fieldObj["policy_no"] = row.policy_no ? row.policy_no : '';
      fieldObj["created"] = row.created ? row.created : '';
      fieldObj["modified"] = row.modified ? row.modified : '';
      fieldObj["assigned_to"] = row.assigned_to ? row.assigned_to : '';
      fieldObj["status"] = row.status ? row.status : '';
      fieldObj["substatus"] = row.substatus ? row.substatus : "";
      fieldObj["planname"] = row.plan_name ? row.plan_name : '';
      fieldObj["action"] = { "create": false, "view": true, "edit": editPermession, "delete": false };
      //decrypting
      utils.getDecryptedJson(fieldObj);
      dataRow.push(fieldObj);
    }
    return [dataRow, totalClaimCount];
  } catch (error) {
    throw error;
  }
};



const getClaimDataListCount = async (whereCondition, clientProgramCodeStr, start_date, end_date) => {
  const claimCount = await sequelize.query(
    `SELECT 
        count(clm_claim.claim_number) as 'total_count'
        FROM 
        clm_claim
        INNER JOIN clm_sales_clientprogram
        ON clm_sales_clientprogram.id = clm_claim.client_program_id 
        WHERE`+ whereCondition,
    {
      type: QueryTypes.SELECT,
    });
  return claimCount;
};

exports.getClaimData = async (whereCondition) => {
  try {
    return await clmClaim.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.claimReportDOwnloadData = async (start_date, end_date) => {
  try {
    const claimDataDownload = await sequelize.query(
      `SELECT
        clm_claim.id AS 'id',
        clm_claim.id_str AS 'id_str', 
        clm_claim.claim_number AS 'Claim No',
        clm_claim.policyholder_full_name AS 'Customer Name',
        clm_claim.policy_no AS 'Policy No',
        CONCAT(clm_user.first_name,' ',clm_user.last_name) AS 'Assign To',
        clm_claim.substatus AS 'Sub Status',
        clm_claim.created AS 'Claim Created Date'
        FROM clm_claim
        INNER JOIN clm_user
        ON clm_user.id = clm_claim.assigned_to
        WHERE clm_claim.deleted='0' AND 
        DATE(clm_claim.created) BETWEEN '`+ start_date + `' AND '` + end_date + `'`,
      {
        type: QueryTypes.SELECT,
      });
    return claimDataDownload;
  } catch (error) {
    throw error;
  }
};

exports.claimStatusCount = async (start_date, end_date, cpid_str) => {
  try {
    return await sequelize.query(
      `SELECT 
        COUNT(cc.id) AS count, cdb.dashboard_box
    FROM
        clm_claim AS cc
            LEFT JOIN
        clm_dashboard_box AS cdb ON cdb.clm_status = cc.status
            AND cdb.clm_substatus = cc.substatus
    WHERE
        DATE(cc.created) BETWEEN '${start_date}' AND '${end_date}' AND  cc.client_program_id IN(select clientprogram_id from clm_user_clientprogram where id_str = '${cpid_str}')
    GROUP BY cdb.dashboard_box
      `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.dashboardAgeBucket = async (cpid_str) => {
  try {
    return await clmClaim.findAll({
      attributes: [
        [sequelize.literal("ROW_NUMBER() OVER (ORDER BY status)"), "id"],
        "status",
        "substatus",
        [
          sequelize.fn("SUM", sequelize.literal(`CASE WHEN DATEDIFF(CURDATE(), created) <= 0 THEN 1 ELSE 0 END`)),
          "<= 0",
        ],
        [
          sequelize.fn("SUM", sequelize.literal(`CASE WHEN DATEDIFF(CURDATE(), created) > 0 AND DATEDIFF(CURDATE(), created) <= 3 THEN 1 ELSE 0 END`)),
          ">0 and <=3",
        ],
        [
          sequelize.fn("SUM", sequelize.literal(`CASE WHEN DATEDIFF(CURDATE(), created) > 3 AND DATEDIFF(CURDATE(), created) <= 8 THEN 1 ELSE 0 END`)),
          ">3 and <=8",
        ],
        [
          sequelize.fn("SUM", sequelize.literal(`CASE WHEN DATEDIFF(CURDATE(), created) > 8 AND DATEDIFF(CURDATE(), created) <= 16 THEN 1 ELSE 0 END`)),
          ">8 and <=16",
        ],
        [
          sequelize.fn("SUM", sequelize.literal(`CASE WHEN DATEDIFF(CURDATE(), created) > 16 AND DATEDIFF(CURDATE(), created) <= 22 THEN 1 ELSE 0 END`)),
          ">16 and <=22",
        ],
        [
          sequelize.fn("SUM", sequelize.literal(`CASE WHEN DATEDIFF(CURDATE(), created) > 22 THEN 1 ELSE 0 END`)),
          ">22",
        ],
        [sequelize.fn("COUNT", sequelize.col("*")), "grand_total"],
      ],
      where: {
        client_program_id: [sequelize.literal(`select clientprogram_id from clm_user_clientprogram where id_str='${cpid_str}'`)]
      },
      group: ["status", "substatus"],
      order: [[sequelize.literal("grand_total"), "DESC"]],
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};


exports.pendingClaim = async (cpid_str) => {
  try {
    return await sequelize.query(
      `
        SELECT
        (role.rolename) as role, (user.username) as name, (cc.assigned_to) as assign_to,
      SUM(CASE WHEN datediff(CURDATE(), cc.created) <= 0 THEN 1 ELSE 0 END) AS "<=0",
      SUM(CASE WHEN datediff(CURDATE(), cc.created) > 0 AND DATEDIFF(CURDATE(), cc.created) <= 3 THEN 1 ELSE 0 END) AS ">0 and <=3",
      SUM(CASE WHEN datediff(CURDATE(), cc.created) > 3 AND DATEDIFF(CURDATE(), cc.created) <= 8 THEN 1 ELSE 0 END) AS ">3 and <=8",
      SUM(CASE WHEN datediff(CURDATE(), cc.created) > 8 AND DATEDIFF(CURDATE(), cc.created) <= 16 THEN 1 ELSE 0 END) AS ">8 and <=16",
      SUM(CASE WHEN datediff(CURDATE(), cc.created) > 16 AND DATEDIFF(CURDATE(), cc.created) <= 22 THEN 1 ELSE 0 END) AS ">16 and <=22",
      SUM(CASE WHEN datediff(CURDATE(), cc.created) > 22 THEN 1 ELSE 0 END) AS ">22",
      COUNT(cc.assigned_to) as total_claim 
        FROM
        clm_claim AS cc
        INNER JOIN
        clm_user AS user ON user.id = cc.assigned_to
        INNER JOIN
        clm_role AS role ON role.id = user.role_id
        WHERE cc.client_program_id IN(select clientprogram_id from clm_user_clientprogram where id_str = '${cpid_str}') AND cc.status NOT IN ('Claim Closed')
        group by cc.assigned_to
        ORDER BY "total_claim" DESC
      `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.roleClaimDetails = async (id, cpid_str) => {
  try {
    return await sequelize.query(
      `SELECT 
        cc.claim_number as claim_no,
      cc.policyholder_full_name as policy_holder_name,
      cc.policy_no as policy_no,
      cc.created as claim_created_date,
      cu.username as assigned_to,
      ROW_NUMBER() over(order by cc.status) as tat,
      cc.status
		FROM
        clm_claim AS cc left join clm_user as cu on 
    cu.id = cc.assigned_to
        where cc.assigned_to = "${id}" AND cc.client_program_id IN(select clientprogram_id from clm_user_clientprogram where id_str = '${cpid_str}') AND cc.status NOT IN ('Claim Closed')
		ORDER BY cc.assigned_to  ASC;
    `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.isCreatePermission = async (whereCondition, policy_end_date = null, qualifying_end_date = null) => {
  try {
    let permission = true;
    let data = await clmClaim.findOne({
      where: whereCondition,
      attributes: ["policy_no"],
      raw: true,
    });
    if (data) { permission = false; }
    if ((moment(qualifying_end_date) > moment(utils.getUTCDate())) || (moment(policy_end_date) < moment(utils.getUTCDate()))) { permission = false; }
    return permission;
  } catch (error) {
    throw error;
  }
};

// create consent pending bitly
exports.getConsentPendingURL = async (req) => {
  const createdBy = (req.user && req.user.id) ? req.user.id : 1;
  const base_url = process.env["CUST_PORTAL_BASE_URL_" + env];
  const module = 'claims';
  const otpMobile = req.commMobileNo;
  const otpEmail = req.commCustomerEmailId;
  const expireTime = moment().add(process.env["CUST_BITLYLINK_EXPIRETIME_" + env], "hour").format("YYYY-MM-DD H:mm:ss");
  const currentTime = moment().format("YYYY-MM-DD H:mm:ss");

  //code start Bitly Link send on mail after claim creation
  const OldBitlyLinkOtpExpire = await sequelize.query(
    `UPDATE clm_otp_log INNER JOIN clm_bitly_link ON clm_bitly_link.id = clm_otp_log.record_id
       SET clm_otp_log.otp_status = "expire", clm_otp_log.modified = '`+ currentTime + `'
       WHERE LOWER(clm_bitly_link.ref_module) = 'claims' AND clm_otp_log.otp_status = 'send' 
       AND clm_bitly_link.status = 'send' AND clm_bitly_link.ref_id = `+ req.commClaimId + ``,
    {
      type: QueryTypes.UPDATE,
    });

  const oldBitlyLinkExpire = await sequelize.query(
    `UPDATE clm_bitly_link SET clm_bitly_link.status = "expire", clm_bitly_link.otp_status = "expire",
      clm_bitly_link.modified = '`+ currentTime + `'
       WHERE LOWER(clm_bitly_link.ref_module) = 'claims' 
       AND clm_bitly_link.status = 'send' AND clm_bitly_link.ref_id = `+ req.commClaimId + ``,
    {
      type: QueryTypes.UPDATE,
    });

  const token = utils.generateUserId();
  const bitly_link = base_url + `/` + module + `/view/` + token;
  await this.createBitlyLink({
    ref_module: 'Claims',
    ref_id: req.commClaimId,
    token,
    bitly_link,
    emailid: otpEmail,
    mobileno: otpMobile,
    expiry_datetime: expireTime,
    source: 'WEB',
    created: currentTime,
    modified: currentTime,
    created_by: createdBy,
    modified_by: createdBy,
    status: 'send',
    delete: 0
  });
  return bitly_link;
};

exports.claimDisablitiesPayload = async (multiple_disablities,decode,case_id) => {
  try {
    let dataRow = []
    for (const row of multiple_disablities) {
      let fieldObj = {};
      fieldObj["case_id"] = case_id,
      fieldObj["illness"] = row.illness,
      fieldObj["accident"] = row.accident,
      fieldObj["disability"] = row.disability,
      fieldObj["date_symptoms_first_started"] = row.date_symptoms_first_started,
      fieldObj["date_of_accident"] = row.date_of_accident,
      fieldObj["time_of_accident"] = row.time_of_accident,
      fieldObj["location_of_accident"] = row.location_of_accident,
      fieldObj["doctor_confirmed_disability_date"] = row.doctor_confirmed_disability_date,
      fieldObj["details_the_nature"] = row.details_the_nature,
      fieldObj["have_you_suffered_previuos_illnes_or_injury"] = row.have_you_suffered_previuos_illnes_or_injury,
      fieldObj["specify"] = row.specify,
      fieldObj["date_of_first_consultation_of_injury_illness"] = row.date_of_first_consultation_of_injury_illness,
      fieldObj["date_of_noticed_symptoms_condition"] = row.date_of_noticed_symptoms_condition,
      fieldObj["job_related_injury"] = row.job_related_injury,
      fieldObj["claim_against_other_party"] = row.claim_against_other_party,
      fieldObj["claimed_amount"] = row.claimed_amount,
      fieldObj["description_of_claim"] = row.description_of_claim,
      fieldObj["another_party_or_insurance_company_name"] = row.another_party_or_insurance_company_name,
      fieldObj["created"] = utils.getUTCDateTime(),
      fieldObj["created_by"] = decode?.id
      dataRow.push(fieldObj);
    }
    return dataRow;
  } catch (error) {
    throw error;
  }
};

exports.isDisabilityDateVaild = async (multiple_disablities) => {
  try {
    let vaild = true;
    for (const row of multiple_disablities) {
      let doctorConfirmDate = row.doctor_confirmed_disability_date;
      let todayDate = moment(new moment(), "YYYY-MM-DD");
      let dateDiff = todayDate.diff(doctorConfirmDate,"days");  
      if(dateDiff > 15 || dateDiff < 0){
        vaild = false;
      }
    }
    return vaild;
  } catch (error) {
    throw error;
  }
};

