const db = require("../../model");
const hashingService = require("../../common/hashing");
const apiLogsTable = db.apiLogs;
const commonService = require("../../common/utils");

exports.apiLogData = async (req) => {
  try {
    const token = req.headers["x-access-token"];
    const data = await apiLogsTable.create({
      api_name: req.url.replace("/", ""),
      api_url: req?.originalUrl,
      method: req?.method,
      req_body: JSON.stringify(req?.body),
      //req_body: hashingService.encrypt(JSON.stringify(req?.body)),
      req_header: JSON.stringify(req?.rawHeaders),
      created_date: req?.createdDate,
      status: req?.status,
      ip: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
    });
    return data;
  } catch (error) {
    throw error;
  }
};

exports.updateApiLogs = async (responseData, whereCondition) => {
  try {
    responseData.response = responseData.response;
    //responseData.response = hashingService.encrypt(responseData.response);
    await apiLogsTable.update(responseData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};
exports.updateApiLogsData = async (responseData, whereCondition) => {
  try {
    await apiLogsTable.update(responseData, {
      where: whereCondition,
    },);
  } catch (error) {
    throw error;
  }
};



exports.getApiLogData = async (whereCondition) => {
  try {
    return await apiLogsTable.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};