const db = require("../../model");

class RoleWiseStatusService {
  constructor() {}

  getRoleWiseStatus = async (whereCondition) => {
    try {
      return await db.roleWiseStatus.findOne({
        where: whereCondition,
        include: {
          model: db.role,
          required: true,
        },
      })
    } catch (error) {
      throw error;
    }
  };
}

exports.RoleWiseStatusService = new RoleWiseStatusService();
