const httpStatus = require("http-status");
const utils = require("../../common/utils");
const claimService = require("../../service/claim/claim.service");
const claimModel = require("../../model/claim/claim");
const otpService = require("../../service/otp/otp.service");
const moment = require("moment");
const pickService = require("../../service/picklist/picklist.service");
const { QueryTypes } = require("sequelize");
const db = require("../../model");
const message = require("../../common/messages");
const { documentsCtrl } = require("../../controllers/documents/documents.controller");
const sequelize = db.sequelize;
const { Op } = require("sequelize");
const converter = require('json-2-csv');
const commoService = require("../../service/common/common.service");
const { communicationCtrl } = require("../../controllers/communication/communication.controller");
const {customerFormRendering,actionsButton,docActionsButton} = require('../../uirender/claim_customerFormRendering')
const { RoleService } = require("../../service/role/role");
const { getUser } = require("../../service/user/user.service");
const commonService = require("../../common/utils");

exports.clmCreateFrmRender = async (req, res) => {
    try {

      let { id, module, method, request_type, mode } = req.body;
      mode = mode.toUpperCase();

      if(method == "create_individual_claim" && (request_type == "create" || request_type == "edit") && module == "claims" && mode == "WEB")
      {
          const getClaimFormSectionData = await sequelize.query(
              `SELECT  
          clm_section.type,
          clm_section.title ,
          clm_section.content ,
          clm_section.name ,
          clm_section.displayType ,
          clm_section.styles,
          clm_section.disabled ,
          clm_section.hidden,
          clm_section.hidetoggle, 
          clm_section.expanded,
          clm_section.fields  
          FROM 
          clm_section 
          INNER JOIN clm_module 
          ON clm_module.id= clm_section.module_id
          WHERE LOWER(clm_module.name)='claims' and clm_section.type='accordian' AND page = 'claims_create' ORDER BY sequence ASC`,
            {
                type: QueryTypes.SELECT,
            });
          let claimFormGroup  = [];
          for(const row of getClaimFormSectionData){
                let newObj = {};
                newObj["type"] = row.type ? row.type : '';
                newObj["title"] = row.title ? row.title : '';
                newObj["content"] = row.content ? row.content : false;
                newObj["name"] = row.name ? row.name : false;
                newObj["displayType"] = row.displayType === 1 ? row.displayType : false;
                newObj["styles"] = row.styles ? JSON.parse(row.styles) : null;
                newObj["disabled"] = row.disabled === 1 ? true : false;
                newObj["hidden"] = row.hidden === 1 ? true : false;
                newObj["hidetoggle"] = row.hidetoggle === 1 ? true : false;
                newObj["expanded"] = row.expanded === 1 ? true : false;

                //Illness & Injury Details
                //newObj["fields"] = row.fields ? await getFieldDataBySectionFieldId(row.fields) : "";
                if(row.name != 'illness_&_injury_details') {
                  newObj["fields"] = row.fields ? await getFieldDataBySectionFieldId(row.fields) : "";
                }
                else{
                  newObj["fields"] = await getFormGroupFrmRender(row.fields);
                }
                
                claimFormGroup.push(newObj);
            }
            /* console.log(claimFormGroup);
                return res.status(httpStatus.OK).json({
                status: claimFormGroup,
                msg: "OK",
            });*/
        
        let actionsButton = '{"type": "button","name": "action","inputType": "button","displayType": "default","styles": {},"options": [{"type": "button","name": "button","inputType": "button","label": "Generate BitlyLink","icon": "","disabled": false,"styles": {	"color": "primary","css": {"background": "rgb(4, 171, 233)"}},"callbacks": [{"redirectURL": "claims","method": "","action": "api/claim/create","type": "submit","fieldData": null}],"action": "submit"}]}';
        let claimFormStyle = '{"id": "claimForm","class": ["dynmaic-form"]}';
        

        let claimCreateFormObj = {
        name: "claim_form",
        title: "Create Claim",
        styles: JSON.parse(claimFormStyle),
        groups: claimFormGroup,
        actions : JSON.parse(actionsButton)
        }

        //claimCreateFormObj = JSON.stringify(claimCreateFormObj);
        //claimCreateFormObj1 = claimCreateFormObj.replace(/\\/g, '');

        //res.status().message
        //res.status(200).send(claimCreateFormObj1);

      const response = {
        responseCode: 200,
        responseMessage: "Ok",
        responseData: claimCreateFormObj,
      };
      // update response in api_log table
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );

        utils.responseWithJsonBody(res, 200 ,response )
      }
    } catch (err) {
      //const errorMsg = err.errors ? err.errors[0].message : err.message;
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
    
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: err.message,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: err.message,
      });
    }
  };
 
  const getFieldDataBySectionFieldId = async (sectionFieldIds) => {
  let fieldData  = [];
    const getFieldDataByFieldId = await sequelize.query(
      `SELECT  
      clm_field.field_id AS id,
      clm_field.type ,
      clm_uitype_master.inputtype AS 'inputType' ,
      clm_field.fieldname AS 'name' ,
      clm_field.fieldlabel AS 'label' ,
      clm_field.mandatory AS 'required',
      clm_field.placeholder ,
      clm_field.minimumlength AS 'minlength',
      clm_field.maximumlength AS 'maxlength', 
      clm_field.readonly,
      clm_field.disabled,
      clm_field.hidden,
      clm_field.pattern,
      clm_field.validations,
      clm_field.styles,
      clm_field.callbacks,
      clm_field.options  
      FROM 
      clm_field
      INNER JOIN clm_uitype_master
      ON clm_uitype_master.id = clm_field.uitype
      WHERE clm_field.field_id IN(`+sectionFieldIds+`) ORDER BY sequence`,
          {
              type: QueryTypes.SELECT,
          });
         for(const row of getFieldDataByFieldId){
            let fieldObj = {};
            
            fieldObj["id"] = row.id ? row.id : '';
            fieldObj["type"] = row.type ? row.type : '';
            fieldObj["inputType"] = row.inputType ? row.inputType : '';
            fieldObj["name"] = row.name ? row.name : '';
            fieldObj["label"] = row.label ? row.label : '';
            fieldObj["required"] = row.required === 1 ? true : false;
            fieldObj["value"] = '';
            fieldObj["placeholder"] = row.placeholder ? row.placeholder : '';
            fieldObj["minlength"] = row.minlength ? row.minlength : 0;
            fieldObj["maxlength"] = row.maxlength ? row.maxlength : 0;
            fieldObj["readonly"] = row.readonly === 1 ? true : false;
            fieldObj["disabled"] = row.disabled === 1 ? true : false;
            fieldObj["hidden"] = row.hidden === 1 ? true : false;
            fieldObj["pattern"] = row.pattern ? row.pattern : null;
            fieldObj["validations"] = row.validations ? JSON.parse(row.validations) : null;
            fieldObj["styles"] = row.styles ? JSON.parse(row.styles) : null;
            fieldObj["callbacks"] = row.callbacks ? JSON.parse(row.callbacks) : false;
            if(row.name == 'disability' || row.name == 'account_holder'||row.name=='time_of_accident')
            {
                if(row.name=='time_of_accident'){
                  fieldObj["options"] = await pickService.getPickListAllData('time');
                }else{
                  fieldObj["options"] = await pickService.getPickListAllData(row.name);
                }
               
            }
            else{
                fieldObj["options"] = row.options ? JSON.parse(row.options) : false;
            }
            
            fieldData.push(fieldObj);
        };
        return fieldData;
}

const getFormGroupFrmRender = async (sectionFieldIds) => {
  let newObj ={};
  let fieldData = {};
  let groupData  = [];

  newObj["type"] = 'formarray';
  newObj["inputType"] = '';
  newObj["displayType"] = '';
  newObj["icon"] = '';
  newObj["placeholder"] = '';
  newObj["title"] = 'Illness & Injury Details';
  newObj["name"] = 'illness_and_injury_details';
  newObj["label"] = 'Illness & Injury Details';
  newObj["styles"] = null;
  newObj["disabled"] = false;
  newObj["hidden"] = false;
  newObj["hidetoggle"] = false;
  newObj["expanded"] = true;
  newObj["callbacks"] = [];
  
  let actionsButton = '{"name":"action","type":"button","inputType":"button","displayType":"default","label":"","styles":{"appearance":""},"options":[{"type":"button","name":"button","inputType":"button","label":"Add New","icon":"add","action":"addGroup","styles":{"appearance":"","color":"primary"},"enableOn":1},{"type":"button","name":"button","inputType":"button","label":"Remove","icon":"delete","action":"delete","styles":{"appearance":"","color":"warn"},"enableOn":2}],"callbacks":[]}';
  fieldData['fields'] = await getFieldDataBySectionFieldId(sectionFieldIds);
  fieldData['actions'] = JSON.parse(actionsButton);
  
  newObj["formgroups"] = fieldData;

  groupData.push(newObj);
  return groupData;
}

exports.clmCustomerFrmRender = async (req, res) => {
  try {
    const { method, token } = req.body;

    const getValue = await claimService.getClmBitlyLink(token);
    utils.getDecryptedJson(getValue[0]);
    if (getValue.length <= 0) {
      return res.status(httpStatus.BAD_REQUEST).json({
        success: false,
        message: message.INVALID_TOKEN,
      });
    }
    const getClaimDisabilitiesData = await claimService.getClaimDisabilitiesData({case_id: getValue[0].id});
    let claim_method = (getValue[0].substatus === "Consent Pending") ? "claims" : (getValue[0].substatus === "Document Pending") ? "document":"";
    let isDocumentSubmitted = (claim_method == '') ? true : false;
    const getClaimFormSectionData = await claimService.getClaimFormSectionData(
      claim_method
    );
    let claimFormGroup = [];
    for (const element of getClaimFormSectionData) {

      let dataObj = {};

      if(element.name == 'cust_illness_&_injury_details')
      {
        //let i = 0;
        for (const disabilitesData of getClaimDisabilitiesData) {
          dataObj["type"] =
          element?.type == "accordian" ? "fieldset" : element?.type;
          dataObj["name"] = element?.name;
          dataObj["label"] = element?.title;
          dataObj["value"] = "";
          dataObj["editable"] = false;
          dataObj["required"] = false;
          dataObj["disabled"] = false;
          dataObj["hidden"] = false;
          dataObj["readonly"] = false;
          dataObj["width"] = 100;
          dataObj["offset"] = 0;
          claimFormGroup.push(dataObj);

          const getCustomFieldDataByFieldId = await claimService.getCustomFieldDataByFieldId(element?.fields);
          for (const row of getCustomFieldDataByFieldId) {
            let fieldObj = {};
            fieldObj["type"] = row.type ? row.type : "";
            fieldObj["name"] = row.name ? row.name : "";
            fieldObj["label"] = row.label ? row.label : "";
                      
            fieldObj["value"] = disabilitesData[row.name] ? disabilitesData[row.name] : " ";
            (fieldObj["editable"] = false), (fieldObj["required"] = false);
            (fieldObj["width"] = 50), (fieldObj["offset"] = 0);
 
            fieldObj["disabled"] = false;
            fieldObj["hidden"] = false
            fieldObj["readonly"] = true;
            
            if (row.name == "disability") {
              fieldObj["value"] = disabilitesData.disability ? disabilitesData.disability : " ", 
              fieldObj["options"] = await pickService.getPickListAllData(row.name);
            }
            if (
              row.name == "job_related_injury" ||
              row.name == "claim_against_other_party" ||
              row.name == "have_you_suffered_previuos_illnes_or_injury" ||
              row.name == "accident" ||
              row.name == "illness"
            ) 
            {
              fieldObj["value"] = disabilitesData[row.name] == 1 ? "Yes" : "No";
            }
            
            if (disabilitesData.illness && (row.name == "date_of_accident" || row.name == "time_of_accident" || row.name == "location_of_accident")) 
            {
              continue;
            }

            if (Object.keys(customerFormRendering[0]).includes(row.name)) {
              Object.assign(fieldObj, customerFormRendering[0][row.name]);
            }
            
            claimFormGroup.push(fieldObj);
          }
          //i++
        }
      }
      else{
        dataObj["type"] =
        element?.type == "accordian" ? "fieldset" : element?.type;
        dataObj["name"] = element?.name;
        dataObj["label"] = element?.title;
        dataObj["value"] = "";
        dataObj["editable"] = false;
        dataObj["required"] = false;
        dataObj["disabled"] = false;
        dataObj["hidden"] = false;
        dataObj["readonly"] = false;
        dataObj["width"] = 100;
        dataObj["offset"] = 0;
        claimFormGroup.push(dataObj);

        const getCustomFieldDataByFieldId = await claimService.getCustomFieldDataByFieldId(element?.fields);

        for (const row of getCustomFieldDataByFieldId) {
          let fieldObj = {};
  
          fieldObj["type"] = row.type ? row.type : "";
          fieldObj["name"] = row.name ? row.name : "";
          fieldObj["label"] = row.label ? row.label : "";
          
          if(claim_method == 'document'){
            fieldObj["value"] = (row.name=='claimants_statement') ? claim_doc : 
            (row.name=='clinical_abstract_form') ? clinical_doc : (row.name=='doctors_statement_or_attending_physician_statement') ? doctors_doc : 
            (row.name=='medical_reports') ? medical_doc : (row.name=='police_report') ? police_doc : 
            (row.name=='deputy_appointment') ? deputy_doc : (row.name=='salary_slips') ? salary_doc : '';
            
            fieldObj["editable"] = true;
            fieldObj["required"] = true;
            fieldObj["callbacks"] = [{"method": "document_upload","action": "api/documents/customer_upload","type": "dependent","fieldData": null}];
            fieldObj["width"] = 100;
            fieldObj["offset"] = 0;
            fieldObj["fileType"] = "";
            fieldObj["multiple"] = false;
            fieldObj["hint"] = "Formats allowed are jpg, png, pdf. Maximum file size allowed is 5 MB.";
            fieldObj["validations"] = row.validations ? JSON.parse(row.validations) : "";
          }
          else{
            fieldObj["value"] = getValue[0][row.name] ? getValue[0][row.name] : " ";
            (fieldObj["editable"] = false), (fieldObj["required"] = false);
            (fieldObj["width"] = 50), (fieldObj["offset"] = 0);
          }
  
          fieldObj["disabled"] = false;
          fieldObj["hidden"] = false
          fieldObj["readonly"] = true;
          
          if (row.name == "disability") {
            fieldObj["value"] = getValue[0].disability ? JSON.parse(getValue[0].disability) : " ", 
            fieldObj["options"] = await pickService.getPickListAllData(row.name);
          }
          if (
            row.name == "job_related_injury" ||
            row.name == "claim_against_other_party" ||
            row.name == "have_you_suffered_previuos_illnes_or_injury" ||
            row.name == "accident" ||
            row.name == "illness"
          ) 
          {
            fieldObj["value"] = getValue[0][row.name] == 1 ? "YES" : "NO";
          }  

          if(getValue[0].relation_with_insured == "" && (row.name == "relation_with_insured" || row.name == "specify_relationship"))
          {
            continue;
          }
  
          if (Object.keys(customerFormRendering[0]).includes(row.name)) {
            Object.assign(fieldObj, customerFormRendering[0][row.name]);
          }
  
          claimFormGroup.push(fieldObj);
        }
      }
          
      
      if(claim_method == 'document'){
        req.body = {...req.body,module:'claims',id:getValue[0].claim_number}
        let documentData = await documentsCtrl.getCustomerDocumentList(req, res);
        var claim_doc = documentData.claimants_statement ? documentData.claimants_statement : "";
        var clinical_doc = documentData.clinical_abstract_form ? documentData.clinical_abstract_form : "";
        var doctors_doc = documentData.doctors_statement_or_attending_physician_statement ? documentData.doctors_statement_or_attending_physician_statement : "";
        var medical_doc =  documentData.medical_reports ? documentData.medical_reports : "";
        var police_doc = documentData.police_report ? documentData.police_report : "";
        var deputy_doc = documentData.deputy_appointment ? documentData.deputy_appointment : "";
        var salary_doc = documentData.salary_slips ? documentData.salary_slips : "";
      }

      
    };
    

    if(claim_method == 'claims'){
      const checkBox = {
        type: "confirm_checkbox",
        name: "are_you_confirm",
        label: "Are you sure want to submit?",
        value: "",
        editable: true,
        required: true,
        disabled: false,
        hidden: false,
        readonly: true,
        width: 100,
        offset: 0,
      };
      claimFormGroup.push(checkBox);
    }
    let responseObj = {
      type: "",
      title: "",
      name: "",
      id: "",
      styles: [],
      isDocumentSubmitted : isDocumentSubmitted,
      fields: claimFormGroup,
      actions: (claim_method == 'document') ? JSON.parse(docActionsButton) : (claim_method == 'claims') ? JSON.parse(actionsButton) : "",
    };

    let response = {
      responseCode: httpStatus.OK,
      responseMessage: message.CLM_CUSTOMER_FORM_RENDER,
      responseData: responseObj,
    };

    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    utils.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.approveCustomerForm = async (req, res) => {
  const saveApiLog = await utils.createApiLogs(req);
  try {
    
    const { token, action, method } = req.body;
    var documentUpload = true;
    const claimData = await claimService.getToken(token);

    const user_id= await claimService.getuseridByTokendata(token);
    if(user_id.length>=1){
      await commonService.updateLogsData(
        { 
          user_id:JSON.stringify(user_id[0].id)
        },
        { id:saveApiLog.dataValues.id }
      );
    }
    if (claimData.length <= 0) {
      const response = utils.response(
        200,
        message.CLAIM_NOT_FOUND,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:saveApiLog.dataValues.id }
      );

      await utils.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.OK).json(response);
    }

    const status = (method == 'accept') ? "Document Pending" : (method == 'submit') ? "Document Submitted" : "Consent Reject";
    const responseMsg = (method == 'submit') ? message.DOC_UPDATE_MSG :  message.UPDATE_SUBSTATUS;

    const userData = await getUser({ username: 'customer_user' });
    const roleData = await RoleService.getRole({ rolename: 'Customer' });
    let caseSubStatus = await claimService.getSubStatus({pname: 'New Case Request', name: status});			
		const assignTo = await commoService.getNextAssignTo(claimData[0].client_program_id,roleData.id,caseSubStatus.id,"NA");
    
    const updateStatusData = await claimService.updateClaimData(
      { substatus: status, assigned_to: assignTo, modified: utils.getUTCDateTime(), modified_by: userData.id },
      { id: claimData[0]?.id }
    );

    await claimService.createStatusHistoryData({
      case_id: claimData[0]?.id,
      case_status_id: caseSubStatus.pid,
      case_substatus_id:caseSubStatus.id,
      case_status:caseSubStatus.pname,
      case_substatus:caseSubStatus.name,
      assigned_to: assignTo,
      modified: new Date(),
      modified_by: userData.id,
      source: claimData[0]?.source,
    });

    if(method != 'accept'){
      await claimService.updateBitlyLinkData({ status: "expire" }, { token });
      documentUpload = false;
    }
    
    // email trigger function
    await communicationCtrl.pushTemplateCommQueue({...req,claimNumber:claimData[0].claim_number});

    let response = {
      responseCode: httpStatus.OK,
      responseMessage: responseMsg,
      responseData: null,
      documentUpload
    };
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );

    await utils.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    //utils.dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;

    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await utils.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};

exports.statusUpdateOtp = async (req,res)=>{
  try{
    
    const bitlyToken =req.params.token;
    let emailClaimData = await communicationService.getEmailTempByClaim(bitlyToken);
    const code = utils.generateOTP();
    const user_id= await claimService.getuseridByTokendata(bitlyToken);
    if(user_id.length >=1){
      await commonService.updateLogsData(
        { 
          user_id:JSON.stringify(user_id[0].id)
        },
        { id:req.dataValues }
      );
    }
    const startTime = moment()
      .add(24, "hour")
      .format("YYYY-MM-DD h:mm:ss");

    await otpService.createOTP({
      record_id: emailClaimData[0].id,
      templateid: emailClaimData[0].templateID,
      record_type: "user",
      mobile: emailClaimData[0].mobile,
      emailid:emailClaimData[0].email_id,
      otp: code,
      expirytime: startTime,
      created: utils.getUTCDateTime(),
      modified: utils.getUTCDateTime()
    });

    emailClaimData[0]["OTP"]=code

    await communicationService.statusMailSend(
      "OTP for Bitly Link",
      emailClaimData[0],
      "OTP for Bitly Link",
      "otp"
    );

    await communicationService.createCommunication({
      type: "email",
      pid: emailClaimData[2].claimId,
      subject: emailClaimData[2].subject,
      body: emailClaimData[2].body,
      to: emailClaimData[2].email,
      cc:  emailClaimData[2].email,
      created: utils.getUTCDateTime(),
      modified: utils.getUTCDateTime(),
      status: "send",
      response: " ",
    });

    let response = {
      responseCode: httpStatus.OK,
      responseMessage: `${message.SENT_USER_PASSWORD_OTP}${emailClaimData[0].email}`,
      responseData: null,
    };
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );

    return res.status(httpStatus.OK).json(response);
  }catch (err) {
    //utils.dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: req.dataValues }
    );

    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
}

exports.reminderMail = async () => {
  try {
    const claimStatusBasedEmail = await commoService.claimStatusBasedEmail();

    for (const key of claimStatusBasedEmail) {
      const claimTemplateDetail =
        await communicationService.claimTemplateDetail(key);
      const commuData = await communicationService.createCommQueue({
        commid: "",
        caseid: key.caseid,
        roleid: key.roleid,
        type: "email",
        templateid: key.templateID,
        data: claimTemplateDetail,
        bitly_url: key.bitly_link,
        created: utils.getUTCDateTime(),
        modified: utils.getUTCDateTime(),
        status: "processed",
      });
    
      if (key.substatus == "Document Pending") {
        await communicationService.statusMailSend(
          "Reminder for Pending Document",
          key,
          "Biometric : Reminder for Pending Document"
        );
      } else {
        await communicationService.statusMailSend(
          "Reminder for Claim Consent",
          key,
          "Biometric : Reminder for Claim Consent"
        );
      };
 
    const communication = await communicationService.createCommunication({
      type: "email",
      pid: key.caseid,
      subject: key.substatus == "Document Pending" ? "Biometric : Reminder for Pending Document" : "Biometric : Reminder for Claim Consent", 
      body: key.body,
      to: commuData.dataValues.data.TO[0],
      cc: commuData.dataValues.data.CC[0],
      created: utils.getUTCDateTime(),
      modified: utils.getUTCDateTime(),
      status: "send",
      response: " ",
    });

    await communicationService.updatecommQueue(
      { commid: communication.dataValues.id },
      { id: commuData.dataValues.id }
    );
    }
  } catch (err) {
    utils.dumpError(err);
  }
};

exports.getClaimDetails = async (req, res) => {
  try {
    //const saveApiLog = await utils.createApiLogs(req);
    const { id, request_type, module } = req.body;
    let response = {
      responseCode: httpStatus.OK,
      responseMessage: message.CLAIM_RECEIVED,
      responseData: null,
    };
    if (module == "claims" && request_type == "view") {
      const data = await claimService.getClaimData({
        claim_number: id,
      });

      utils.getDecryptedJson(data);

      response["responseData"] = data;
      data["disability"] = JSON.parse(data["disability"]);
      data["illness"] = data["illness"] == 1? true : false
      data["accident"] = data["accident"] == 1? true : false
      data["have_you_suffered_previuos_illnes_or_injury"] = data["have_you_suffered_previuos_illnes_or_injury"] == 1? true : false
      data["job_related_injury"] = data["job_related_injury"] == 1? true : false
      data["claim_against_other_party"] = data["claim_against_other_party"] == 1? true : false
      data["same_account_details"] = data["same_account_details"] == 1? true : false
      clientprogram_code_data = await claimService.getClientProgramId({ id : data["client_program_id"] }); 
      data["clientprogram_code"] = clientprogram_code_data.clientprogram_code;
    }
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await utils.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues}
    );
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    //utils.dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    await utils.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await utils.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: req.dataValues}
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};

exports.downloadClaimReport = async (req, res) => {
  try {
    const { start_date, end_date, deleted } = req.body;
    const claimReportData = await claimService.claimReportDOwnloadData(start_date,end_date);

    //const csvData = await converter.json2csv(claimReportData);
    let response = {
      responseCode: httpStatus.OK,
      responseMessage: message.CLAIM_RECEIVED,
      responseData: claimReportData,
    };
    if(claimReportData.length > 0){  
      for(let claimReport of claimReportData){
        claimReport = utils.getDecryptedJson(claimReport);
      }
    }
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );

    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    //utils.dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: req.dataValues }
    );
  
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};


