const httpStatus = require("http-status");
const {
  disabilityValidationRes,
  previousIllnessInjuryValidationRes,
  claimAgainstOtherPartyValidationRes,
  noSameAccountDetailsValidationRes,
  AccountDetailsoptions,
} = require("../../uirender/claim_callback");
const utils = require("../../common/utils");
const message = require("../../common/messages");
const moment = require("moment");
const todayDate = moment().format("YYYY-MM-DD");
const claimService = require("../../service/claim/claim.service");

exports.claimCallbackDeatails = async (req, res) => {
  try {
    const fieldname = req?.body?.fieldname;
    switch (fieldname) {
      case "illness":
        await illnessCase(req, res);
        break;
      case "accident":
        await accidentCase(req, res);
        break;
      case "disability":
        await disabilityCase(req, res);
        break;
      case "have_you_suffered_previuos_illnes_or_injury":
        await previuosIllnesOrInjuryCase(req, res);
        break;
      case "claim_against_other_party":
        await claimAgainstOtherPartyCase(req, res);
        break;
      case "job_related_injury":
        await jobRelatedInjuryCase(req, res);
        break;
      case "date_symptoms_first_started":
        await dateRelatedCase(req, res);
        break;
      case "date_of_accident":
        await dateRelatedCase(req, res);
        break;
      case "date_of_first_consultation_of_injury_illness":
        await dateRelatedCase(req, res);
        break;
      case "same_account_details":
        await sameAccountDetailsCase(req, res);
        break;
      case "account_holder":
        await diffAccountDetailsCase(req, res);
        break;
      case "relation_with_insured":
        await specifyRelationshipCase(req, res);
        break;
      case "doctor_confirmed_disability_date":
        await dateRelatedCase(req, res);
        break;
      case "date_of_noticed_symptoms_condition":
        await dateRelatedCase(req, res);
        break;
      default:
        break;
    }
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

// illnessCase checkbox click callback function
const illnessCase = async (req, res) => {
  try 
  {
    const {formdata,action,id,type, } = req.body;
    let fieldDisabled = true;
    let indexValue = req.body.options.index;
    let mainData = req.body.options.mainData[indexValue];
    let fieldvalue = formdata.illness_and_injury_details[indexValue].illness
    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };
    
    // let date_symptoms_first_started_fieldvalue = "";
    let accident_fieldvalue = false;
    let doctor_confirmed_disability_date_fieldvalue = "";
    let date_of_accident_fieldvalue = "";
    let time_of_accident_fieldvalue = "";
    let location_of_accident_fieldvalue = "";
    let date_of_noticed_symptoms_condition_fieldvalue = "";
    let date_symptoms_first_started_fieldvalue = "";
    let date_of_first_consultation_of_injury_illness_fieldvalue = "";

    if(type == "onload"){
      //const claimData = await claimService.getClaimData({claim_number: id});
      const getClaimDisabilitiesData = await claimService.getClaimDisabilitiesSingleRow({id: mainData.id});
      //utils.getDecryptedJson(claimData);
      date_symptoms_first_started_fieldvalue = getClaimDisabilitiesData.date_symptoms_first_started;
      accident_fieldvalue = (getClaimDisabilitiesData.accident==1)?true:false;
      doctor_confirmed_disability_date_fieldvalue = getClaimDisabilitiesData.doctor_confirmed_disability_date;
      date_of_noticed_symptoms_condition_fieldvalue = getClaimDisabilitiesData.date_of_noticed_symptoms_condition;
      date_of_first_consultation_of_injury_illness_fieldvalue = getClaimDisabilitiesData.date_of_first_consultation_of_injury_illness;
    }

    const dateDiff = utils.calculateMinMaxDate(formdata.policy_start_date)


    if (fieldvalue == true) 
    {
   
      response["responseData"] = [
        {
          fieldname: "illness",
          fieldtype: "checkbox",
          defaultvalue: "",
          fieldvalue: fieldvalue,
          validations:[{action:"required",value:true,},],
        },
        {
          fieldname: "accident",
          fieldtype: "checkbox",
          defaultvalue: "",
          fieldvalue: accident_fieldvalue,
          validations:[{action:"required",value:false,},],
        },
        {
          fieldname: "date_symptoms_first_started",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_symptoms_first_started_fieldvalue,
          validations:[{action:"required",value:true,}, 
          {action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},
        ],
        },
        {
          fieldname: "doctor_confirmed_disability_date",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: doctor_confirmed_disability_date_fieldvalue,
          validations:[
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},
            {action:"required",value:true,},
          ],
        },
        {
          fieldname: "date_of_accident",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_accident_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:(action=='view')?fieldDisabled:true,},
          {action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},],
        },
        {
          fieldname: "date_of_noticed_symptoms_condition",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_noticed_symptoms_condition_fieldvalue,
          validations:[
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},
            {action:"required",value:true,},
          ],
        },
        {
          fieldname: "date_of_first_consultation_of_injury_illness",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_first_consultation_of_injury_illness_fieldvalue,
          validations:[
            {action:"required",value:true,},
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},

          ]
        },
        {
          fieldname: "time_of_accident",
          fieldvalue: time_of_accident_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:(action=='view')?fieldDisabled:true,},],
        },
        {
          fieldname: "location_of_accident",
          fieldtype: "input",
          fieldvalue: location_of_accident_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:(action=='view')?fieldDisabled:true,},],
        },
      ];
    }
    else 
    {
      response["responseData"] = [
        {
          fieldname: "date_symptoms_first_started",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_symptoms_first_started_fieldvalue,
          validations:[{action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},
        ],
        },
        {
          fieldname: "date_of_noticed_symptoms_condition",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_noticed_symptoms_condition_fieldvalue,
          validations:[
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},
            {action:"required",value:true,},
          ],
        },
        {
          fieldname: "date_of_first_consultation_of_injury_illness",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_first_consultation_of_injury_illness_fieldvalue,
          validations:[
            {action:"required",value:true,},
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},

          ]
        },
        {
          fieldname: "accident",
          fieldtype: "checkbox",
          defaultvalue: "",
          fieldvalue: accident_fieldvalue,
          validations:[{action:"required",value:true,},],
        },
      ];
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

// accidentCase checkbox click callback function
const accidentCase = async (req, res) => {
  try {
    const {formdata,action,id,type } = req.body;
    let fieldDisabled = true;
    let indexValue = req.body.options.index;
    let mainData = req.body.options.mainData[indexValue];
    let fieldvalue = formdata.illness_and_injury_details[indexValue].accident

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };

    let illness_fieldvalue = false;
    let doctor_confirmed_disability_date_fieldvalue = "";
    let date_symptoms_first_started_fieldvalue = "";
    let date_of_accident_fieldvalue = "";
    let time_of_accident_fieldvalue = "";
    let location_of_accident_fieldvalue = "";
    let date_of_noticed_symptoms_condition_fieldvalue = "";
    let date_of_first_consultation_of_injury_illness_fieldvalue="";



    if(type == "onload"){
      //const claimData = await claimService.getClaimData({claim_number: id});
      const getClaimDisabilitiesData = await claimService.getClaimDisabilitiesSingleRow({id: mainData.id});
      illness_fieldvalue = getClaimDisabilitiesData.illness;
      doctor_confirmed_disability_date_fieldvalue = getClaimDisabilitiesData.doctor_confirmed_disability_date;
      date_of_accident_fieldvalue = getClaimDisabilitiesData.date_of_accident;
      time_of_accident_fieldvalue = getClaimDisabilitiesData.time_of_accident;
      location_of_accident_fieldvalue = getClaimDisabilitiesData.location_of_accident;
      date_symptoms_first_started_fieldvalue = getClaimDisabilitiesData.date_symptoms_first_started;
      date_of_first_consultation_of_injury_illness_fieldvalue = getClaimDisabilitiesData.date_of_first_consultation_of_injury_illness;
    }

    const dateDiff = utils.calculateMinMaxDate(formdata.policy_start_date)

    if (fieldvalue == true) 
    {
 
      response["responseData"] = [
        {
          fieldname: "accident",
          fieldtype: "checkbox",
          defaultvalue: "",
          fieldvalue: true,
          validations:[{action:"required",value:true,},],
        },
        {
          fieldname: "illness",
          fieldtype: "checkbox",
          defaultvalue: "",
          fieldvalue: (illness_fieldvalue==1)?true:false,
          validations:[{action:"required",value:false,},],
        },
        {
          fieldname: "date_symptoms_first_started",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_symptoms_first_started_fieldvalue,
          validations:[{action:"required",value:true,},{action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},],
        },
        {
          fieldname: "doctor_confirmed_disability_date",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: doctor_confirmed_disability_date_fieldvalue,
          validations:[{action:"required",value:true,}, {action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},

        ],
        },
        {
          fieldname: "date_of_accident",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_accident_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:(action=='view')?fieldDisabled:false,}, {action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},],
        },
        {
          fieldname: "date_of_noticed_symptoms_condition",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_noticed_symptoms_condition_fieldvalue,
          validations:[
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},
            {action:"required",value:true,},
          ],
        },
        {
          fieldname: "date_of_first_consultation_of_injury_illness",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_first_consultation_of_injury_illness_fieldvalue,
          validations:[
            {action:"required",value:true,},
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},

          ]
        },
        {
          fieldname: "time_of_accident",
          fieldtype: "input",
          fieldvalue: time_of_accident_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:(action=='view')?fieldDisabled:false,},],
        },
        {
          fieldname: "location_of_accident",
          fieldtype: "input",
          fieldvalue: location_of_accident_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:(action=='view')?fieldDisabled:false,},],
        },
      ];
    } else {
      response["responseData"] = [
        {
          fieldname: "date_of_accident",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: "",
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},{action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},],
        },
        {
          fieldname: "date_of_noticed_symptoms_condition",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_noticed_symptoms_condition_fieldvalue,
          validations:[
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},
            {action:"required",value:true,},
          ],
        },
        {
          fieldname: "date_symptoms_first_started",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_symptoms_first_started_fieldvalue,
          validations:[{action:"required",value:true,},{action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},],
        },
        {
          fieldname: "date_of_first_consultation_of_injury_illness",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_first_consultation_of_injury_illness_fieldvalue,
          validations:[
            {action:"required",value:true,},
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},

          ]
        },
        {
          fieldname: "time_of_accident",
          fieldtype: "input",
          fieldvalue: "",
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "location_of_accident",
          fieldtype: "input",
          fieldvalue: "",
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "illness",
          fieldtype: "checkbox",
          defaultvalue: "",
          fieldvalue: (illness_fieldvalue==1)?true:false,
          validations:[{action:"required",value:true,},],
        },
      ];
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

// disabilityCase doropdown click callback function
const disabilityCase = async (req, res) => {
  try 
  {
    const { fieldvalue, formdata,action,id,type } = req.body;
    let indexValue = req.body.options.index;
    let illness = formdata.illness_and_injury_details[indexValue].illness;
    let accident = formdata.illness_and_injury_details[indexValue].accident;
    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };
    let details_the_nature_fieldvalue = "";
    if(type == "onload"){
      const claimData = await claimService.getClaimData({claim_number: id});
      details_the_nature_fieldvalue = claimData.details_the_nature;
    }

    if(illness == false && accident == false) 
    {
      response["responseCode"] = 0;
      response["responseMessage"] = message.CHECK_ILLNESS_ACCIDENT;
      response["responseData"] = [];
    } else if (fieldvalue.includes("Other") == true && formdata.disability.includes("Other")  == true) 
    {
      response["responseData"] = [{
          fieldname: "details_the_nature",
          fieldtype: "input",
          defaultvalue: "",
          fieldvalue: details_the_nature_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        }];
    } 
    else
    {
      response["responseData"] = [{
          fieldname: "details_the_nature",
          fieldtype: "input",
          defaultvalue: "",
          fieldvalue: details_the_nature_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        }];
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

// previuosIllnesOrInjuryCase click callback function
const previuosIllnesOrInjuryCase = async (req, res) => {
  try 
  {
    const { fieldvalue, formdata,action,id,type } = req.body;

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };

    let specify_fieldvalue = "";
    if(type == "onload"){
      const claimData = await claimService.getClaimData({claim_number: id});
      specify_fieldvalue = claimData.specify;
    }

    if(fieldvalue == true) 
    {
      response["responseData"] = [{
        fieldname: "specify",
        fieldtype: "textarea",
        defaultvalue: "",
        fieldvalue: specify_fieldvalue,
        validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
      }];
    }
    else if(fieldvalue == false) 
    {
      response["responseData"] = [{
          fieldname: "specify",
          fieldtype: "textarea",
          defaultvalue: "",
          fieldvalue: specify_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        }]
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

// claimAgainstOtherPartyCase click callback function
const claimAgainstOtherPartyCase = async (req, res) => {
  try {
    const { fieldvalue, formdata,action,id,type } = req.body;

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };

    let another_party_or_insurance_company_name_fieldvalue ="";
    let description_of_claim_fieldvalue = "";
    let claimed_amount_fieldvalue = "";
    if(type == "onload"){
      const claimData = await claimService.getClaimData({claim_number: id});
      another_party_or_insurance_company_name_fieldvalue = claimData.another_party_or_insurance_company_name;
      description_of_claim_fieldvalue = claimData.description_of_claim;
      claimed_amount_fieldvalue = claimData.claimed_amount;
    }

    if (fieldvalue == true) {
      response["responseData"] = [
        {
          fieldname: "another_party_or_insurance_company_name",
          fieldtype: "input",
          fieldvalue: another_party_or_insurance_company_name_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "description_of_claim",
          fieldtype: "textarea",
          defaultvalue: "",
          fieldvalue: description_of_claim_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "claimed_amount",
          fieldtype: "input",
          fieldvalue: claimed_amount_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
      ];
    } else if (fieldvalue == false ) {
      response["responseData"] = [
        {
          fieldname: "another_party_or_insurance_company_name",
          fieldtype: "input",
          fieldvalue: another_party_or_insurance_company_name_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "description_of_claim",
          fieldtype: "textarea",
          defaultvalue: "",
          fieldvalue: description_of_claim_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "claimed_amount",
          fieldtype: "input",
          fieldvalue: claimed_amount_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
      ]
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

const jobRelatedInjuryCase = async (req, res) => {
  try {
    const { fieldvalue, formdata,action,id,type } = req.body;

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };

    let another_party_or_insurance_company_name_fieldvalue = "";
    let description_of_claim_fieldvalue = "";
    let claimed_amount_fieldvalue = "";
    if(type == "onload"){
      const claimData = await claimService.getClaimData({claim_number: id});
      another_party_or_insurance_company_name_fieldvalue = claimData.another_party_or_insurance_company_name;
      description_of_claim_fieldvalue = claimData.description_of_claim;
      claimed_amount_fieldvalue = claimData.claimed_amount;
    }

    if(fieldvalue == true && formdata.claim_against_other_party == true) 
    {
      response["responseData"] = [{
          fieldname: "another_party_or_insurance_company_name",
          fieldtype: "input",
          fieldvalue: another_party_or_insurance_company_name_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "description_of_claim",
          fieldtype: "textarea",
          defaultvalue: "",
          fieldvalue: description_of_claim_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "claimed_amount",
          fieldtype: "input",
          fieldvalue: claimed_amount_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        }];
    }
    else if(fieldvalue == false && formdata.claim_against_other_party == true )
    {
      response["responseData"] = [{
          fieldname: "another_party_or_insurance_company_name",
          fieldtype: "input",
          fieldvalue: another_party_or_insurance_company_name_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "description_of_claim",
          fieldtype: "textarea",
          defaultvalue: "",
          fieldvalue: description_of_claim_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "claimed_amount",
          fieldtype: "input",
          defaultvalue: "",
          fieldvalue: claimed_amount_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        }];
    } 
    else if((fieldvalue == true && formdata.claim_against_other_party == false) || (fieldvalue == false && formdata.claim_against_other_party == false )) 
    {
      response["responseData"] = [{
          fieldname: "another_party_or_insurance_company_name",
          fieldtype: "input",
          fieldvalue: another_party_or_insurance_company_name_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "description_of_claim",
          fieldtype: "textarea",
          defaultvalue: "",
          fieldvalue: description_of_claim_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "claimed_amount",
          fieldtype: "input",
          fieldvalue: claimed_amount_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        }]
      } 
    
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

//create function for dateRelatedCase
const dateRelatedCase = async (req, res) => {
  try 
  {
    const { fieldname,fieldvalue, formdata,action,id,type } = req.body;
    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };

    let date_of_first_consultation_of_injury_illness_fieldvalue = "";
    let doctor_confirmed_disability_date_fieldvalue = "";
    let date_of_noticed_symptoms_condition_fieldvalue = "";
    if(type == "onload"){
      const claimData = await claimService.getClaimData({claim_number: id});
      date_of_first_consultation_of_injury_illness_fieldvalue = claimData.date_of_first_consultation_of_injury_illness;
      doctor_confirmed_disability_date_fieldvalue = claimData.doctor_confirmed_disability_date;
      date_of_noticed_symptoms_condition_fieldvalue = claimData.date_of_noticed_symptoms_condition;
    }

    const dateDiff = utils.calculateMinMaxDate(formdata.policy_start_date)

    
    if(fieldname == "date_symptoms_first_started") 
    {
      response["responseData"] = [{
          fieldname: "date_of_first_consultation_of_injury_illness",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_first_consultation_of_injury_illness_fieldvalue,
          validations:[
          {action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},
          {action:"required",value:true,},]
        }];
    } 
    else if(fieldname == "date_of_accident")
    {
      response["responseData"] = [{
          fieldname: "date_of_first_consultation_of_injury_illness",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_first_consultation_of_injury_illness_fieldvalue,
          validations:[
          {action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},
          {action:"required",value:true},]
        }];
    } 
    else if(fieldname == "doctor_confirmed_disability_date") 
    {

      response["responseData"] = [{
          fieldname: "doctor_confirmed_disability_date",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: doctor_confirmed_disability_date_fieldvalue,
          validations:[
          {action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},],
        }];
    } 
    else if(fieldname == "date_of_first_consultation_of_injury_illness" || fieldname == "date_of_noticed_symptoms_condition") 
    {
      if(formdata.date_symptoms_first_started !== "" && formdata.date_symptoms_first_started !=="0000-00-00" && formdata.date_symptoms_first_started != null) 
      {
        let symptomsDate = utils.callBackDate(formdata.date_symptoms_first_started);
        response["responseData"] = [{
          fieldname: "date_of_noticed_symptoms_condition",
          fieldtype: "date",
          defaultvalue: "",
          fieldvalue: date_of_noticed_symptoms_condition_fieldvalue,
          validations:[
          {action: "min",value: dateDiff[0]},
          {action: "max",value: dateDiff[1]},
          {action:"required",value:true,},],
        }];
      }
      if(formdata.date_of_accident !== "" && formdata.date_of_accident !=="0000-00-00" && formdata.date_of_accident != null)  
      {
        let  accidentDate = utils.callBackDate(formdata.date_of_accident);
        response["responseData"] = [{
            fieldname: "date_of_noticed_symptoms_condition",
            fieldtype: "date",
            defaultvalue: "",
            fieldvalue: date_of_noticed_symptoms_condition_fieldvalue,
            validations:[       
            {action: "min",value: dateDiff[0]},
            {action: "max",value: dateDiff[1]},
            {action:"required",value:true},],
        }];
      }
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

const sameAccountDetailsCase = async (req, res) => {
  try 
  {
    const {fieldname,fieldvalue, formdata,action,id,type } = req.body;

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };

    let account_holder_fieldvalue = "";
    let name_of_next_of_kin_fieldvalue = "";
    let updt_mobile_no_fieldvalue = "";
    let updt_bank_name_fieldvalue = "";
    let updt_account_no_fieldvalue = "";
    let updt_branch_code_fieldvalue = "";
    if(type == "onload"){
      const claimData = await claimService.getClaimData({claim_number: id});
      utils.getDecryptedJson(claimData);
      account_holder_fieldvalue = claimData.account_holder;
      name_of_next_of_kin_fieldvalue = claimData.name_of_next_of_kin;
      updt_mobile_no_fieldvalue = claimData.updt_mobile_no;
      updt_bank_name_fieldvalue = claimData.updt_bank_name;
      updt_account_no_fieldvalue = claimData.updt_account_no;
      updt_branch_code_fieldvalue = claimData.updt_branch_code;
    }
 
    if (fieldvalue == true) 
    {
      response["responseData"] = [{
          fieldname: "account_holder",
          fieldtype: "select",
          defaultvalue: account_holder_fieldvalue,
          fieldvalue: [],
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "name_of_next_of_kin",
          fieldtype: "input",
          fieldvalue: name_of_next_of_kin_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "updt_mobile_no",
          fieldtype: "input",
          fieldvalue: updt_mobile_no_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "updt_bank_name",
          fieldtype: "input",
          fieldvalue: formdata.bank_name,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "updt_account_no",
          fieldtype: "input",
          fieldvalue: formdata.account_no,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "updt_branch_code",
          fieldtype: "input",
          fieldvalue: formdata.branch_code,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:true,},],
        }];
    } 
    else 
    {
      response["responseData"] = [{
          fieldname: "account_holder",
          fieldtype: "select",
          defaultvalue: account_holder_fieldvalue,
          fieldvalue: [
            {
              key: "Insured’s Bank Details",
              value: "Insured’s Bank Details",
              selected: false,
            },
            {
              key: "Next-of-kin/Guardian",
              value: "Next-of-kin/Guardian",
              selected: false,
            },
          ],
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "updt_bank_name",
          fieldtype: "input",
          fieldvalue: updt_bank_name_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "updt_account_no",
          fieldtype: "input",
          fieldvalue: updt_account_no_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "updt_branch_code",
          fieldtype: "input",
          fieldvalue: updt_branch_code_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        }
      ];
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

const diffAccountDetailsCase = async (req, res) => {
  try 
  {
    const {fieldname,fieldvalue, formdata,action,id,type } = req.body;

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };

    let specify_relationship_fieldvalue = "";
    let relation_with_insured_fieldvalue = "";
    let account_holder_name_fieldvalue = "";
    let updt_bank_name_fieldvalue = "";
    let updt_account_no_fieldvalue = "";
    let updt_branch_code_fieldvalue = "";
    let updt_email_id_fieldvalue = "";
    if(type == "onload"){
      const claimData = await claimService.getClaimData({claim_number: id});
      specify_relationship_fieldvalue = claimData.specify_relationship;
      relation_with_insured_fieldvalue = claimData.relation_with_insured;
      account_holder_name_fieldvalue = claimData.account_holder_name;
      updt_bank_name_fieldvalue = claimData.updt_bank_name;
      updt_account_no_fieldvalue = claimData.updt_account_no;
      updt_branch_code_fieldvalue = claimData.updt_branch_code;
      updt_email_id_fieldvalue = claimData.updt_email_id;
    }

    if (fieldvalue == "Insured’s Bank Details") 
    {
      response["responseData"] = [{
          fieldname: "updt_bank_name",
          fieldtype: "input",
          fieldvalue: updt_bank_name_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "updt_account_no",
          fieldtype: "input",
          fieldvalue: updt_account_no_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "updt_branch_code",
          fieldtype: "input",
          fieldvalue: updt_branch_code_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "relation_with_insured",
          fieldvalue: relation_with_insured_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "specify_relationship",
          fieldtype: "input",
          fieldvalue: specify_relationship_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "account_holder_name",
          fieldtype: "input",
          fieldvalue: account_holder_name_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},],
        }];
    } 
    else 
    {
      response["responseData"] = [{
          fieldname: "relation_with_insured",
          fieldvalue: relation_with_insured_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},],
        },{
          fieldname: "account_holder_name",
          fieldtype: "input",
          fieldvalue: account_holder_name_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},],
        },
        {
          fieldname: "specify_relationship",
          fieldtype: "input",
          fieldvalue: specify_relationship_fieldvalue,
          validations:[{action:"hidden",value:true,},{action:"disabled",value:true,},],
        },
        {
          fieldname: "updt_email_id",
          fieldtype: "input",
          fieldvalue: updt_email_id_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "updt_bank_name",
          fieldtype: "input",
          fieldvalue: updt_bank_name_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "updt_account_no",
          fieldtype: "input",
          fieldvalue: updt_account_no_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        },
        {
          fieldname: "updt_branch_code",
          fieldtype: "input",
          fieldvalue: updt_branch_code_fieldvalue,
          validations:[{action:"hidden",value:false,},{action:"disabled",value:false,},{action:"required",value:true,},],
        }];
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

const specifyRelationshipCase = async (req, res) => {
  try 
  {
    const {fieldname,fieldvalue, formdata,action,id,type } = req.body;

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DETAILS_RETRIEVED,
      responseData: null,
    };

    let specify_relationship_fieldvalue = "";
    if(type == "onload"){
      const claimData = await claimService.getClaimData({claim_number: id});
      specify_relationship_fieldvalue = claimData.specify_relationship;
    }

    if (fieldvalue == "Others") 
    {
      response["responseData"] = [{
          fieldname: "specify_relationship",
          fieldtype: "input",
          fieldvalue: specify_relationship_fieldvalue,
          validations:[{action:"hidden",value:false},{action:"disabled",value:false},{action:"required",value:true}]
        }];
    } 
    else 
    {
      response["responseData"] = [{
          fieldname: "specify_relationship",
          fieldvalue: specify_relationship_fieldvalue,
          validations:[{action:"hidden",value:true},{action:"disabled",value:true}]
        }];
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};
