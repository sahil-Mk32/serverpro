const httpStatus = require("http-status");
const utils = require("../../common/utils");
const moment = require("moment");
const moduleService = require("../../service/module/module.service");
const claimCtrl = require("../../controllers/claim/claim.controller");
const claimService = require("../../service/claim/claim.service");
const message = require("../../common/messages");
const communicationService = require("../../service/communication/communication.service");
const { RoleService } = require("../../service/role/role");
const { bitlyLink } = require("../../model");
class Communication {
	constructor() {}

	async pushTemplateCommQueue(req) {
		let commQueueData = {}
		const claimDetails = await claimService.getClaimData({claim_number:req.claimNumber});
		utils.getDecryptedJson(claimDetails);
		const subStatusDetails = await claimService.getSubStatus({pname: claimDetails.status, name: claimDetails.substatus, deleted:0});		
		req = {...req, commClaimId:claimDetails.id, commCustomerName:claimDetails.policyholder_full_name, commCustomerEmailId:claimDetails.email_id, commMobileNo:claimDetails.mobile_no, commPolicyNo:claimDetails.policy_no, commSubStatusId: subStatusDetails.id,account_no:claimDetails.account_no};
		
		if(subStatusDetails){

			this.pushEmailTemplateCommQueue(req);
			
			//sms-templates
			this.pushSmsTemplateCommQueue(req);
		}

	}

	// sms templates function create here 
	async pushSmsTemplateCommQueue(req){
		let consentPendingLink, bitlyLink, result, response, data = {};
		let recipientMobileData = [req.commMobileNo];
		let bitlyurl;
		const roleData = await RoleService.getRole({ rolename: 'Customer' });
		result = await communicationService.getSmsTemplate({
			case_substatus_id: req.commSubStatusId,
			deleted:'0'
		});
		
		for(const row of result)
		{
			req.commTemplateId = row.id ? row.id : '';
			
			if (row.bitly_link_type == 'cp')
			{
				consentPendingLink = await claimService.getConsentPendingURL(req);//get bitly link
				bitlyurl= await utils.Bitlylink(consentPendingLink);
				bitlyLink =bitlyurl.shortened_url ;
			}
			let 
			data = 
			{
				"TO" : recipientMobileData,
				"CUSTOMER_NAME" : req.commCustomerName, //we can pass multiple email at same time with comma separated
				"PAYMENT_STOP_REASON": '',
				"CLAIM_REJECT_REASON": '',
				"SUBJECT": row.subject ? row.subject : '',
				"CONSENT_PENDING_LINK": (bitlyLink) ? bitlyLink : "",
				"DOC_SUBMITTED_LINK": (bitlyLink) ? bitlyLink : "",
				"CLAIM_NUMBER": req.claimNumber,
				"CLAIM_APPROVED_AMOUNT": req.commClaimApprovedAmount ? req.commClaimApprovedAmount : "",
				"CUSTOMER_ACCOUNT_NO":req.account_no ? req.account_no : "",
			}
			
			response = await communicationService.createCommQueue({
				commid: "",
				caseid: req.commClaimId,
				roleid: (req.user && req.user.role_id) ? req.user.role_id : roleData.id,
				type: "sms",
				templateid: req.commTemplateId,
				data: data,
				bitly_url: bitlyLink,
				created: utils.getUTCDateTime()
			});
		}
	};

	async pushEmailTemplateCommQueue(req) {
		let consentPendingLink, bitlyLink, result, response, data = {};
		let recipientCCEmails = [];
		let recipientEmailData = [req.commCustomerEmailId];
		const roleData = await RoleService.getRole({ rolename: 'Customer' });

		result = await communicationService.getEmailTemplate({
			case_substatus_id: req.commSubStatusId,
			deleted:'0'
		});
		for(const row of result)
		{
			var templateId = row.id ? row.id : '';
			if (row.bitly_link_type == 'cp')
			{
				consentPendingLink = await claimService.getConsentPendingURL(req);
				bitlyLink = consentPendingLink;
			}
			let 
			data = 
			{
				"TO" : recipientEmailData,//we can pass multiple email at same time with comma separated
				"CC": recipientCCEmails,
				"SUBJECT": {
					"SUBJECT": row.subject ? row.subject : '',
					"CLAIM_NUMBER": req.claimNumber,
					"CUSTOMER_NAME": req.commCustomerName

				},
				"BODY": {
					"CLAIM_NUMBER": req.claimNumber,
					"CONSENT_PENDING_LINK": (consentPendingLink) ? consentPendingLink : "",
					"POLICY_NUMBER": req.commPolicyNo,
					"CUSTOMER_NAME": req.commCustomerName,
					"PAYMENT_MODE": "NEFT",
					"CLAIM_APPROVED_AMOUNT": req.commClaimApprovedAmount ? req.commClaimApprovedAmount : "",
					"PAYMENT_INSTALLMENT_AMOUNT": req.commPaymentInstallmentAmount ? req.commPaymentInstallmentAmount : "",
					"PAYMENT_REMAINING_COUNT": req.commPaymentCountRemaining ? req.commPaymentCountRemaining : "",
				}
			}
			response = await communicationService.createCommQueue({
				commid: "",
				caseid: req.commClaimId,
				roleid: (req.user && req.user.role_id) ? req.user.role_id : roleData.id,
				type: "email",
				templateid: templateId,
				data: data,
				bitly_url: bitlyLink,
				created: utils.getUTCDateTime()
			});
		}
	};

	async trigger(req, res) {
		try {
			const commQueueData = await communicationService.getAllCommQueueData({status: "open"});
			if(commQueueData.length > 0){
				for (const ele of commQueueData) {
					if(ele.type == 'email'){
						let response = await communicationService.emailTrigger(ele);
					}
					else if(ele.type == 'sms'){
						// sms code
						let response= await communicationService.smsTrigger(ele);
					}				
				}
				return res.status(httpStatus.OK).json({
					responseCode: httpStatus.OK,
					responseMessage: 'Send Successfully'
				});
			}
			return res.status(httpStatus.OK).json({
				responseCode: httpStatus.OK,
				responseMessage: 'Data is not available to process'
			});
		}
		catch (err) {
		  const errorMsg = err.errors ? err.errors[0].message : err.message;
		  return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
			status: "error",
			msg: errorMsg,
		  });
		}
	};
}


exports.communicationCtrl = new Communication();