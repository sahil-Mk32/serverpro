const httpStatus = require("http-status");
const userProfileRendering = require("../../uirender/userProfileRendering");
const userService = require("../../service/user/user.service");
const message = require("../../common/messages");
const utils = require("../../common/utils");
const {UserCreateFieldRender} = require('../../uirender/user.createuserfromrender');
const pickService = require("../../service/picklist/picklist.service"); 
const db = require("../../model");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");
const commonService = require("../../common/utils");

exports.getProfile = async (req, res) => {
  try {
    let getMainHeaderFields = await userService.getMainHeaderFields(req);
    if(getMainHeaderFields == 'unauthorized'){
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: 0,
          responseMessage: message.NOT_ACCESSIBLE,
          responseData :{}
        }) },
        { id: req.dataValues }
      );
      res.status(httpStatus.OK).json({
        responseCode: 0,
        responseMessage: message.NOT_ACCESSIBLE,
        responseData :{}
      });
     
    }
    else
    {
      let getUserProfileData = await userService.getUserProfileData({id_str:req.body.user_id});
      
      //request json decrypted
      //utils.getDecryptedJson(getUserProfileData);

      let getprofileDetailPageFields = await userService.getprofileDetailPageFields(getUserProfileData);
      let profileFormObj = {
        name: "user_details",
        title: "User Details",
        styles: userProfileRendering.profileFormStyle,
        groups: userProfileRendering.profileFormGroup(getprofileDetailPageFields),
        mainheader: userProfileRendering.profileMainHeader(getMainHeaderFields)
      }

      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: message.DETAILS_RETRIEVED,
          responseData: profileFormObj,
        }) },
        { id: req.dataValues }
      );

      res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: message.DETAILS_RETRIEVED,
        responseData: profileFormObj,
      });
    }
  } catch (err) {
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    console.log(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};


exports.getUserCreateFormRender = async(req,res) =>{
  try{
    getRoleListData = await pickService.getRoleList(); 
    getClientProgramData = await pickService.getClientProgramData();
    let keys = Object.keys(UserCreateFieldRender[0].fields);

    if(Object.keys(UserCreateFieldRender[0].fields[6]).includes("options")) 
    {
      UserCreateFieldRender[0].fields[6].options = getRoleListData;
    } 

    if(Object.keys(UserCreateFieldRender[0].fields[8]).includes("options")) 
    {
      UserCreateFieldRender[0].fields[8].options = getClientProgramData;
    } 

    let fieldObj = {};
    fieldObj["name"] = "user_details_config";
    fieldObj["title"] = "Users Details";
    fieldObj["groups"] = UserCreateFieldRender;
    fieldObj["actions"] = { "type": "button", "name": "action", "inputType": "button", "displayType": "default", "styles": [], "options": [{ "type": "button", "name": "update_privacy", "inputType": "button", "label": "Save", "icon": "", "disabled": false, "styles": { "color": "primary", "css": { "background": "#007ed2" } }, "callbacks": [{ "method": "update_user_data", "action": "api/user/create", "type": "submit", "fieldData": null }], "action": "submit" }] };
    return res.status(httpStatus.OK).json({
      responseCode: httpStatus.OK,
      responseMessage: 'User form Data',
      responseData : fieldObj
    });
    
  }catch(err){
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.errorMsg,
      msg: errorMsg,
    });
  }
}

exports.userCreationCallback = async(req,res) =>{
  try{

    const fieldname = req?.body?.fieldname;
    switch (fieldname) {
    case "username":
      response = await duplicateValueCallBackValidation(req, res);
        break;
    case "email":
      response = await duplicateValueCallBackValidation(req, res);
        break;
    default:
      response = {"responseCode": 200,
      "responseMessage": "",
      "responseData":[] }
        break;
    }
    return res.status(httpStatus.OK).json(response);

  }catch(err){
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
}

const duplicateValueCallBackValidation = async(req,res) =>{
  try{
      const { fieldname, fieldvalue, formdata } = req.body;
      if(formdata.id_str == null || formdata.id_str == ''){
        subQuery = "";
      }else{
        subQuery = "AND clm_user.id_str !='"+formdata.id_str+"'";
      }

      const userCount = await sequelize.query(
        `SELECT 
        count(clm_user.id) as 'total_count'
        FROM 
        clm_user
        WHERE
        clm_user.deleted = '0' AND `+fieldname+` = '`+fieldvalue+`'
        `+subQuery,
        {
            type: QueryTypes.SELECT,
        });
        if(userCount[0].total_count >0){
          response =  {
          "responseCode": 406,
          "responseMessage": fieldname+" Already Exist",
          "responseData":[{
              "fieldname": fieldname,
              "fieldtype": "input",
              "fieldvalue": ""
              }]
         };
        }else{
          response = {"responseCode": 200,
          "responseMessage": "",
          "responseData":[] }
        }
        return response;
  }catch(err){
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.errorMsg,
      msg: errorMsg,
    });
  }
}