const httpStatus = require("http-status");
const commonService = require("../../common/utils");
const paymentScheduleService = require("../../service/paymentSchedule/paymentSchedule.service");
const env = process.env.ENV.toUpperCase();
const { QueryTypes } = require("sequelize");
const db = require("../../model");
const message = require("../../common/messages");
const sequelize = db.sequelize;
const { Op } = require("sequelize");
const claimService = require("../../service/claim/claim.service");
const { openStatusSendMail, getSubstatusIdBystatusSubstatus } = require("../../service/common/common.service");
const { getClaimData } = require("../../service/claimView/claimView.service");
const { emailTemplate } = require("../../service/template/template.service");
const claimData = require("../claim/claimformrender.controller");
const templateService = require("../../service/template/template.service");
const communicationService = require("../../service/communication/communication.service");
const { communicationCtrl } = require("../../controllers/communication/communication.controller");

exports.claimClosed = async(req,res) => {
    let claimRowArray  = [];
    const getClaimDataReadyToClosed = await sequelize.query(
      `SELECT 
      * 
      FROM 
      clm_claim 
      WHERE
      clm_claim.status !='Claim Closed' 
      AND clm_claim.substatus IN ('Review Completed Insured Recovered','Payment Disbursed','Rejected')
      AND clm_claim.deleted ='0'`,
          {
              type: QueryTypes.SELECT,
          });

    for(const row of getClaimDataReadyToClosed){
      //update reserve amount
      await update_reserved_amount(row);      
        if(row.substatus == 'Rejected'){
            await setClaimClosedOnReject(req,row.id_str,row.id,row.claim_number);

        }else if(row.substatus == 'Review Completed Insured Recovered'){
            await setClaimClosedOnInsuredRecovered(req,row.id_str,row.claim_number,row.id);

        }else if(row.substatus == 'Payment Disbursed'){
            let withoutDisbursedPaymentCount = 0;
            withoutDisbursedPaymentCount = await checkAllPaymentDisbursed(row.claim_number);
            if(withoutDisbursedPaymentCount<=0){
                await setClaimClosedOnPaymentDisbursed(req,row.id_str,row.id,row.claim_number);
            }   
          }
    }
    
    return res.status(httpStatus.OK).json({
        responseCode: 200,
        responseMessage: "cron execute successfully",
        responseData: [],
      });
    
}

const setClaimClosedOnReject = async(req,claimIdStr,claimid,claim_number) =>{
    claimUpdate = {};
    claimUpdate['status'] = 'Claim Closed';
    claimUpdate['substatus'] = 'Rejected';
    claimUpdate['modified'] = commonService.getUTCDateTime(),
    claimUpdate['modified_by'] = '1';
    claimUpdate['assigned_to'] = '9';
    await claimService.updateClaimData(claimUpdate, {id_str: claimIdStr,});
    // sms service 
    await communicationCtrl.pushTemplateCommQueue({...req,claimNumber:claim_number});

    let statusHistoryData = {
        case_id: claimid,
        case_status_id: 6,
        case_substatus_id:42,
        case_status:'Claim Closed',
        case_substatus:'Rejected',
        assigned_to: 9,
        modified: commonService.getUTCDateTime(),
        modified_by: 1,
        source: 'WEB',
        remarks:'Claim Closed By CronJob'
    };

   
    await claimService.createStatusHistoryData(statusHistoryData);
}

const setClaimClosedOnInsuredRecovered = async(req,claimIdStr,claim_number,claimid,) =>{

    let updateData = {
        payment_status:"Payment Stop Due To Insured Recovered",
        modified: commonService.getUTCDateTime(),
        modified_by: 1
    };
    response = await paymentScheduleService.updatePayment(updateData, {claim_number});

    claimUpdate = {};
    claimUpdate['status'] = 'Claim Closed';
    claimUpdate['substatus'] = 'Payment Stopped';
    claimUpdate['modified'] = commonService.getUTCDateTime(),
    claimUpdate['modified_by'] = '1';
    claimUpdate['assigned_to'] = '9';
    await claimService.updateClaimData(claimUpdate, {id_str: claimIdStr,});

    //await createCommQueueForPayment(claim_number, 'Claim Closed', 'Payment Stopped');
    // sms service 
    await communicationCtrl.pushTemplateCommQueue({...req,claimNumber:claim_number});

    let statusHistoryData = {
        case_id: claimid,
        case_status_id: 6,
        case_substatus_id:43,
        case_status:'Claim Closed',
        case_substatus:'Payment Stopped',
        assigned_to: 9,
        modified: commonService.getUTCDateTime(),
        modified_by: 1,
        source: 'WEB',
        remarks:'Claim Closed By CronJob'
    };
    await claimService.createStatusHistoryData(statusHistoryData);
    //process.exit();
}

const setClaimClosedOnPaymentDisbursed = async(req,claimIdStr,claimid,claim_number,) =>{
    claimUpdate = {};
    claimUpdate['status'] = 'Claim Closed';
    claimUpdate['substatus'] = 'Payment Settled';
    claimUpdate['modified'] = commonService.getUTCDateTime(),
    claimUpdate['modified_by'] = '1';
    claimUpdate['assigned_to'] = '9';
    await claimService.updateClaimData(claimUpdate, {id_str: claimIdStr,});
    // sms service 
    await communicationCtrl.pushTemplateCommQueue({...req,claimNumber:claim_number});
    
    let statusHistoryData = {
      case_id: claimid,
      case_status_id: 6,
      case_substatus_id:41,
      case_status:'Claim Closed',
      case_substatus:'Payment Settled',
      assigned_to: 9,
      modified: commonService.getUTCDateTime(),
      modified_by: 1,
      source: 'WEB',
      remarks:'Claim Closed By CronJob'
    };
    

    await claimService.createStatusHistoryData(statusHistoryData);

    //await createCommQueueForPayment(claim_number, 'Claim Closed','Payment Settled' );

    
}

const checkAllPaymentDisbursed = async(claim_number) => {
    let getPaymentCountArray  = [];
    let paymentCount = 0;
    getPaymentCountArray = await sequelize.query(
      `SELECT 
      COUNT(id) AS payment_count
      FROM 
      clm_payment_schedule
      WHERE 
      claim_number = '`+claim_number+`' AND payment_status !='Payment Disbursed' AND deleted='0'`,
        {
            type: QueryTypes.SELECT,
        });
    paymentCount = getPaymentCountArray[0].payment_count;
    return paymentCount;
}
const PaymentDisbursedCount = async(claim_number) => {
  let getPaymentCountArray  = [];
  let paymentCount = 0;
  getPaymentCountArray = await sequelize.query(
    `SELECT 
    COUNT(id) AS payment_count,amount
    FROM 
    clm_payment_schedule
    WHERE 
    claim_number = '`+claim_number+`' AND payment_status ='Payment Disbursed' AND deleted='0'`,
      {
          type: QueryTypes.SELECT,
      });
  //paymentCount = getPaymentCountArray[0].payment_count;
  return getPaymentCountArray;
}

exports.sendMailOnOpenStatus = async () => {
  try {
    const commQueueData = await communicationService.getAllcommQueueData({
      status: "open",
    });

    for (const ele of commQueueData) {
      const mailData = await openStatusSendMail(ele);

      const communication = await communicationService.createCommunication({
        type: "email",
        pid: ele.caseid,
        subject: mailData.subject,
        body: mailData.body,
        to: ele.data.TO[0],
        cc: ele.data.CC[0],
        created: commonService.getUTCDateTime(),
        modified: commonService.getUTCDateTime(),
        status: "send",
        response: " ",
      });

      await communicationService.updatecommQueue(
        { commid: communication.dataValues.id, status: "processed" },
        { id: ele.id }
      );
    }
  } catch (err) {
    commonService.dumpError(err);
  }
};

const createCommQueueForPayment = async(claim_number, status, subStatus) => {
  const claimData = await getClaimData(claim_number)
  const claimTemplateDetails = await communicationService.claimTemplateDetail(claimData[0]);
  const substatusDetail = await getSubstatusIdBystatusSubstatus(
    status,
    subStatus
  );

  const templateData = await emailTemplate({
    case_substatus_id: substatusDetail,
  });

   const data = await communicationService.createCommQueue({
    commid: "",
    caseid: claimData[0].id,
    roleid: claimData[0].assigned_to,
    type: "email",
    templateid: templateData.id,
    data: claimTemplateDetails,
    bitly_url: "",
    created: commonService.getUTCDateTime(),
    modified: commonService.getUTCDateTime(),
    status: "open",
  });
}

exports.reminderMailSend = async (req, res) => {
  try {
    await claimData.reminderMail();
    return res.status(httpStatus.OK).json({
      responseCode: 200,
      responseMessage: message.CRON_EXECUTE_SUCCESSFULLY,
      responseData: [],
    });
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      responseCode: httpStatus.INTERNAL_SERVER_ERROR,
      responseMessage: errorMsg,
      responseData: {},
    });
  }
};

exports.mailOnOpenStatus = async (req, res) => {
  try {
    await this.sendMailOnOpenStatus();
    return res.status(httpStatus.OK).json({
      responseCode: 200,
      responseMessage: message.CRON_EXECUTE_SUCCESSFULLY,
      responseData: [],
    });
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      responseCode: httpStatus.INTERNAL_SERVER_ERROR,
      responseMessage: errorMsg,
      responseData: {},
    });
  }
};

const update_reserved_amount= async(row)=>{
    let postReq = {};
    let timestamp = Math.floor(Date.now()/1000);
    let DisbursedPaymentCount= await PaymentDisbursedCount(row.claim_number);
    if(DisbursedPaymentCount[0].payment_count>0){
      let amount=(DisbursedPaymentCount[0].payment_count)*DisbursedPaymentCount[0].amount;
      
      let headerToken = commonService.createExposeHeaderToken(timestamp,'CLAIM');
      let data={
        "policy_no":row.policy_no,
        "payment":amount,
        "paymentcount":DisbursedPaymentCount[0].payment_count
      };
      let baseUrl = process.env['BASE_URL_PHP_' + env];
      postReq["api_name"] = "updateReservedAmount";
      postReq["api_data_key"] = 100005;
      postReq["expose"] = "php";
      postReq["base_url"] = baseUrl;
      postReq["url"] = "/biometric_webapi/v1/update_reserved_amount.php";
      
      postReq["headers"] = {
        Authorization: headerToken,
        ContentType: 'application/json',
        Timestamp: timestamp
      };
      let apiConsumeRes = await commonService.postAPI(data, postReq);
    }
};