const httpStatus = require("http-status");
const utils = require("../../common/utils");
const env = process.env.ENV.toUpperCase();
const claimViewSer = require("../../service/claimView/claimView.service");
const claimService = require("../../service/claim/claim.service");
const message = require("../../common/messages");
const pickService = require("../../service/picklist/picklist.service");
const { getUser } = require("../../service/user/user.service");
const moment = require("moment");
const todayDate = moment().format("YYYY-MM-DD");



exports.claimViewApprovalHistoryCallBack = async(req,res) =>{
    try{
        const fieldname = req?.body?.fieldname;
        switch (fieldname) {
        case "substatus":
            responseData = await subStatusFieldCallBack(req, res);
            break;
        case "disability_type":
            responseData = await disabilityTypeFieldCallBack(req, res);
            break;
        case "is_date_disability_diff_by_csr":
            responseData = await disabilityDateDiffFieldCallBack(req, res);
            break;
        case "icd_code":
                responseData = await icdCodeFieldCallBack(req, res);
                break;
        default:
            responseData = "";
            break;
        }

        response = {"responseCode": 200,
        "responseMessage": "ClaimForm Json",
        "responseData":responseData }
        return res.status(httpStatus.OK).json(response);

    }catch{
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: message.ERROR,
        msg: errorMsg,
      });
    }
  }

  const subStatusFieldCallBack = async (req,res) =>{
    try
    {
        const { id, fieldvalue, formdata } = req.body;
        const decode = req.user;
        const roleid  = decode.role_id;

        let responseDataObj = {};
        let responseData = [
            {
                fieldname: "icd_code",
                fieldtype: "autocomplete",
                defaultvalue: "",
                fieldvalue: [],
                validations: [{ action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "payment_start_waiting_period_in_days",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "max_number_of_payment_as_per_plan",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "max_number_of_payment_availability",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "payment_frequency_in_days",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "reserved_amount",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "max_number_of_review_as_per_plan",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "review_frequency_in_days",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "payment_installment",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "number_of_payment",
                fieldtype: "select",
                defaultvalue: "",
                fieldvalue: [],
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "payment_start_date",
                fieldtype: "date",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            }
        ];

        if (fieldvalue == "Approved" && (formdata.status == "L1 Adjudication" || formdata.status == "L2 Adjudication") &&  roleid == '5') 
        {
            const getValue = await claimViewSer.getClaimData(id);
            const plan_name = getValue[0].plan_name;
            if(plan_name.toLowerCase().startsWith('tod')){
                getValueDisabilityType = [{key:"TD",value:"TD"}];
            }else{
                getValueDisabilityType = [{key:"TD",value:"TD"},{key:"PD",value:"PD"}];
            }

            responseDataObj = {
                    fieldname: "disability_type",
                    fieldtype: "select",
                    defaultvalue: "",
                    fieldvalue: getValueDisabilityType,
                    validations: [{ action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true}]
            }
        }
        else
        {
            responseDataObj = {
                fieldname: "disability_type",
                fieldtype: "select",
                defaultvalue: "",
                fieldvalue: [],
                validations: [{ action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            }
        }
        responseData.push(responseDataObj);
        return responseData;
    }catch(err){
        const errorMsg = err.errors ? err.errors[0].message : err.message;
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
          status: message.ERROR,
          msg: errorMsg,
        });
      }
  }

  /*const icdCodeFieldCallBack = async(req,res) =>{
    try{

        const { fieldvalue, formdata,id } = req.body;
        let claimData = await claimViewSer.getClaimColumnData(id);
        
        let picklistData = []
        if(fieldvalue.length >= 3)
        {
            picklistData = await pickService.getPickListIcdCodeAllData("icd_code",fieldvalue);
        }
        responseData = [
            {
                fieldname: "icd_code",
                fieldtype: "autocomplete",
                defaultvalue: "",
                fieldvalue: picklistData,
                validations: [{ action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true}]
            }]
        return responseData;

    }catch(err){
        const errorMsg = err.errors ? err.errors[0].message : err.message;
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
          status: message.ERROR,
          msg: errorMsg,
        });
    }
  }*/

  const icdCodeFieldCallBack = async(req,res) =>{
    try{
        const { fieldvalue, formdata,id } = req.body;
        picklistData = await pickService.getPickListSingleData("icd_code",fieldvalue);
        responseData = [
            {
                fieldname: "icd_code_description",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: picklistData[0].description,
                validations: [{ action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true}]
            }]
        return responseData;

    }catch(err){
        const errorMsg = err.errors ? err.errors[0].message : err.message;
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
          status: message.ERROR,
          msg: errorMsg,
        });
    }
  }

  const disabilityDateDiffFieldCallBack = async(req,res) =>{
    try{
        const {fieldvalue, formdata} = req.body;
        let indexValue = req.body.options.index;
        let mainData = req.body.options.mainData[indexValue];
        
        const getClaimDisabilitiesData = await claimService.getClaimDisabilitiesSingleRow({id: mainData.id});
        let date_disability_as_per_review = getClaimDisabilitiesData.doctor_confirmed_disability_date;
        let fieldData = (fieldvalue=='Yes')?'':date_disability_as_per_review;
        let disabled = (fieldvalue=='Yes')?false:true;
        responseData = [
            {
                fieldname: "date_disability_as_per_review",
                fieldtype: "date",
                defaultvalue: "",
                fieldvalue: fieldData,
                validations: [{action: "disabled",value: disabled},{action: "required",value: true},{action: "max",value: 0}]
            }]
        return responseData;

    }catch(err){
        const errorMsg = err.errors ? err.errors[0].message : err.message;
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
          status: message.ERROR,
          msg: errorMsg,
        });
    }
  }

  const disabilityTypeFieldCallBack = async (req,res) =>{
    try{
        
        const { fieldvalue, formdata,id } = req.body;
        let claimData = await claimViewSer.getClaimColumnData(id);
        let policyNo = claimData[0].policy_no;
        let disabilityType = fieldvalue;
        const getPolicyData = await policyDataBasedOnDisabilityType(policyNo,disabilityType);

        let responseDataObj = {};
        let responseData = [
            {
                fieldname: "icd_code",
                fieldtype: "autocomplete",
                defaultvalue: "",
                fieldvalue: await pickService.getPickListIcdCodeAllData("icd_code"),
                validations: [{ action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true}]
            },
            {
                fieldname: "payment_start_waiting_period_in_days",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getPolicyData[0].payment_start_waiting_period_in_days,
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: true}]
            },
            {
                fieldname: "max_number_of_payment_as_per_plan",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getPolicyData[0].max_number_of_payment_as_per_plan,
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: true}]
            },
            {
                fieldname: "max_number_of_payment_availability",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getPolicyData[0].max_number_of_payment_availability,
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: true}]
            },
            {
                fieldname: "payment_frequency_in_days",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getPolicyData[0].payment_frequency_in_days,
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: true}]
            },
            {
                fieldname: "max_number_of_review_as_per_plan",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getPolicyData[0].max_number_of_review_as_per_plan,
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: true}]
            },
            {
                fieldname: "reserved_amount",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getPolicyData[0].reserved_amount,
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: true}]
            },
            
            {
                fieldname: "review_frequency_in_days",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: JSON.stringify(getPolicyData[0].review_frequency_in_days),
                validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "payment_installment",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getPolicyData[0].payment_installment,
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: true}]
            },
            {
                fieldname: "number_of_payment",
                fieldtype: "select",
                defaultvalue: "",
                fieldvalue: getPolicyData[0].number_of_payment,
                validations: [{action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true}]
            },
            {
                fieldname: "payment_start_date",
                fieldtype: "date",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true},{action: "min",value:getPolicyData[0].payment_start_waiting_period_in_days}]
            }
        ];
        return responseData;

    }catch(err){
        const errorMsg = err.errors ? err.errors[0].message : err.message;
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
          status: message.ERROR,
          msg: errorMsg,
        });

    }
    
  }

const policyDataBasedOnDisabilityType = async(policyNo, disabilityType) =>{

    let postReq = {};
    timestamp = Math.floor(Date.now()/1000);
    let headerToken = utils.createExposeHeaderToken(timestamp,'CLAIM');

    let bodyData= {policy_no:policyNo,disability_type:disabilityType};
    let baseUrl = process.env['BASE_URL_PHP_' + env];
    postReq["api_name"] = "getMasterDataPaymentReview";
    postReq["api_data_key"] = 100002;
    postReq["expose"] = "php";
    postReq["base_url"] = baseUrl;
    postReq["url"] = "/biometric_webapi/v1/payment_review.php";
     
    postReq["headers"] = {
    Authorization: headerToken,
    ContentType: 'application/json',
    Timestamp: timestamp
    };
    
    let response = await utils.postAPI(bodyData, postReq);
    let salesData = response.salesData;
    /*
    salesData = [
    {
      payment_start_waiting_period_in_days: 30,
      max_number_of_payment_as_per_plan: 10,
      max_number_of_payment_availability: 10,
      payment_frequency_in_days: 30,
      max_number_of_review_as_per_plan: 9,
      reserved_amount: 99999,
      review_frequency_in_days: {"1": "20","2": "50","3": "80","4": "110","5": "140","6": "170","7": "200","8": "230","9": "260"}
    }
  ]
  */
 
  let number_of_payment = [];
  let max_number_of_payment_availability = salesData[0].max_number_of_payment_availability;
  let reserved_amount = salesData[0].reserved_amount;
  payment_installment =  Math.round(reserved_amount)/ max_number_of_payment_availability;
  for(i=1;i<=max_number_of_payment_availability;i++){
    number_of_payment.push({key:i,value:i});
  }
  salesData[0]['payment_installment'] = payment_installment;
  salesData[0]['number_of_payment'] = number_of_payment;
  return salesData;
}
