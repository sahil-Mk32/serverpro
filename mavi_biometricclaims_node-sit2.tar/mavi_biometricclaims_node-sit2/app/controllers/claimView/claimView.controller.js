const httpStatus = require("http-status");
const utils = require("../../common/utils");
const { communicationCtrl } = require("../../controllers/communication/communication.controller");
const moment = require("moment");
const commonService = require("../../common/utils");
const {
  getClaimViewSectionData,
  getSummaryFieldDataByFieldId,
  getClaimData,
  getModule,
  getModtrackerData,
  commentData,
  createClaimComments,
  trackClaimData,
  getClaimFormSectionData,
  getClaimFormSectionHeaderData,
  getApprovalHistoryList
} = require("../../service/claimView/claimView.service");

const claimService = require("../../service/claim/claim.service");
const message = require("../../common/messages");
const {
  claimViewStyle,
  claimViewRendering,
  claimViewRenderingassign_to,
  claimViewRenderingCreated_by,
  claimViewRenderingClaim_no,
  claimDetailsStyles,
  claimDetailsRendering,
  claimDetailsRenderingField,
} = require("../../uirender/claim_claimSummaryViewRendering");
const pickService = require("../../service/picklist/picklist.service");
const { headers, Historycolumns } = require("../../uirender/claim_updateHistory");
const { getUser } = require("../../service/user/user.service");

const {ApprovalHistoryListHeader} = require('../../uirender/approval_history_list.js');
const commonSer = require("../../service/common/common.service");
const paymentScheduleCtrl = require("../../controllers/paymentSchedule/paymentSchedule.controller");
const { emailTemplate } = require("../../service/template/template.service");
/*const { getModtrackerData,commentData,createClaimComments,trackClaimData} = require("../../service/claimView/claimView.service");*/

exports.claimSummaryDetails = async (req, res) => {
  try {
    const { id, module, method, section, request_type, mode, sectionid } =
      req.body;

    const getSummaryClaimViewSectionData = await getClaimViewSectionData(
      sectionid
    );

    let claimViewFormGroup = [];
    for (const element of getSummaryClaimViewSectionData) {
      let dataObj = {};
      dataObj["type"] = element.type;
      dataObj["title"] = element.title;
      dataObj["name"] = element?.name;
      dataObj["is_fields_hidden"] = false;
      dataObj["is_history_hidden"] = true;
      dataObj["is_history_enabled"] = false;
      dataObj["is_attachment_hidden"] = true;
      dataObj["is_attachment_enabled"] = false;
      dataObj["is_history_details_enabled"] = false;
      dataObj["history_action"] = "";
      dataObj["attachment_action"] = "";
      dataObj["displayType"] = section;
      dataObj["styles"] = claimViewStyle[0];
      dataObj["disabled"] = true;
      dataObj["hidden"] = element.hidden == 0 ? false : true;
      dataObj["hidetoggle"] = element.hidetoggle == 0 ? false : true;
      dataObj["expanded"] = true;
      claimViewFormGroup.push(dataObj);

      const getSummaryClaimViewDataByFieldId =
        await getSummaryFieldDataByFieldId(element?.fields);

      const getValue = await getClaimData(id);
      utils.getDecryptedJson(getValue[0]);

      if (getValue.length <= 0) {
        return res.status(httpStatus.BAD_REQUEST).json({
          success: false,
          message: message.INVALID_CLAIM,
        });
      }
      let fieldArray = [];
      for (const row of getSummaryClaimViewDataByFieldId) {
        let fieldObj = {};

        fieldObj["id"] = row.id ? row.id : "";
        fieldObj["type"] = row.type ? row.type : "";
        fieldObj["icon"] = row.icon ? row.icon : "";
        fieldObj["inputType"] = row.inputType ? row.inputType : "";
        fieldObj["name"] = row.name ? row.name : "";
        fieldObj["label"] = row.label ? row.label : "";
        fieldObj["required"] = row.required === 1 ? true : false;
        fieldObj["value"] = getValue[0][row.name] ? getValue[0][row.name] : " ";
        fieldObj["placeholder"] = row.placeholder ? row.placeholder : "";
        fieldObj["minlength"] = row.minimumlength === 0 ? 0 : "";
        fieldObj["maxlength"] =
          row.name.toLowerCase() === "icd_code"
            ? 15
            : row.maximumlength
            ? row.maximumlength
            : "";
        fieldObj["readonly"] = row.readonly === 1 ? true : false;
        fieldObj["disabled"] = true;
        fieldObj["hidden"] = row.hidden === 1 ? true : false;
        fieldObj["pattern"] = row.pattern == null ? null : ""; 
        fieldObj["validations"] = row.validations ? JSON.parse(row.validations) : "";
        fieldObj["styles"] = row.styles ?  JSON.parse(row.styles) : "";
        fieldObj["callbacks"] = row.callbacks ? JSON.parse(row.callbacks ): "";

        if (row.name == "disability" || row.name == "account_holder") {
          fieldObj["value"] = getValue[0].disability ? JSON.parse(getValue[0].disability) : " ", 
          fieldObj["options"] = await pickService.getPickListAllData(row.name);
        } 

        if (Object.keys(claimViewRendering[0]).includes(row.name)) {
          Object.assign(fieldObj, claimViewRendering[0][row.name]);
        }

        fieldArray.push(fieldObj);
      }
      let createdBy = claimViewRenderingCreated_by[0];
      const user = await getUser({ id: getValue[0].created_by });
      createdBy["value"] = user.first_name;
      let cliamNumber = claimViewRenderingClaim_no[0];
      cliamNumber["value"] = id;
      dataObj["fields"] = fieldArray;
      let assignedTo = claimViewRenderingassign_to[0];
      assignedTo["value"] = user.first_name;
      fieldArray.push(createdBy);
      fieldArray.push(cliamNumber);
      fieldArray.push(assignedTo)
    }

    let response = {
      responseCode: 200,
      responseMessage: "Form Json",
      responseData: {
        name: "complaint_form",
        title: "Create Complaint",
        styles: {
          id: "complaintForm",
          class: ["dynmaic-form"],
        },
        groups: claimViewFormGroup,
        sub_menus: "",
        actions: [],
      },
    };
    //update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues}
    );

    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.errors ? err.errors[0].message : err.message,
      }) },
      { id: req.dataValues}
    );
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.claimViewDetails = async (req, res) => {
  try {
    const { id, sectionid } = req.body;
    const sectionData = await getClaimViewSectionData(sectionid);
    let array = [];
    for (const ele of sectionData) {
      let newObj = {};
      
      newObj["type"] = "accordian";
      newObj["title"] = ele?.title ? ele?.title : "";
      newObj["name"] = ele?.name ? ele?.name : "";
      newObj["displayType"] = ele?.displayType ? ele?.displayType : "";
      newObj["styles"] = claimDetailsStyles;
      (newObj["disabled"] = false),
        (newObj["hidden"] = false),
        (newObj["hidetoggle"] = false),
        (newObj["expanded"] = true);
      if (Object.keys(claimDetailsRendering[0]).includes(ele.name)) {
        Object.assign(newObj, claimDetailsRendering[0][ele.name]);
      }
      
      if(ele.name != 'illness_&_injury_details') { 
        newObj["fields"] = ele?.fields
        ? await claimViewDetailsField(ele?.fields, id)
        : [];
      }
      else{ 
        newObj["fields"] = await getFormGroupFrmRender(ele.fields, id);
      }
      
      array.push(newObj);
    }

    let response = {
      responseCode: 200,
      reponseMessage: "Ok",
      responseData: {
        name: "claim_form",
        title: "Create Claim",
        styles: {
          id: "claimForm",
          class: ["dynmaic-form"],
        },
        groups: array,
      },
    };
    //update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues}
    );

    return res.status(200).json(response);
  } catch (err) {
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.errors ? err.errors[0].message : err.message,
      }) },
      { id: req.dataValues}
    );
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
    
  }
};

const claimViewDetailsField = async (fields, cliamId) => {
  try {

    const field = await getSummaryFieldDataByFieldId(fields);

    const getValue = await getClaimData(cliamId);
    //console.log(getValue);process.exit();
    utils.getDecryptedJson(getValue[0]);

    if (getValue.length <= 0) {
      throw new Error(message.CLAIM_NOT_FOUND)
    }

    let array = [];
    for (const ele of field) { 
      let obj = {
        id: ele?.id,
        type: ele?.type,
        icon: "",
        inputType: ele?.inputType,
        name: ele?.name,
        label: ele?.label,
        value: getValue[0][ele.name] ? getValue[0][ele.name] : " ",
        required: ele?.required == 1 ? true : false,
        placeholder: ele?.placeholder,
        minlength: ele?.minimumlength,
        maxlength: ele?.maximumlength,
        disabled: true,
        readonly: true,
        hidden: false,
        pattern: ele?.pattern,
        validations: JSON.parse(ele?.validations),
        styles: JSON.parse(ele?.styles),
        callbacks: JSON.parse(ele?.callbacks),
        options: JSON.parse(ele?.options),
      };
      if (ele.name == "disability") {
        //obj["value"] = getValue[0].disability ? JSON.parse(getValue[0].disability) : " ",    
        obj["options"] = await pickService.getPickListAllData(ele.name);
      }
      if (ele.name == "time_of_accident") {
        //obj["value"] = getValue[0].time_of_accident ? JSON.parse(getValue[0].time_of_accident) : " ",    
        obj["options"] = await pickService.getPickListAllData('time');
      } 
      if (ele.name == "account_holder") {
        //obj["value"] = getValue[0].account_holder ? getValue[0].account_holder : " ",    
        obj["options"] = await pickService.getPickListAllData(ele.name);
      } 
      if (
        ele.name == "job_related_injury" ||
        ele.name == "claim_against_other_party" ||
        ele.name == "same_account_details" ||
        ele.name == "have_you_suffered_previuos_illnes_or_injury" ||
        ele.name == "accident" ||
        ele.name == "illness"
      )
       {
        obj["value"] =
          getValue[0][ele.name] == 1
            ? getValue[0][ele.name] == true
            : false;
      }

      if (Object.keys(claimDetailsRenderingField[0]).includes(ele?.name)) {
        Object.assign(obj, claimDetailsRenderingField[0][ele?.name]);
      }
    array.push(obj);
  };
    //console.log(obj.name);process.exit();

    const indexOfSelectedAccountHolder = array.findIndex(
      (obj) => obj.name === "account_holder" && obj.value === "Insured’s Bank Details"
    );
    if (indexOfSelectedAccountHolder !== -1) {
      array = array.filter(
        (obj) =>
          obj.name !== "relation_with_insured" && obj.name !== "specify_relationship"
      );
    }
    const indexOfIllness = array.findIndex(
      (obj) => obj.name === "illness" && obj.value === true
    );
    if (indexOfIllness !== -1) {
      array = array.filter(
        (obj) =>
          obj.name !== "date_of_accident" && obj.name !== "time_of_accident" &&  obj.name !== "location_of_accident"
      );
    }

    const indexOfDisability = array.findIndex(
      (obj) => obj.name === "disability" && !obj.value.includes("Other")
    );
    if (indexOfDisability !== -1) {
      array = array.filter((obj) => obj.name !== "details_the_nature");
    }

    const indexOfAccident = array.findIndex(
      (obj) => obj.name === "accident" && obj.value === true
    );
    if (indexOfAccident !== -1) {
      array = array.filter((obj) => obj.name !== "date_symptoms_first_started");
    }

    // const indexOfPreviousIllness = array.findIndex(
    //   (obj) =>
    //     obj.name === "have_you_suffered_previuos_illnes_or_injury" &&
    //     obj.value === false
    // );
    // if (indexOfPreviousIllness !== -1) {
    //   array = array.filter((obj) => obj.name !== "specify");
    // }

    // const indexOfClaimAgainst = array.findIndex(
    //   (obj) => obj.name === "claim_against_other_party" && obj.value === false
    // );
    // if (indexOfClaimAgainst !== -1) {
    //   array = array.filter(
    //     (obj) =>
    //       obj.name !== "another_party_or_insurance_company_name" &&
    //       obj.name !== "description_of_claim" &&
    //       obj.name !== "claimed_amount"
    //   );
    // }

    const indexOfJobRelated = array.findIndex(
      (obj) => obj.name === "job_related_injury" && obj.value === false 
    );
    // if(indexOfJobRelated !== -1){
    //   const indexOfClaimedAmount = array.findIndex(
    //     (obj) => obj.name === "claim_against_other_party" && obj.value === true
    //   );
    //   if (indexOfClaimedAmount !== -1) {
    //     array = array.filter(
    //       (obj) =>
    //         obj.name !== "claimed_amount" 
    //     );
    //   }
    // }

    const indexOfSameAccount = array.findIndex(
      (obj) => obj.name === "same_account_details" && obj.value === true
    );
    if (indexOfSameAccount !== -1) {
      array = array.filter(
        (obj) =>
          obj.name !== "account_holder" && obj.name !== "name_of_next_of_kin" && obj.name !== "updt_mobile_no"
      );
    }

    const indexOfNoSameAccount = array.findIndex(
      (obj) => obj.name === "same_account_details" && obj.value === false
    );
    if (indexOfNoSameAccount !== -1){
      const indexOfInsuredBank = array.findIndex(
        (obj) => obj.name === "account_holder" && obj.value === 'Insured’s Bank Details'
      );
      if(indexOfInsuredBank !== -1){
        
        array = array.filter(
          (obj) =>
            obj.name !== "name_of_next_of_kin" && obj.name !== "updt_mobile_no"
        );
      }
    }

    return array;
  } catch (err) {
    throw err;
  }
};

exports.claimUpdateHistory = async (req, res) => {
  try {
    //const saveApiLog = await utils.createApiLogs(req);
    const { id, module, request_type } = req.body;
    let response = {
      responseCode: 200,
      responseMessage: "Json",
      responseData: null,
    };
    if (module == "claims" && request_type == "view") {
      const claimModuleId = await getClaimData(id);
      utils.getDecryptedJson(claimModuleId[0]);
      
      if (claimModuleId.length <= 0) {
        const response = utils.response(
          200,
          message.CLAIM_NOT_FOUND,
          null,
          message.ERROR
        );
        await commonService.updateLogsData(
          { status: 'Failed',
            error_type:'Failed'
          },
          { id:req.dataValues }
        );
  
        await utils.updateApiLogsData(
          { response: JSON.stringify(response) },
          { id: req.dataValues }
        );
        return res.status(httpStatus.OK).json(response);
      }
      
      const getTrackerData = await getModtrackerData(
        claimModuleId[0].id
      );
      let res = []
      getTrackerData.forEach((data) => {
        let fields = JSON.parse(data.field)
        const updateHistory = fields.filter(
          (ele) =>
            ele.field_name !== "id" &&
            ele.field_name !== "deleted" &&
            ele.field_name !== "Unique ID" &&
            ele.field_name !== "client_program_id" &&
            ele.field_name !== "source"
        );
        let update = []
        updateHistory.forEach((claimDetail) => {
          if(claimDetail.current_value == "0" || claimDetail.current_value == "1"){
            claimDetail.current_value = claimDetail.current_value == "0" ? false : true
          }else if(claimDetail.field_name == "Assign To" || claimDetail.field_name == "Modified By" || claimDetail.field_name == "Created By"){
            claimDetail.current_value = data.name
          }
          update.push(claimDetail)
        })
        data["field"] =  JSON.stringify(update)
        res.push(data)
      })
      // if (getTrackerData.length <= 0) {
      //   const response = utils.response(
      //     200,
      //     message.MODULE_NOT_FOUND,
      //     null,
      //     message.ERROR
      //   );
  
      //   await utils.updateApiLogsData(
      //     { response: JSON.stringify(response) },
      //     { id: saveApiLog.dataValues.id }
      //   );
      //   return res.status(httpStatus.OK).json(response);
      // }

      let claimViewFormGroup = [];

      res.forEach((element) => {
        let obj = {};
        let fieldDetailArray = [];
        let fieldObj = {};
        obj["act"] = element?.status === "m" ? "modified" : "created";
        obj["action_by"] = element?.name;
        obj["action_done_on"] = element?.changedone;
        (fieldObj["key"] = "history"),
          (fieldObj["label"] = ""),
          (fieldObj["value"] = {
            columns: Historycolumns,
            rows: JSON.parse(element.field),
          }),
          (fieldObj["type"] = "formarray");
        fieldDetailArray.push(fieldObj);
        obj["fielddetails"] = fieldDetailArray;
        claimViewFormGroup.push(obj);
      });

      response["responseData"] = {
        headers: headers,
        data: claimViewFormGroup,
        type: "table",
      };
    }
    // update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues}
    );
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.errors ? err.errors[0].message : err.message,
      }) },
      { id: req.dataValues}
    );
    utils.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.getClaimComments = async (req, res) => {
  try {
    //const saveApiLog = await utils.createApiLogs(req);
    const { id, module, request_type } = req.body;
    let response = {
      responseCode: "200",
      responseMessage: "Ok",
      responseData: null,
    };
    if (module == "claims" && request_type == "view") {
      const getComments = await commentData(id);
      // if (getComments.length <= 0) {
      //   const response = utils.response(
      //     200,
      //     message.COMMENT_NOT_FOUND,
      //     null,
      //     message.ERROR
      //   );
      //   await utils.updateApiLogsData(
      //     { response: JSON.stringify(response) },
      //     { id: saveApiLog.dataValues.id }
      //   );
      //   return res.status(httpStatus.OK).json(response);
      // }
      getComments.map((ele) => {
        const data = ele.username.replace(/_/g, ' ').replace(/(?:^|\s)\S/g, function(word){
          return word.toUpperCase()
        })
        ele["username"] = data
        return ele
      })
       response["responseData"] = { 
        commentData: getComments,   
      };
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await utils.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
    }
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await utils.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.errors ? err.errors[0].message : err.message,
      }) },
      { id: req.dataValues }
    );
    utils.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.createClaimComments = async (req, res) => {
  try {
    //const saveApiLog = await utils.createApiLogs(req);
    const { id, module, formdata} = req.body;
    const decode = req.user;
    const claimName = module === "claims" ? "Claims" : module;
    const moduleData = await getModule({ name: claimName });
    
    if (!moduleData) {
      const response = utils.response(
        200,
        message.MODULE_NOT_FOUND,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await utils.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.OK).json(response);
    }
    const claimData = await getClaimData(id);
    if (claimData.length <= 0) {
      const response = utils.response(
        200,
        message.CLAIM_NOT_FOUND,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await utils.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.OK).json(response);
    }
    const userData = await getUser({
      username: decode.username,
      id: decode.id,
    });

    if (!userData) {
      const response = utils.response(
        200,
        message.USER_NOT_FOUND,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await utils.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.OK).json(response);
    }

    await createClaimComments({
      module_id: moduleData.id,
      ref_id: claimData[0].id,
      comments: formdata.body,
      created: new Date(),
      modified: new Date(),
      created_by: userData.id,
      modified_by: userData.id,
    });

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DATA_SAVED,
    };
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await utils.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await utils.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg:err.errors ? err.errors[0].message : err.message,
      }) },
      { id: req.dataValues }
    );
    utils.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.trackClaim = async (req, res) => {
  try {
    //const saveApiLog = await utils.createApiLogs(req);
    const { id, module, request_type } = req.body;
    let response = {
      responseCode: 200,
      responseMessage: message.JSON,
      responseData: {
        title: "Tracking Status",
        type: "vertical_timeline",
        field: null,
      },
    };

    if (module == "claims" && request_type == "view") {
      const trackData = await trackClaimData(id);

      if (trackData <= 0) {
        const response = utils.response(
          200,
          message.STATUS_NOT_FOUND,
          null,
          message.ERROR
        );
        await commonService.updateLogsData(
          { status: 'Failed',
            error_type:'Failed'
          },
          { id:req.dataValues }
        );
        await utils.updateApiLogsData(
          { response: JSON.stringify(response) },
          { id: req.dataValues }
        );
        return res.status(httpStatus.OK).json(response);
      }

      const trackField = [];
      trackData.forEach((data, index) => {
        const trackStatus = {};
        (trackStatus["name"] = data.case_substatus
          .replace(/\s/g, "_")
          .toLowerCase()),
          (trackStatus["username"] = data.username.replace(/_/g, ' ').replace(/(?:^|\s)\S/g, function(word){
            return word.toUpperCase()
          })),
          (trackStatus["contents"] = data.track_claim),
          (trackStatus["type"] = "text"),
          (trackStatus["date"] = data.modified),
          (trackStatus["status"] =
            trackData.length - 1 === index ? "processing" : "approved");
        trackField.push(trackStatus);
      });

     
      response["responseData"].field = trackField;
    }
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await utils.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues}
    );
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await utils.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.errors ? err.errors[0].message : err.message,
      }) },
      { id: req.dataValues}
    );
    utils.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.claimViewDetail = async(req,res) =>{
  try{
    let getClaimFormTabData = await getClaimFormSectionData(req);
    let getClaimFormHeaderData = await getClaimFormSectionHeaderData(req);
    
    let isBitlyPermession = 0;
    const getValue = await getClaimData(req.body.id);
    const status = getValue[0].status;
    const substatus = getValue[0].substatus;
    const client_program_id = getValue[0].client_program_id;
    const role_id = req.user.role_id;
    
        
    isBitlyPermession = await commonSer.getResendBitlyPermession(status,substatus);
    isBitlyPermession = isBitlyPermession === 1 ? true : false;
    
    response = {"responseCode": 200,
    "responseMessage": "ClaimForm Json",
    "responseData": {
      "isResendBitlylinkButtonAvailable":isBitlyPermession,
      "name": "claim_detail_form",
      "title": "Claim Detail",
      "styles": {
        "id": "claimForm",
        "class": ["dynmaic-form"]
      },
      "groups":[],
      "tabs":getClaimFormTabData,
      "header":getClaimFormHeaderData
    },
      
    };
    //update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues}
    );

    return res.status(httpStatus.OK).json(response);
    
  }catch(err){
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.errors ? err.errors[0].message : err.message,
      }) },
      { id: req.dataValues}
    );
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.claimViewApprovalHistory = async(req,res) =>{
  try{    
      ApprovalHistoryListData = await getApprovalHistoryList(req);
      let fieldObj = {};
      
      //fieldObj["filters"] = [];
      //fieldObj["size"] = 10;
      //fieldObj["total"] = getClaimData[1];
      //fieldObj["styles"] = {};
      
      fieldObj["headers"] = ApprovalHistoryListHeader;
      fieldObj["data"] = ApprovalHistoryListData[0];
      fieldObj["page"] = req.body.page;
      fieldObj["per_page"] = 10;
      fieldObj["total"] = ApprovalHistoryListData[1];
      fieldObj["type"] = "table";

      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        responseCode: httpStatus.OK,
        responseMessage: 'Claim List Data',
        responseData : fieldObj
      }) },
      { id: req.dataValues}
    );

      return res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: 'Claim List Data',
        responseData : fieldObj
      });
  }catch(err){
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.errors ? err.errors[0].message : err.message,
      }) },
      { id: req.dataValues}
    );
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
}

exports.claimViewApprovalHistorySubmit = async(req,res) =>{
  try{
      const decode = req.user;
      const roleid  = decode.role_id;
      const userid = decode.id;
      const formdata = req.body.formdata;
      const claim_no = req.body.id;
      let claim_disability = formdata.claim_disability;
      const claimData = await getClaimData(claim_no);
      let clm_status = claimData[0].status;
      let claimid = claimData[0].id;
      let clm_substatus = claimData[0].substatus;
      let client_program_id = claimData[0].client_program_id;
      let clm_next_substatus = formdata.substatus;    
      
      const clm_next_status = await commonSer.getNextClaimPhase_ClaimStatus(roleid,clm_status,clm_substatus);
      const case_sub_status_id = await commonSer.getSubstatusIdBystatusSubstatus(clm_next_status,clm_next_substatus);
      const assignTo = await commonSer.getNextAssignTo(client_program_id,roleid,case_sub_status_id,"NA");
      const statusId = await commonSer.getStatusIdBystatus(clm_next_status);
    
      const statusHistoryData = {
        case_id: claimid,
        case_status_id: statusId,
        case_substatus_id:case_sub_status_id,
        case_status:clm_next_status,
        case_substatus:clm_next_substatus,
        assigned_to: assignTo,
        modified: new Date(),
        modified_by: userid,
        source: req.body.mode,
        remarks:formdata.remarks,
        claim_disabilities_data: JSON.stringify(claim_disability)
      };

      if(claimid && formdata.claim_disability){
        for(const ele of claim_disability){
          let disabilitiesUpdate = {
            icd_code: ele.icd_code,
            icd_code_description: ele.icd_code_description,
            is_date_disability_diff_by_csr: ele.is_date_disability_diff_by_csr,
            date_disability_as_per_review: ele.date_disability_as_per_review,
            modified: utils.getUTCDateTime(),
            modified_by: decode.id
          };
          await claimService.updateClaimDisabilitiesData(disabilitiesUpdate, {id: ele.id,case_id:claimid});
        }        
      }
      
      req.body.formdata.payment_start_date = moment(req.body.formdata.payment_start_date).format("YYYY-MM-DD");
      await claimService.createStatusHistoryData(statusHistoryData);
      delete formdata['id_str'];
      delete formdata['status'];
      delete formdata['substatus'];
      formdata['status'] = clm_next_status;
      formdata['substatus'] = clm_next_substatus;
      formdata['modified'] = new Date();
      formdata['modified_by'] = userid;
      formdata['assigned_to'] = assignTo;
      formdata['claim_approved_date'] = moment().utc().format("YYYY-MM-DD");

      await claimService.updateClaimData(formdata, {id_str: claimData[0].id_str});
     
      
      let payment_installment = req.body.formdata.payment_installment;
      let number_of_payment = req.body.formdata.number_of_payment;
      let claimApprovedAmount = payment_installment * number_of_payment;
      req = {...req,claimNumber:claim_no}
      // email trigger function
      
      await communicationCtrl.pushTemplateCommQueue({...req,claimNumber:claim_no,commClaimApprovedAmount:claimApprovedAmount});
      
      //start need to call api for payment schedule
      if (clm_next_status == 'L2 Adjudication' && clm_next_substatus == 'Approved' && roleid == 5) 
      {
          let new_body = {
            mode : 'WEB',
            //mode : req.body.mode,
            claim_no:req.body.id,
            payment_frequency_in_days : req.body.formdata.payment_frequency_in_days,
            payment_start_date:req.body.formdata.payment_start_date,
            no_of_payment_as_per_plan:number_of_payment,
            payment_installment,
            no_of_review_as_per_plan:req.body.formdata.max_number_of_review_as_per_plan,
            review_frequency_in_days:JSON.parse(req.body.formdata.review_frequency_in_days),
            claim_approved_date:formdata['claim_approved_date']
          }
          req.body =  new_body;          
          await paymentScheduleCtrl.paymentScheduleCreate(req, res);         
      }
      else
      {
        return res.status(httpStatus.OK).json({
          responseCode: httpStatus.OK,
          responseMessage: message.STATUS_UPDATED,
          responseData : []
        });
      }

      //end need to call api for payment schedule 

  }catch(err){
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
}

const getFormGroupFrmRender = async (sectionFieldIds, id) => {
  let newObj ={};
  let fieldData = {};
  let groupData  = [];

  newObj["type"] = 'formarray';
  newObj["inputType"] = '';
  newObj["displayType"] = '';
  newObj["icon"] = '';
  newObj["placeholder"] = '';
  newObj["title"] = 'Illness & Injury Details';
  newObj["name"] = 'illness_and_injury_details';
  newObj["label"] = 'Illness & Injury Details';
  newObj["styles"] = null;
  newObj["disabled"] = false;
  newObj["hidden"] = false;
  newObj["hidetoggle"] = false;
  newObj["expanded"] = true;
  newObj["callbacks"] = [];
  
  let actionsButton = '{"name":"action","type":"button","inputType":"button","displayType":"default","label":"","styles":{"appearance":""},"options":[],"callbacks":[]}';
  fieldData['fields'] = await claimViewDetailsField(sectionFieldIds, id);
  fieldData['actions'] = JSON.parse(actionsButton);
  
  //multiple disabilites
  const claimData = await claimService.getClaimData({claim_number: id});
  const getClaimDisabilitiesData = await claimService.getClaimDisabilitiesData({case_id: claimData.id});
  let dataRow = []
  for (const row of getClaimDisabilitiesData) {
    let fieldObj = {};
    fieldObj["id"] = row.id,
    fieldObj["illness"] = (row.illness==1)?true:false,
    fieldObj["accident"] = (row.accident==1)?true:false,
    fieldObj["disability"] = row.disability,
    fieldObj["date_symptoms_first_started"] = row.date_symptoms_first_started,
    fieldObj["date_of_accident"] = row.date_of_accident,
    fieldObj["time_of_accident"] = row.time_of_accident,
    fieldObj["location_of_accident"] = row.location_of_accident,
    fieldObj["doctor_confirmed_disability_date"] = row.doctor_confirmed_disability_date,
    fieldObj["details_the_nature"] = row.details_the_nature,
    fieldObj["have_you_suffered_previuos_illnes_or_injury"] = (row.have_you_suffered_previuos_illnes_or_injury==1)?true:false,
    fieldObj["specify"] = row.specify,
    fieldObj["date_of_first_consultation_of_injury_illness"] = row.date_of_first_consultation_of_injury_illness,
    fieldObj["date_of_noticed_symptoms_condition"] = row.date_of_noticed_symptoms_condition,
    fieldObj["job_related_injury"] = (row.job_related_injury==1)?true:false,
    fieldObj["claim_against_other_party"] = (row.claim_against_other_party==1)?true:false,
    fieldObj["another_party_or_insurance_company_name"] = row.another_party_or_insurance_company_name,
    fieldObj["claimed_amount"] = row.claimed_amount,
    fieldObj["description_of_claim"] = row.description_of_claim,
    dataRow.push(fieldObj);
  }
  newObj["formgroups"] = fieldData;
  newObj["fieldData"] = dataRow;
  groupData.push(newObj);
  return groupData;
}

