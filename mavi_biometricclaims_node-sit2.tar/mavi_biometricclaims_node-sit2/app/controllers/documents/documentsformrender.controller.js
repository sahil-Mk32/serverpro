const httpStatus = require("http-status");
const documentsService = require("../../service/documents/documents.service");
const { documentsFormRenderSections, documentFormRenderFields } = require("../../uirender/claim_documetsFormRendering");
const claimService = require("../../service/claim/claim.service");
const commonService = require("../../common/utils");

exports.documentsCreateFrmRender = async (req, res) => {
  try {
    let { sectionid } = req.body;
    let actionsButton = {};
    let isDeleteButtonVisible = false;
    /* let documentModule = await db.module.findOne({ 
      where: {
        columnWithFunction: sequelize.where(fn('LOWER', col('name')), '=', moduleName),
      }
    });
    if(!documentModule) {
      throw {
        message: 'Document module not found'
      }
    } */
    let claim = await claimService.getClaimData({
      claim_number: req.body.id,
    });
    if (commonService.isEmpty(claim)) {
      throw {
        message: `${req.body.id} claim no found`,
      };
    }
    if(claim.status == 'New Case Request' && claim.substatus == 'Document Pending'){
      actionsButton = '{"type": "button","name": "action","inputType": "button","displayType": "default","styles": {},"options": [{"type": "button","name": "button","inputType": "button","label": "Submit","icon": "","disabled": false ,"styles": {"color": "primary","css": {"background": "rgb(4, 171, 233)"}},"callbacks": [{"redirectURL": "claims/view","method": "document_upload","action": "api/documents/submit","type": "submit","fieldData": null}],"action": "submit"}]}';
      actionsButton = JSON.parse(actionsButton);
      isDeleteButtonVisible = true;
    }
    let documentSections = await documentsService.getDocumentsSectionData(sectionid); 
    let claimFormGroup  = [];
    for (let section of documentSections) {
      let newObj = {};
      newObj["type"] = section.type ? section.type : '';
      newObj["title"] = section.title ? section.title : '';
      newObj["name"] = section.name ? section.name : '';
      newObj["is_fields_hidden"] = section.is_fields_hidden ? section.is_fields_hidden : documentsFormRenderSections[section.name].is_fields_hidden;
      newObj["is_history_hidden"] = section.is_history_hidden ? section.is_history_hidden : documentsFormRenderSections[section.name].is_history_hidden;
      newObj["is_history_enabled"] = section.is_history_enabled ? section.is_history_enabled : documentsFormRenderSections[section.name].is_history_enabled;
      newObj["is_attachment_hidden"] = section.is_attachment_hidden ? section.is_attachment_hidden : documentsFormRenderSections[section.name].is_attachment_hidden;
      newObj["is_attachment_enabled"] = section.is_attachment_enabled ? section.is_attachment_enabled : documentsFormRenderSections[section.name].is_attachment_enabled;
      newObj["is_history_details_enabled"] = section.is_history_details_enabled ? section.is_history_details_enabled : documentsFormRenderSections[section.name].is_history_details_enabled;
      newObj["history_action"] = section.history_action ? section.history_action : documentsFormRenderSections[section.name].history_action;
      newObj["attachment_action"] = section.attachment_action ? section.attachment_action : documentsFormRenderSections[section.name].attachment_action;
      newObj["displayType"] = section.displayType ? section.displayType : '';
      newObj["styles"] = section.styles ? JSON.parse(section.styles) : null;
      newObj["disabled"] = section.disabled === 1 ? true : false;
      newObj["hidden"] = section.hidden === 1 ? true : false;
      newObj["hidetoggle"] = section.hidetoggle === 1 ? true : false;
      newObj["expanded"] = section.expanded === 1 ? true : false;
      newObj["fields"] = section.fields ? await getFieldDataBySectionFieldId(section.fields,isDeleteButtonVisible) : "";       
      claimFormGroup.push(newObj);
    }
    let claimFormStyle = '{"id": "complaintForm","class": ["dynmaic-form"]}';

    let claimCreateFormObj = {
      name: "complaint_form",
      title: "Create Complaint",
      styles: JSON.parse(claimFormStyle),
      groups: claimFormGroup,
      actions : actionsButton
    }
    // update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        responseCode: 200,
        responseMessage: "Form Json",
        responseData: claimCreateFormObj,
      }) },
      { id: req.dataValues }
    );

    res.status(200).json({
      responseCode: 200,
      responseMessage: "Form Json",
      responseData: claimCreateFormObj,
    });
  } catch (err) {
    console.log(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    // update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: "error",
        msg: errorMsg,
      }) },
      { id: req.dataValues }
    );

    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: "error",
      msg: errorMsg,
    });
  }
};

const getFieldDataBySectionFieldId = async (sectionFieldIds,isDeleteButtonVisible) => {
  try {
    let fieldData = [];
    if (sectionFieldIds) {
      let fields = await documentsService.getDocumentsFieldDataByFieldId(sectionFieldIds);
      for (let field of fields) {
        fieldName = field.get("name");
        let multiPermission = (fieldName == 'other_documents') ? true : false;
        fieldData.push({
          id: field.get("id") ? field.get("id") : "",
          name: fieldName ? fieldName : "",
          value: "",
          multiple: multiPermission,
          type: field.type ? field.type : "",
          isDeleteButtonVisible : isDeleteButtonVisible,
          label: field.get("label") ? field.get("label") : "",
          is_editable: field.is_editable ? field.is_editable : documentFormRenderFields[fieldName].is_editable,
          icon: field.icon ? field.icon : documentFormRenderFields[fieldName].icon,
          inputType: field.get("inputType") ? field.get("inputType") : documentFormRenderFields[fieldName].inputType,
          required: field.get("required") ? true : documentFormRenderFields[fieldName].required,
          placeholder: field.placeholder ? field.placeholder : documentFormRenderFields[fieldName].placeholder,
          hint: field.hint ? field.hint : documentFormRenderFields[fieldName].hint,
          minlength: field.minimumlength ? field.minimumlength : documentFormRenderFields[fieldName].minlength,
          maxlength: field.maximumlength ? field.maximumlength : documentFormRenderFields[fieldName].maxlength,
          readonly: field.readonly ? field.readonly : documentFormRenderFields[fieldName].readonly,
          disabled: field.disabled ? true : documentFormRenderFields[fieldName].disabled,
          hidden: field.hidden ? true : documentFormRenderFields[fieldName].hidden,
          pattern: field.pattern ? field.pattern : documentFormRenderFields[fieldName].pattern,
          validations: field.validations ? JSON.parse(field.validations) : documentFormRenderFields[fieldName].validations,
          styles: field.styles ? JSON.parse(field.styles) : documentFormRenderFields[fieldName].styles,
          callbacks: field.callbacks ? JSON.parse(field.callbacks) : documentFormRenderFields[fieldName].callbacks,
        });
      }
    }
    return fieldData;
  } catch(error) {
    throw error;
  }
};
