const httpStatus = require("http-status");
const commonService = require("../../common/utils");
const moduleService = require("../../service/module/module.service");
const utils = require("../../common/utils");
const FormData = require("form-data");
const env = process.env.ENV.toUpperCase();
const { BulkCronJobService } = require("../../service/bulkCronJob/bulkCronJob.service");
const { BulkTempDataImport } = require("../../service/bulkTempDataImport/bulkTempDataImport");
const { BulkUploadService } = require("../../service/bulkUpload/bulkUpload.service");
const paymentScheduleCtrl = require("../../controllers/paymentSchedule/paymentSchedule.controller");
const request = require('request')
const csv = require('csvtojson')
const bulkUploadResponseCode = require("../../common/bulkUploadResponseCodeTypes");
const { BulkUploadListHeader } = require("../../uirender/bulkUploadRendering");
const moment = require("moment");
const db = require("../../model");
const { Op } = require("sequelize");
class BulkUpload {
  constructor() {}

  paymentBulkUpload = async (req, res) => {
    try {

      if (commonService.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}
			if (req.body.data) {
				if (commonService.isEmpty(JSON.parse(req.body.data))) {
          
					throw {
						message: `Data can't be empty`,
					};
				}
				req.body = JSON.parse(req.body.data);
			} else {
        
				throw {
					message: `Data can't be empty`,
				};
			}
      if (commonService.isEmpty(req.files)) {
        
        throw {
          message: `File not uploded`,
        }
      }
      let extension = utils.getFileExtention(req.files[req.body.method].mimetype);
      if (!utils.getAllowedBulkFileExtentions().includes(extension)) {
        throw {
          message: `File with ${extension} extension is not allowed!`,
        }
      } 
      let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);
			if (commonService.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
			let { id: moduleId } = module;
      let file = req.files[req.body.method];
      let apiCallpayload = {
				base_url: process.env["BASE_URL_DS_" + env],
				url: "/api/document/upload",
				headers: { "Content-Type": "multipart/form-data" },
			};
			let data = {
				method: req.body.method,
				module: moduleId,
				application_id: process.env["DS_APPLICATION_ID_" + env],
				reference_id: req.body.id,
				user_id: 1,
			};
			let formData = new FormData();
			formData.append("data", JSON.stringify(data));
			formData.append("file", file.data, file.name);
			let response = await utils.postAPI(formData, apiCallpayload);
      
      if (response && !commonService.isEmpty(response.responseData)) {
        let cronjob = await this.createCronJob({fileId: response.responseData.id, moduleId, userId: req.user?.id});
        if (!commonService.isEmpty(cronjob)) {
          await this.processCronData({ filePath: response.responseData.path, cronJobId: cronjob.id });
        } 
      }
      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      res.status(httpStatus.OK).json(response);
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  createCronJob = async ({ fileId, moduleId, userId = 1 }) => {
    try {
      let data = {
        module_id: moduleId,
        file_id: fileId,
        created: utils.getUTCDateTime(),
        modified: utils.getUTCDateTime(),
        assigned_to: userId || 1,
        created_by: userId || 1, 
        modified_by: userId || 1,
      }
      return await BulkCronJobService.createBulkCronJob(data);
    } catch (err) {
      throw err;
    }
  }

  processCronData = async ({filePath, cronJobId}) => {
    try {
      let onError = (err) => {
        throw err;
      }
      let onComplete = async () => {
        let uploadRecordCount = await BulkTempDataImport.getBulkTempDataImportCoundBYJodId({job_id: cronJobId});
        await BulkCronJobService.updateBulkCronJob({total_records: uploadRecordCount},{id: cronJobId});
      }
      csv().fromStream(request.get(`${process.env["BASE_URL_DS_" + env]}/${filePath}`))
      .subscribe(async (bulkRecord) => {
          let data = {
            job_id: cronJobId,
            record_id: 0,
            data: JSON.stringify(bulkRecord),
            status: "open",
            created: utils.getUTCDateTime(),
            modified: utils.getUTCDateTime(),
          };
          await BulkTempDataImport.createBulkTempDataImport(data);
      }, onError, onComplete);
    } catch (error) {
      throw error;
    }
  }

  paymentBulkUpdateProcess = async (req, res) => {
    try {
      let module = await moduleService.getModuleByName("paymentschedule");
      await BulkCronJobService.resetProcessingStuckJobs({ module_id: module.id });
      let jobs = await BulkCronJobService.getCronJobList({ module_id: module.id, status: 'open' });
      for (let job of jobs) {
        let uploadedRecords = 0;
        let skippedRecords = 0;
        let errorRecords = 0;
        await BulkCronJobService.updateBulkCronJob(
          {cron_start_date: utils.getUTCDateTime(), modified: utils.getUTCDateTime(), status: 'processing'},
          {id: job.id},
        );
        let tempDataImports = await BulkTempDataImport.getBulkTempDataImportList({job_id: job.id});
        for (let tempDataImport of tempDataImports) {
          let body = JSON.parse(tempDataImport.data)
          if (!commonService.isEmpty(body)) {
            req.body = body;
            let response = await paymentScheduleCtrl.paymentBulkUpdate(req, res);
            if (response.responseCode == bulkUploadResponseCode.error_records) {
              errorRecords += 1;
            }
            if (response.responseCode == bulkUploadResponseCode.skipped_records) {
              skippedRecords += 1;
            }
            if (response.responseCode == bulkUploadResponseCode.uploaded_records) {
              uploadedRecords += 1;
            }
            await BulkTempDataImport.updateBulkTempImport(
              {status: response.responseCode, error: response.message, modified: utils.getUTCDateTime()},
              {id: tempDataImport.id},
            );
            
          }
        }    
        await BulkCronJobService.updateBulkCronJob(
          {
            cron_end_date: utils.getUTCDateTime(), 
            modified: utils.getUTCDateTime(), 
            status: 'completed', 
            uploaded_records: uploadedRecords, 
            skipped_records: skippedRecords,
            error_records: errorRecords,
          },
          {id: job.id},
        );
      }
      res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: 'Job finished',
        responseData: null
      });
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        responseCode: httpStatus.INTERNAL_SERVER_ERROR,
        responseMessage: errorMsg,
        responseData: {}
      });
    }
  }

  paymentBulkUploadFormat = async (req, res) => {
    try {
      if (commonService.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}
      let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);
			if (commonService.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
      //let format = await BulkUploadService.getPaymentBulkUploadFormat();
      let format = await BulkUploadService.getPaymentBulkUploadFormatWithData();
      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: 'Details fetched successfully',
          responseData: format
        }) },
        { id: req.dataValues }
      );
      res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: 'Details fetched successfully',
        responseData: format
      });
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  paymentBulkUploadList = async (req, res) => {
    try {
      if (commonService.isEmpty(req.body)) {
        
				throw {
					message: `Body can't be empty`,
				};
			}
      let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);
			if (commonService.isEmpty(module)) {
        
				throw {
					message: `${req.body.module} module not found`,
				};
			}
      let { id: moduleId } = module;
      let { start_date, end_date } = req.body;
      start_date = start_date || moment().subtract(10, 'days').format('YYYY-MM-DD');
      end_date = end_date || moment().format("YYYY-MM-DD");
      let rows = [];
      let paymentBulkUploadList = await BulkCronJobService.getCronJobList(
        {
          module_id: moduleId,
          columnWithFunction: db.sequelize.where(db.sequelize.fn('DATE_FORMAT', db.sequelize.col('clm_bulk_cron_job.created'), "%Y-%m-%d"), Op.between, [start_date, end_date]),
        }
      );
      for (let payment of paymentBulkUploadList) {
        rows.push({
          jobid: payment.id,
          total_records: payment.total_records,
          skipped_records: payment.skipped_records,
          error_records: payment.error_records,
          uploaded_records: payment.uploaded_records,
          uploaded_date: payment.created ? utils.getLocalDateTime(payment.created) : payment.created,
          job_status: payment.status,
          cron_start_date: payment.cron_start_date ? utils.getLocalDateTime(payment.cron_start_date) : payment.cron_start_date,
          cron_end_date: payment.cron_end_date ? utils.getLocalDateTime(payment.cron_end_date) : payment.cron_end_date,
          assignto: payment.assigned_to,
          action: true,
        });
      }
      let response = {
        filters: [],
        headers: BulkUploadListHeader,
        page: req.body.page || 1,
        per_page: req.body.size || 10,
        rows,
        styles: [],
        total: (await BulkCronJobService.getCronJobCount({ 
            module_id: moduleId,
            columnWithFunction: db.sequelize.where(db.sequelize.fn('DATE_FORMAT', db.sequelize.col('clm_bulk_cron_job.created'), "%Y-%m-%d"), Op.between, [start_date, end_date]),
          })
        ) || 0,
      };
      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: 'Data fetched successfully',
          responseData: response,
        }) },
        { id: req.dataValues }
      );
      res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: 'Data fetched successfully',
        responseData: response,
      });
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  paymentBulkUploadReport = async (req, res) => {
    try {
      if (commonService.isEmpty(req.body)) {
        
				throw {
					message: `Body can't be empty`,
				};
			}
			if (req.body.formdata) {
				if (commonService.isEmpty(req.body.formdata)) {

					throw {
						message: `Form data can't be empty`,
					};
				}
				req.body = req.body.formdata;
			} else {
        
				throw {
					message: `Form data can't be empty`,
				};
			}
      let cronJob = await BulkCronJobService.getCronJob({ id: req.body.jobid });
      if (commonService.isEmpty(cronJob)) {
        
        throw {
          message: `Job with ${req.body.jobid} not found`,
        }
      }
      let jobRecords = await BulkTempDataImport.getBulkTempDataImportList({job_id: cronJob.id});
      let response = [];
      for (let jobRecord of jobRecords) {
        response.push({
          ...JSON.parse(jobRecord.data),
          "Uploaded Status": jobRecord.status,
          "Response": jobRecord.error,
          "Uploaded Date": cronJob.cron_start_date ? utils.getLocalDateTime(cronJob.cron_start_date) : null,
          "Processed Date": cronJob.cron_end_date ? utils.getLocalDateTime(cronJob.cron_end_date) : null,
        })
      }
      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: 'Data fetched successfully',
          responseData: response,
        }) },
        { id: req.dataValues }
      );
      res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: 'Data fetched successfully',
        responseData: response,
      });
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }
}

exports.BulkUpload = new BulkUpload();

