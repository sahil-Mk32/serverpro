const express = require("express");
var cors = require("cors");
require("dotenv").config();
var bodyParser = require("body-parser");
require('dotenv').config();
// var multer = require("multer");
// var upload = multer();
const fileUpload = require('express-fileupload');
const app = express();
const cron = require('node-cron');
app.use(bodyParser.json());
app.use(express.json());
app.use(
  cors({
    origin: "*",
  })
);
app.use(express.urlencoded({ extended: true }));
// app.use(upload.array());
app.use(fileUpload());
app.use(express.static("public"));
const env = process.env.ENV.toUpperCase();

function setupRoute() {
  const routes = require("./app/router");
  routes.setup(app);
}
setupRoute();

app.listen(process.env["PORT_" + env], () => {
  console.log(
    `port running on port http://localhost:${process.env["PORT_" + env]}`
  );
});
