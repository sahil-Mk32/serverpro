import sys
sys.path.append('api/v1')
from main import app

if __name__ == "__main__":
    app.run(port=8086,host='0.0.0.0')