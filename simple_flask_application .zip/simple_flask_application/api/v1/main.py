
from flask_restful import reqparse, abort, Api, Resource
from flask_cors import CORS
from flask import Flask


app = Flask(__name__)
CORS(app)
app.config["DEBUG"] = True
api = Api(app)

parser = reqparse.RequestParser()

class index(Resource):
    def get(self):
        return "Health Check Ok"

api.add_resource(index, '/')

if __name__ == '__main__':
    app.run(debug=True,port=4001)
    app.run(host='0.0.0.0',threaded=True)