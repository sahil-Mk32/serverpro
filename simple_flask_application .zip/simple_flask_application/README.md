# mavi_biometricsales_python

This repository contains the implementation of mavi_biometricsales_python and the source code of application.

## Prerequisites  
- Python (required version) 
-  Git installed 
-  [Any other dependencies]

## Setup  
### 1. Create Virtual Environment 
Ensure Required Python Version is installed. 
If not, you can install it using your package manager: 
```
sudo apt install python3.X -y
```
Then, install the `python3.x-venv` package:
```
sudo apt install python3.x-venv -y
python3.x -m venv [virtual_environment_name] 
```
Activate the Virtual Environment 
```
source [virtual_environment_name]/bin/activate
```
### 2. Install Dependencies
Install the required dependencies using pip:
```
pip install -r requirements.txt
```
### 3. Add Server-side Packages (if any)
If there are additional server-side packages needed, install them using pip within the virtual environment:
```
pip install <package_name>
```
### 4. Gitignore Configuration
Ensure sensitive or unnecessary files related to server side are ignored by adding them to the `.gitignore` file. This prevents them from being tracked by Git and uploaded to the repository.

### 5. Serve the Application
	Run the application locally:
	```
	python <entry_point>.py
	```
The above way is running the application locally, Not recommended for the server side, Deploy the server side accordingly