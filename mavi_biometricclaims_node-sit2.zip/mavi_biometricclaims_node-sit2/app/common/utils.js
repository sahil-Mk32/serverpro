const { v4: uuidv4 } = require("uuid");
const bcrypt = require("bcrypt");
var jwt = require("jsonwebtoken");
const passwordValidator = require("password-validator");
const nodemailer = require("nodemailer");
var CryptoJS = require("crypto-js");
const env = process.env.ENV.toUpperCase();
const userService = require("../service/user/user.service");
const apiLogsService = require("../service/api/apiLog.service");
const moment = require("moment");
var fs = require("fs");
const message = require("../common/messages");
const hashingService = require("../common/hashing");
const axios = require("axios");
const crypto = require("crypto");
const _ = require("lodash");
const encryptedFileds = require('./encryptionField.json')

const hashPassword = (password) => {
  return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

const generateUserId = () => {
  return uuidv4();
};

const createOneTimeToken = (user, secretKey) => {
  return jwt.sign(
    {
      username: user?.username,
      first_name: user?.first_name,
      email: user?.email,
    },
    secretKey,
    {
      expiresIn: "8h", // hours
    }
  );
};

const decodeToken = (token) => {
  try {
    const decode = jwt.verify(token, process.env["JWT_SECRET_" + env]);
    return decode;
  } catch (err) {
    return null;
  }
};

const createToken = (user, secretKey) => {
  return jwt.sign(
    {
      id: user.id,
      id_str: user.id_str,
      username: user.username,
      first_name: user.first_name,
      email: user.email,
      mobile: user.mobile,
      role_id: user.role_id,
      is_admin: user.is_admin,
      time_zone: user.time_zone,
      repairer_id: user.repairer_id,
      repairer_user_id: user.repairer_user_id,
      vendor_code: user.vendor_code,
      gst_type: user.gst_type,
      web_access: user.web_access,
      mobile_access: user.mobile_access,
      login_token: user.login_token,
      clientprogram_code: user.client_code,
      user: user.user,
    },
    secretKey,
    {
      expiresIn: user.token_expiry ? user.token_expiry + "h" : "30d", // hours
    }
  );
};
const getX = (times) =>{
  let res = "X";
  for(let i=1;i<times;i++){
      res = res+"X";
  }
 return res;
}
const maskemailmobile= async (data,type)=>{
  data.toString();
   if(type=='sms'){
    let noOfx= getX(data.length-4);
    data=data.substring(0,2)+noOfx+data.substring(data.length-2);
  }
  else{
    let noOfx= getX(data.length-12);
    data=data.substring(0,3)+noOfx+data.substring(data.length-9);
  }
  return data;
}
const sendMail = async (to, subject, html) => {
  let mailTransporter = nodemailer.createTransport({
    host: process.env["MAIL_HOST_" + env],
    port: process.env["MAIL_PORT_" + env],
    secure: false,
    auth: {
      user: process.env["MAIL_USERNAME_" + env],
      pass: process.env["MAIL_PASSWORD_" + env],
    },
  });

  let mailDetails = {
    from: process.env["MAIL_FROM_MAIL_" + env],
    to,
    subject,
    html,
  };

  mailTransporter.sendMail(mailDetails, function (err, data) {
    if (err) {
      console.log("Error Occurs", err);
    } else {
      console.log("Email sent successfully");
    }
  });
};



const Bitlylink = async (url)=>{  
  try{
    const data = {
      "destination": url,
      "keyword": Math.random().toString(36).substring(1,7)
    };
    
    const options = {
      headers: {
          'Content-Type': 'application/json',
          "Authorization":process.env.TOKEN_BEARER
      }
    };  
    let response= await axios.post(process.env.API_ENDPOINT_SHORTNER_URL, data, options);
    return response.data;
  }
  catch(err){
    return err.message;
  }

};


const passowrdValidation = (decrypt) => {
  let pwd_error = [];

  return new Promise(async (resolve, reject) => {
    let schema = new passwordValidator();

    const filed = await userService.passwordCheck({ status: "1" });

    filed.forEach((element) => {
      if (element.option_column == "minLength") {
        schema.is().min(element.option_value);
      } else if (element.option_column == "maxLength") {
        schema.is().max(element.option_value);
      } else if (element.option_column == "uppercase") {
        schema.has().uppercase();
      } else if (element.option_column == "lowercase") {
        schema.has().lowercase();
      } else if (element.option_column == "digits") {
        schema.has().digits(Number(element.option_value));
      } else if (element.option_column == "spaces") {
        schema.has().not().spaces();
      } else if (element.option_column == "symbols") {
        schema.has().symbols();
      } else if (element.option_column == "oneOf") {
        schema.is().not().oneOf(JSON.parse(element.option_value));
      }
    });
    const pwd_response = schema.validate(decrypt, { list: true });

    if (pwd_response.length > 0) {
      pwd_response.forEach((value, index) => {
        value = value.charAt(0).toUpperCase() + value.slice(1);
        if (value === "Min") {
          pwd_error[index] = {
            key: value,
            value: message.MIN_VALUE,
          };
        } else if (value === "Max") {
          pwd_error[index] = {
            key: value,
            value: message.MAX_VALUE,
          };
        } else if (value === "Spaces") {
          pwd_error[index] = {
            key: value,
            value: message.SPACES,
          };
        } else if (value === "Symbols") {
          pwd_error[index] = {
            key: value,
            value: message.SYMBOLS,
          };
        } else if (value === "Digits") {
          pwd_error[index] = {
            key: value,
            value: message.DIGITS,
          };
        } else if (value === "Uppercase") {
          pwd_error[index] = {
            key: value,
            value: message.UPPERCASE,
          };
        } else if (value === "Lowercase") {
          pwd_error[index] = {
            key: value,
            value: message.LOWERCASE,
          };
        } else if (value === "OneOf") {
          pwd_error[index] = {
            key: value,
            value: message.ONEOF,
          };
        }
      });
    }
    return resolve(pwd_error);
  });
};

const generateOTP = () => {
  var minm = 100000;
  var maxm = 999999;
  return Math.floor(Math.random() * (maxm - minm + 1)) + minm;
};

const cryptoPasswordDecrypt = (password) => {
  let _key, _iv, decrypted;
  _key = CryptoJS.enc.Utf8.parse(process.env["UI_DECRYPT_KEY_" + env]);
  _iv = CryptoJS.enc.Utf8.parse(process.env["UI_DECRYPT_KEY_" + env]);
  decrypted = CryptoJS.AES.decrypt(password, _key, {
    keySize: 128 / 8,
    iv: _iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  return decrypted.toString(CryptoJS.enc.Utf8);
};

const createApiLogs = async (req) => {
  try {
    return await apiLogsService.apiLogData(req);
  } catch (err) {
    throw err;
  }
};

const updateApiLogsData = async (data, condition) => {
  try {
    await apiLogsService.updateApiLogs(data, condition);
  } catch (err) {
    throw err;
  }
};

const updateLogsData = async (data, condition) => {
  try {
    await apiLogsService.updateApiLogsData(data, condition);
  } catch (err) {
    throw err;
  }
};


let dumpError = async (err) => {
  let error, today;
  today = moment().format("YYYY-MM-DD");
  error = `LogDate=${moment().format("YYYY-MM-DD h:mm:SS A")} `;
  if (typeof err === "object") {
    error += `${err.status || 500} `;
    if (err.message) {
      error += err.message;
      console.log("\nMessage: " + err.message);
    }
    if (err.stack) {
      error += err.stack;
      console.log("\nStacktrace:");
      console.log(err.stack);
    }
  } else {
    error = "dumpError :: argument is not an object";
    console.log(error);
  }
  const errResponce = {
    responseCode: 0,
    responseMessage: message.EXCEPTION,
    responseData: `${error}`,
  };
  const file = err.name == "SequelizeDatabaseError" ? "dbError" : "apiError";
  fs.appendFileSync(
    `${process.env["LOG_ADDRESS_" + env]}${file}/${today}.txt`,
    `${JSON.stringify(errResponce)} \n`,
    function (err) {
      if (err) {
      }
      console.log("Data is appended to file successfully.");
    }
  );
};

const postAPI = async (req, post_req) => {
  let res_status, res_error_type, res_response, final_response, res;

  return new Promise((resolve, reject) => {
    axios({
      method: "post",
      baseURL: post_req.base_url,
      url: post_req.url,
      headers: post_req.headers,
      data: req,
      timeout: 0,
    })
      .then(async function (response) {
        res_response = response.data;
      })
      .catch(function (error) {
        if (error.response) {
          res_response = error.response.data;
        } else {
          res_response = error;
        }
      })
      .then(async function () {
        return resolve(res_response);
      });
  });
};

const createExposeHeaderToken = (timestamp,type) => {
  let string, secretkey, md5Value, cipher, username;
  username = process.env[`${type}_API_USERNAME_${env}`];
  secretkey = process.env[`${type}_SECRET_KEY_${env}`];
  string = `${secretkey}${timestamp}`;
  md5Value = crypto.createHash("md5").update(string).digest("hex");
  iv = crypto.createHash("sha256").update(md5Value).digest("hex").substr(0, 16);
  cipher = crypto.createCipheriv("AES-256-CBC", string, iv);
  return cipher.update(username, "utf8", "base64") + cipher.final("base64");
};

const masking = (string) => {
  return string.slice(0, 2) + string.slice(1).replace(/.(?=...)/g, "*");
};

const responseWithJsonBody = (res,statusCode , body) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  res.header('Access-Control-Allow-Credentials', true)
  res.status(statusCode).json(body);
  return res
}

const response = ( responseCode,responseMessage,responseData ,responseStatus ) => {
  return {
    responseCode,
    responseMessage,
    responseData,
    responseStatus
  }
}

const callBackDate = (date) => {
  return moment(date, "YYYY-MM-DD")
}

const calculateMinMaxDate = (date) => {
  let todayDate = moment(new moment(), "YYYY-MM-DD");
  date = moment(date, "YYYY-MM-DD");
  let minDateDiff = date.diff(todayDate,"days");
  let maxDateDiff = todayDate.diff(todayDate,"days");
  return [minDateDiff,maxDateDiff];
}


const isEmpty = (value) => {
  return _.isEmpty(value);
}

const getUploadDirPath = () => {
  return moment().format("YYYY/MMMM/DD");
}

const getAllowedBulkFileExtentions = () => {
  return ["csv"];
}

const getAllowedEncryptedFields = () => {
  return encryptedFileds;
}

const getEncryptedJson = (payload) => {
  for (let key in payload) {
    if(getAllowedEncryptedFields().includes(key)) {
      payload[key] = payload[key] ? hashingService.encrypt(payload[key]) : "";
    }
  }
  return payload;
}

const getDecryptedJson = (payload) => {
  for (let key in payload) {
    if(getAllowedEncryptedFields().includes(key)) {
      payload[key] = payload[key] ? hashingService.decrypt(payload[key]) : "";
    }
  }
  return payload;

}

const getReviewNotEditableStatus = () => {
  return ['Review Completed Insured Recovered','Review Completed Insured Still Disabled'];
}

const getFileExtention = (mimeType) => {
  let length = mimeType.split("/").length;
  return mimeType.split("/")[length - 1];
}

const getUTCDate = () => {
  return moment().utc().format("YYYY-MM-DD");
}

const getUTCDateTime = () => {
  return moment().utc().format("YYYY-MM-DD H:mm:ss");
}

const getLocalDateTime = (utcDateTime) => {
  return moment.utc(utcDateTime).local().format('YYYY-MM-DD HH:mm:ss') || utcDateTime;
}

const getLocalDateTimeDMY = (utcDateTime) => {
  return moment.utc(utcDateTime).local().format('DD MMM YYYY hh:mm A') || utcDateTime;
}

const getBitlyLinkFromURl = (biltyUrl) => {
  const options = {
    headers: {
        'Content-Type': 'application/json',
        "Authorization":process.env.TOKEN_BEARER
    }
  };
};

module.exports = {
  passowrdValidation,
  sendMail,
  generateUserId,
  hashPassword,
  createOneTimeToken,
  createToken,
  decodeToken,
  cryptoPasswordDecrypt,
  generateOTP,
  passowrdValidation,
  createApiLogs,
  updateApiLogsData,
  updateLogsData,
  dumpError,
  createExposeHeaderToken,
  postAPI,
  masking,
  responseWithJsonBody,
  isEmpty,
  response,
  callBackDate,
  calculateMinMaxDate,
  getUploadDirPath,
  getAllowedBulkFileExtentions,
  getAllowedEncryptedFields,
  getEncryptedJson,
  getDecryptedJson,
  getReviewNotEditableStatus,
  getFileExtention,
  getUTCDate,
  getUTCDateTime,
  getLocalDateTime,
  getLocalDateTimeDMY,
  getBitlyLinkFromURl,
  Bitlylink,
  maskemailmobile,
};
