let archieve_table=[
    "clm_api_log",
    "clm_otp_log",
    "clm_comm_queue",
    "clm_login_history"
];
module.exports=archieve_table;