module.exports = (sequelize, DataTypes) => {
  const claimsSubStatus = sequelize.define(
    "clm_claim_sub_status",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      pid: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      pname: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      customer_timeline: {
        type: DataTypes.STRING,
      },
      customer_text: {
        type: DataTypes.TEXT,
      },
      repairer_timeline: {
        type: DataTypes.STRING,
      },
      colour: {
        type: DataTypes.STRING,
      },
      sfdc_status: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.ENUM,
        values: ["0", "1"],
        defaultValue: "0",
        allowNull: false,
      },
      status: {
        type: DataTypes.ENUM,
        values: ["active", "inactive"],
        defaultValue: "active",
        allowNull: false,
      },
      sequence: {
        type: DataTypes.INTEGER,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return claimsSubStatus;
};
