module.exports = (sequelize, DataTypes) => {
  const claimStatusHistory = sequelize.define(
    "clm_claim_status_history",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      case_id: {
        type: DataTypes.INTEGER,
      },
      case_status_id: {
        type: DataTypes.INTEGER,
      },
      case_substatus_id: {
        type: DataTypes.INTEGER,
      },
      payment_review_no: {
        type: DataTypes.STRING,
      },
      case_status: {
        type: DataTypes.STRING,
      },
      payment_review_no: {
        type: DataTypes.STRING,
      },
      case_substatus: {
        type: DataTypes.STRING,
      },
      assigned_to: {
        type: DataTypes.INTEGER,
      },
      modified: {
        type: DataTypes.DATE,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      remarks: {
        type: DataTypes.TEXT,
      },
      claim_disabilities_data: {
        type: DataTypes.TEXT,
      },
      source: {
        type: DataTypes.STRING,
      },

    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return claimStatusHistory;
};

