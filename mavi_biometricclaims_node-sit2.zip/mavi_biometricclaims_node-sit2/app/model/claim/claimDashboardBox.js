module.exports = (sequelize, DataTypes) => {
  const clmDashboardBox = sequelize.define(
    "clm_dashboard_box",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        defaultValue: "0",
      },
      client_program_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      role_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      status_id: {
        type: DataTypes.INTEGER,
      },
      clm_status: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      substatus_id: {
        type: DataTypes.INTEGER,
      },
      clm_substatus: {
        type: DataTypes.STRING,
      },
      dashboard_box: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: "0",
        allowNull: false,
      },
      status: {
        type: DataTypes.ENUM,
        values: ["active", "inactive"],
        defaultValue: "active",
        allowNull: false,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return clmDashboardBox;
};
