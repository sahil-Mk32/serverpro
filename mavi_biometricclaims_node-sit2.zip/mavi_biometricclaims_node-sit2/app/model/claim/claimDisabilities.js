module.exports = (sequelize, DataTypes) => {
    const claims = sequelize.define(
      "clm_claim_disabilities",
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          allowNull: false,
          autoIncrement: true,
        },
        case_id: {
            type: DataTypes.INTEGER,
        },
        illness: {
            type: DataTypes.TINYINT(1),
        },
        accident: {
            type: DataTypes.TINYINT(1),
        },
        disability: {
            type: DataTypes.TEXT
        },
        icd_code: {
          type: DataTypes.STRING,
        },
        icd_code_description: {
          type: DataTypes.TEXT
        },
        is_date_disability_diff_by_csr: {
          type: DataTypes.ENUM,
          values: ["No", "Yes"],
          defaultValue: "No",
        },
        date_disability_as_per_review: {
          type: DataTypes.DATE,
        },
        date_symptoms_first_started: {
          type: DataTypes.DATE,
        },
        date_of_accident: {
          type: DataTypes.DATE,
        },
        time_of_accident: {
            type: DataTypes.TIME,
        },
        location_of_accident: {
            type: DataTypes.STRING,
        },
        doctor_confirmed_disability_date: {
          type: DataTypes.DATE,
        },
        details_the_nature: {
            type: DataTypes.TEXT,
        },
        have_you_suffered_previuos_illnes_or_injury: {
            type: DataTypes.TINYINT(1),
        },
        specify: {
            type: DataTypes.TEXT,
        },
        date_of_first_consultation_of_injury_illness: {
            type: DataTypes.DATE,
        },
        date_of_noticed_symptoms_condition: {
            type: DataTypes.DATE,
        },
        job_related_injury: {
            type: DataTypes.TINYINT(1),
        },
        claim_against_other_party: {
            type: DataTypes.TINYINT(1),
        },
        another_party_or_insurance_company_name: {
            type: DataTypes.STRING,
        },
        claimed_amount: {
          type: DataTypes.DECIMAL(15,2),
        },
        description_of_claim: {
            type: DataTypes.TEXT
        },
        created: {
          type: DataTypes.DATE,
          allowNull: false,
        },        
        modified: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        created_by: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        modified_by: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        deleted: {
          type: DataTypes.ENUM,
          values: ["0", "1"],
          defaultValue: "0",
        },
  
      },
      {
        freezeTableName: true,
        timestamps: false,
      }
    );
    return claims;
  };
  
