module.exports = (sequelize, DataTypes) => {
  const claimsStatus = sequelize.define(
    "clm_claim_status",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      created: {
        type: DataTypes.DATE,
      },
      modified: {
        type: DataTypes.DATE,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: "0",
      },
      status: {
        type: DataTypes.ENUM,
        values: ["active", "inactive"],
        defaultValue: "active",
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return claimsStatus;
};
