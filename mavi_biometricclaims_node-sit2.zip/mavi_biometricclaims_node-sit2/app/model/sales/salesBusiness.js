module.exports = (sequelize, DataTypes) => {
  const salesBusiness = sequelize.define(
    "clm_sales_business",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      business_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      business_id: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      business_code: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      business_theme_color1: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      business_category: {
        type: DataTypes.STRING,
      },
      business_status: {
        type: DataTypes.STRING,
      },
      business_theme_color2: {
        type: DataTypes.STRING,
      },
      business_description: {
        type: DataTypes.STRING,
      },
      business_icon: {
        type: DataTypes.STRING,
      },
      source: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return salesBusiness;
};
