module.exports = (sequelize, DataTypes) => {
  const salesProgram = sequelize.define(
    "clm_sales_program",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      program_code: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      program_description: {
        type: DataTypes.STRING,
      },
      program_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      program_status: {
        type: DataTypes.STRING,
      },
      program_type: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
      source: {
        type: DataTypes.STRING,
      },
      sum_insured_percentage: {
        type: DataTypes.STRING,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return salesProgram;
};
