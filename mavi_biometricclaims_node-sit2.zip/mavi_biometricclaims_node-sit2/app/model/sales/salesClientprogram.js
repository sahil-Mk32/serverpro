module.exports = (sequelize, DataTypes) => {
  const salesClientprogram = sequelize.define(
    "clm_sales_clientprogram",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      clientprogram_code: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      program_code: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      program_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      client_code: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      client_account_name: {
        type: DataTypes.STRING,
      },
      client_program_status: {
        type: DataTypes.STRING,
      },
      source: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return salesClientprogram;
};
