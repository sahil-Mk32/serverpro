module.exports = (sequelize, DataTypes) => {
    const bulkTempDataImport = sequelize.define(
      "clm_bulk_temp_data_import",
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          allowNull: false,
          autoIncrement: true,
        },
        record_id: {
          type: DataTypes.INTEGER,
          allowNull: true,
        },
        data: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        status: {
          type: DataTypes.ENUM("open", "completed", "processing", "aborted", "error"),
          allowNull: false,
          default: "open",
        },
        error: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        created: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        modified: {
          type: DataTypes.DATE,
          allowNull: false
        },
      },
      {
        freezeTableName: true,
        timestamps: false,
      },
    );
    return bulkTempDataImport;
  };