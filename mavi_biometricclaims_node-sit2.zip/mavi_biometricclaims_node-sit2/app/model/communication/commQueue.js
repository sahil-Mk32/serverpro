module.exports = (sequelize, DataTypes) => {
  const commQueue = sequelize.define(
    "clm_comm_queue",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      commid: {
        type: DataTypes.INTEGER,
      },
      caseid: {
        type: DataTypes.INTEGER,
      },
      roleid: {
        type: DataTypes.INTEGER,
      },
      type: {
        type: DataTypes.ENUM,
        values: ["email", "sms"],
      },
      templateid: {
        type: DataTypes.INTEGER,
      },
      data: {
        type: DataTypes.JSON,
      },
      bitly_url: {
        type: DataTypes.TEXT,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      status: {
        type: DataTypes.ENUM,
        values: ["open", "processed", "failed"],
        defaultValue: "open",
      },
      comm_queuecol: {
        type: DataTypes.STRING,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return commQueue;
};