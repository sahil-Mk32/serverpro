module.exports = (sequelize, DataTypes) => {
  const uiType = sequelize.define(
    "clm_uitype_master",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      uitype: {
        type: DataTypes.STRING(45),
        allowNull: true,
      },
      inputtype: {
        type: DataTypes.STRING(45),
        allowNull: false,
      },
      icon: {
        type: DataTypes.STRING(20),
        allowNull: false,
      },
      status: {
        type: DataTypes.ENUM("Active", "Inactive"),
        allowNull: true,
        default: "Active",
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return uiType;
};
