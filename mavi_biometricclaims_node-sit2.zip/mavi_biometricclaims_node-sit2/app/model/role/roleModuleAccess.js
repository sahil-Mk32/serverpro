module.exports = (sequelize, DataTypes) => {
  const roleModuleAccess = sequelize.define(
    "clm_role_module_access",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      client_program_id: {
        type: DataTypes.INTEGER,
      },
      module_id: {
        type: DataTypes.INTEGER,
      },
      role_id: {
        type: DataTypes.INTEGER,
      },
      module_access: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      read_access: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      write_access: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      delete_access: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      export_access: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      import_access: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      approval: {
        type: DataTypes.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return roleModuleAccess;
};
