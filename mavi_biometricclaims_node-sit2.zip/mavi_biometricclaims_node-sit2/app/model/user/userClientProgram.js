module.exports = (sequelize, DataTypes) => {
  const userClientProgram = sequelize.define(
    "clm_user_clientprogram",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      id_str: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      clientprogram_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return userClientProgram;
};
