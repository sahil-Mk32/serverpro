module.exports = (sequelize, DataTypes) => {
  const onetimeToken = sequelize.define(
    "clm_user_onetime_token",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      id_str: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      token: {
        type: DataTypes.STRING,
      },
      created: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      status: {
        type: DataTypes.ENUM,
        values: ["active", "inactive", "verified", "expired"],
        allowNull: false,
        defaultValue: "active",
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return onetimeToken;
};
