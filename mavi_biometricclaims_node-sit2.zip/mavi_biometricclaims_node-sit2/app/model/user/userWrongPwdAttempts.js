module.exports = (sequelize, DataTypes) => {
  const userWrongPwdAttempts = sequelize.define(
    "clm_user_wrong_pwd_attempts",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      uid: {
        type: DataTypes.INTEGER,
      },
      status: {
        type: DataTypes.TINYINT(1),
        defaultValue: "0",
      },
      attempt_date: {
        type: DataTypes.DATE,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return userWrongPwdAttempts;
};
