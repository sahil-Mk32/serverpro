module.exports = (sequelize, DataTypes) => {
  const emailTemplate = sequelize.define(
    "clm_email_template",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      case_substatus_id: {
        type: DataTypes.INTEGER,
      },
      programe_id: {
        type: DataTypes.INTEGER,
      },
      bitly_link_type: {
        type: DataTypes.ENUM,
        values: ["no", "cd", "cf", "cpl", "cdfl", "cdrd"],
        defaultValue: "no",
      },
      template_name: {
        type: DataTypes.STRING,
      },
      description: {
        type: DataTypes.STRING,
      },
      subject: {
        type: DataTypes.STRING,
      },
      body: {
        type: DataTypes.TEXT,
      },
      attachment: {
        type: DataTypes.STRING,
      },
      recipient: {
        type: DataTypes.ENUM,
        values: ["C", "R"],
        defaultValue: "C",
      },
      created: {
        type: DataTypes.DATE,
      },
      modified: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.ENUM,
        values: ["0", "1"],
        defaultValue: "0",
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return emailTemplate;
};
