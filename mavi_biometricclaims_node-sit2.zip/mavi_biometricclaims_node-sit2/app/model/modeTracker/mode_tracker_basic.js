module.exports = (sequelize, DataTypes) => {
    const modtrackerBasic= sequelize.define(
      "clm_modtracker_basic",
      {
        id: {
          type: DataTypes.BIGINT,
          primaryKey: true,
          allowNull: false,
          autoIncrement: true,
        },
        module_id: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        refid: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        whodid: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        changedone: {
            type: DataTypes.DATE,
            allowNull: false,
          },
        status: {
          type: DataTypes.ENUM,
          values: ["c", "m"],
          defaultValue: "c",
          allowNull: false,
        },
        source: {
          type: DataTypes.STRING,
        },
      },
      {
        freezeTableName: true,
        timestamps: false,
      }
    );
    return modtrackerBasic;
  };
  