module.exports = (sequelize, DataTypes) => {
    const modtrackerDetail= sequelize.define(
      "clm_modtracker_detail",
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          allowNull: false,
          autoIncrement: true,
        },
        basicid: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        fieldname: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        changedone: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        prevalue: {
          type: DataTypes.TEXT,
          allowNull: false,
        },
        postvalue: {
            type: DataTypes.TEXT,
            allowNull: false,
          },
      },
      {
        freezeTableName: true,
        timestamps: false,
      }
    );
    return modtrackerDetail;
  };
  