module.exports = (sequelize, DataTypes) => {
  const moduleApiRegister = sequelize.define(
    "clm_module_api_register",
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      module_id: {
        type: DataTypes.INTEGER,
      },
      method: {
        type: DataTypes.ENUM,
        values: ["post", "get", "put"],
        defaultValue: "post",
      },
      api: {
        type: DataTypes.STRING,
      },
      function: {
        type: DataTypes.STRING,
      },
      permission: {
        type: DataTypes.ENUM,
        values: [
          "read",
          "write",
          "export",
          "import",
          "approval",
          "delete",
          "batch",
          "python",
        ],
        defaultValue: "read",
      },
      status_write_permission: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: 1,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return moduleApiRegister;
};
