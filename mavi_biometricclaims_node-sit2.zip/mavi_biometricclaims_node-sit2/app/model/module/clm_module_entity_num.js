module.exports = (sequelize, DataTypes) => {
    const module_entity = sequelize.define(
      "clm_module_entity_num",
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          allowNull: false,
          autoIncrement: true,
        },
        module_id: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        module_name: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        prefix: {
            type: DataTypes.STRING,
            allowNull: false,
          },
        start_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        cur_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        created: {
          type: DataTypes.DATE,
          defaultValue: DataTypes.NOW,
        },
        modified: {
          type: DataTypes.DATE,
          defaultValue: DataTypes.NOW,
        },
        created_by: {
          type: DataTypes.INTEGER,
        },
        modified_by: {
          type: DataTypes.INTEGER,
        },
        deleted: {
          type: DataTypes.TINYINT(1),
          defaultValue: 0,
        },
      },
      {
        freezeTableName: true,
        timestamps: false,
      }
    );
    return module_entity;
  };
  