module.exports = (sequelize, DataTypes) => {
  const claimSection = sequelize.define(
    "clm_section",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true,
      },
      module_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      parent_section_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        default: 0,
      },
      action_link_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        default: 0,
      },
      type: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      title: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      content: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      name: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      displayType: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      styles: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      disabled: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        default: 0,
      },
      hidden: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        default: 0,
      },
      hidetoggle: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        default: 0,
      },
      expanded: {
        type: DataTypes.TINYINT(1),
        allowNull: true,
        default: 0,
      },
      sequence: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0,
      },
      is_custom: {
        type: DataTypes.ENUM("true", "false"),
        allowNull: true,
        default: "false",
      },
      fields: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      type_json: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      action_button_json: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      add_section_button: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      created: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      modified: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      created_by: {
        type: DataTypes.INTEGER,
      },
      modified_by: {
        type: DataTypes.INTEGER,
      },
      status: {
        type: DataTypes.ENUM("Active", "InActive"),
        allowNull: false,
        default: "Active",
      },
      deleted: {
        type: DataTypes.TINYINT(1),
        defaultValue: 0,
      },
      parent_field_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        default: 0,
      },
      callbacks: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
    },
    {
      freezeTableName: true,
      timestamps: false,
    }
  );
  return claimSection;
};
