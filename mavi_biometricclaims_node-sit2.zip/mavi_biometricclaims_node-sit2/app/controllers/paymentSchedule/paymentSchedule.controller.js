const httpStatus = require("http-status");
const commonService = require("../../common/utils");
const message = require("../../common/messages");
const moment = require("moment");
const claimService = require("../../service/claim/claim.service");
const moduleService = require("../../service/module/module.service");
const { PaymentListRenderHeaderData } = require('../../uirender/paymentListHeaderRendering.js');
const { PaymentTabData } = require('../../uirender/paymentTabRendering.js');
const paymentScheduleService = require("../../service/paymentSchedule/paymentSchedule.service");
const { ReviewScheduleCtrl } = require("../../controllers/reviewSchedule/reviewSchedule.controller");
const { RoleWiseStatusService } = require("../../service/roleWiseStatus/roleWIseStatus");
const { RoleService } = require("../../service/role/role");
const userService = require("../../service/user/user.service");
const bulkUploadResponseCode = require("../../common/bulkUploadResponseCodeTypes");
const utils = require("../../common/utils");
const commonService2 = require("../../service/common/common.service");
const { communicationCtrl } = require("../../controllers/communication/communication.controller");

// create paymentSchedule
exports.paymentScheduleCreate = async (req, res) => {
    try {

        const decode = req.user;
        let validStatus = 'L2 Adjudication';
        let validSubStatus = 'Approved';
        let validRoleId = '5';

        if (commonService.isEmpty(req.body)) {
            throw {
                message: `Body can't be empty`,
            };
        }

        for (let key in req.body) {
            if (req.body[key] == "" || req.body[key] == null) {
                throw {
                    message: `${key} can't be null or empty`,
                };
            }
        }

        let claim = await claimService.getClaimData({
            claim_number: req.body.claim_no,
        });

        if (commonService.isEmpty(claim)) {
            throw {
                message: `${req.body.claim_no} claim no found`,
            };
        }

        if (claim.status == validStatus && claim.substatus == validSubStatus && decode.role_id == validRoleId) {
            let noOfPayment = req.body.no_of_payment_as_per_plan;
            let payment_due = '1/' + noOfPayment;
            const currentTime = utils.getUTCDateTime();
            for (let i = 1; i <= noOfPayment; i++) {
                let interval = (i == 1) ? 0 : ((i - 1) * req.body.payment_frequency_in_days);
                var payment_due_date = moment(req.body.payment_start_date).add(interval, 'd');
                let payment_serial = i + '/' + noOfPayment;
                let insertData = {
                    payment_number: await claimService.moduleEntityNum({ module_name: "PaymentSchedule" }),
                    claim_number: req.body.claim_no,
                    amount: req.body.payment_installment,
                    payment_serial,
                    payment_due_date,
                    payment_status: 'Open',
                    source: "WEB",
                    created: currentTime,
                    created_by: decode.id
                };

                const response = await paymentScheduleService.createPayment(insertData);
                req.body = { ...req.body, payment_end_date: payment_due_date, payment_due: payment_due }
            }

            if (req.body.no_of_review_as_per_plan > 0) {
                const response = await ReviewScheduleCtrl.createReviewScheduleOne(req, res);
            }
            else {
                /* update claim */
                let assignToFlag = await commonService2.getNextPhase({ claimNumber: claim.claim_number, currentPhase: 'P' });
                let caseSubStatus = await claimService.getSubStatus({ pname: validStatus, name: validSubStatus });
                let assignTo = await commonService2.getNextAssignTo(claim.client_program_id, decode.role_id, caseSubStatus.id, assignToFlag);

                await claimService.updateClaimData(
                    { assigned_to: assignTo, payment_end_date: payment_due_date, payment_due },
                    { claim_number: claim.claim_number }
                );

                //update api log
                await commonService.updateLogsData(
                    {
                        status: 'Success',
                        error_type: 'Success'
                    },
                    { id: req.dataValues }
                );
                await commonService.updateApiLogsData(
                    {
                        response: JSON.stringify({
                            responseCode: httpStatus.OK,
                            responseMessage: message.DATA_SAVED,
                        })
                    },
                    { id: req.dataValues }
                );
                res.status(httpStatus.OK).json({
                    responseCode: httpStatus.OK,
                    responseMessage: message.DATA_SAVED,
                });
            }
        }
        else {
            //update api log
            await commonService.updateLogsData(
                {
                    status: 'Success',
                    error_type: 'Success'
                },
                { id: req.dataValues }
            );
            await commonService.updateApiLogsData(
                {
                    response: JSON.stringify({
                        responseCode: httpStatus.OK,
                        responseMessage: message.NOT_ACCESSIBLE,
                        responseData: {}
                    })
                },
                { id: req.dataValues }
            );

            return res.status(httpStatus.OK).json({
                responseCode: httpStatus.OK,
                responseMessage: message.NOT_ACCESSIBLE,
                responseData: {}
            });
        }
    }
    catch (err) {
        const errorMsg = err.errors ? err.errors[0].message : err.message;

        //update api log
        await commonService.updateLogsData(
            {
                status: 'Failed',
                error_type: 'Failed'
            },
            { id: req.dataValues }
        );
        await commonService.updateApiLogsData(
            {
                response: JSON.stringify({
                    responseCode: httpStatus.INTERNAL_SERVER_ERROR,
                    responseMessage: errorMsg,
                    responseData: {}
                })
            },
            { id: req.dataValues }
        );
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
            responseCode: httpStatus.INTERNAL_SERVER_ERROR,
            responseMessage: errorMsg,
            responseData: {}
        });
    }
};

// payment schedule list
exports.getpaymentScheduleList = async (req, res) => {
    try {
        const claim = await claimService.getClaimData({
            claim_number: req.body.id,
        });

        if (commonService.isEmpty(claim)) {
            throw {
                message: `${req.body.id} claim no found`,
            };
        }

        req.body.module = "PaymentSchedule";
        let module = await moduleService.getModuleByName(
            req.body.module.toLowerCase()
        );
        let { id: moduleId } = module;
        let getPaymentData = await paymentScheduleService.getPaymentList(req, claim, moduleId);

        let fieldObj = {};
        fieldObj["headers"] = PaymentListRenderHeaderData;
        fieldObj["rows"] = getPaymentData[0];
        fieldObj["page"] = req.body.page;
        fieldObj["size"] = 10;
        fieldObj["total"] = getPaymentData[1];

        //update api log
        await commonService.updateLogsData(
            {
                status: 'Success',
                error_type: 'Success'
            },
            { id: req.dataValues }
        );
        await commonService.updateApiLogsData(
            {
                response: JSON.stringify({
                    responseCode: httpStatus.OK,
                    responseMessage: 'Payment List Data',
                    responseData: fieldObj
                })
            },
            { id: req.dataValues }
        );

        return res.status(httpStatus.OK).json({
            responseCode: httpStatus.OK,
            responseMessage: 'Payment List Data',
            responseData: fieldObj
        });
    }
    catch (err) {
        const errorMsg = err.errors ? err.errors[0].message : err.message;

        //update api log
        await commonService.updateLogsData(
            {
                status: 'Failed',
                error_type: 'Failed'
            },
            { id: req.dataValues }
        );
        await commonService.updateApiLogsData(
            {
                response: JSON.stringify({
                    responseCode: httpStatus.INTERNAL_SERVER_ERROR,
                    responseMessage: errorMsg,
                    responseData: {}
                })
            },
            { id: req.dataValues }
        );
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
            responseCode: httpStatus.INTERNAL_SERVER_ERROR,
            responseMessage: errorMsg,
            responseData: {}
        });
    }
};

// payment schedule tab
exports.getpaymentScheduleTab = async (req, res) => {
    try {
        //update api log
        await commonService.updateLogsData(
            {
                status: 'Success',
                error_type: 'Success'
            },
            { id: req.dataValues }
        );
        await commonService.updateApiLogsData(
            {
                response: JSON.stringify({
                    responseCode: httpStatus.OK,
                    responseMessage: 'Payment Tab Data',
                    responseData: PaymentTabData
                })
            },
            { id: req.dataValues }
        );
        return res.status(httpStatus.OK).json({
            responseCode: httpStatus.OK,
            responseMessage: 'Payment Tab Data',
            responseData: PaymentTabData
        });
    }
    catch (err) {
        const errorMsg = err.errors ? err.errors[0].message : err.message;
        //update api log
        await commonService.updateLogsData(
            {
                status: 'Failed',
                error_type: 'Failed'
            },
            { id: req.dataValues }
        );
        await commonService.updateApiLogsData(
            {
                response: JSON.stringify({
                    responseCode: httpStatus.INTERNAL_SERVER_ERROR,
                    responseMessage: errorMsg,
                    responseData: {}
                })
            },
            { id: req.dataValues }
        );
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
            responseCode: httpStatus.INTERNAL_SERVER_ERROR,
            responseMessage: errorMsg,
            responseData: {}
        });
    }
};

// payment schedule list
exports.getpaymentScheduleDetail = async (req, res) => {
    try {
        //const saveApiLog = await commonService.createApiLogs(req);
        const { id, request_type, module } = req.body;
        let response = {
            responseCode: httpStatus.OK,
            responseMessage: message.DETAILS_RETRIEVED,
            responseData: null,
        };
        if (module == "paymentschedule" && request_type == "edit") {
            const data = await paymentScheduleService.getPaymentScheduleData({ payment_number: id, deleted: 0 });
            response["responseData"] = data;
        }
        await commonService.updateLogsData(
            {
                status: 'Success',
                error_type: 'Success'
            },
            { id: req.dataValues }
        );
        await commonService.updateApiLogsData(
            { response: JSON.stringify(response) },
            { id: req.dataValues }
        );
        return res.status(httpStatus.OK).json(response);
    }
    catch (err) {
        commonService.dumpError(err);
        const errorMsg = err.errors ? err.errors[0].message : err.message;
        //update api log
        await commonService.updateLogsData(
            {
                status: 'Failed',
                error_type: 'Failed'
            },
            { id: req.dataValues }
        );
        await commonService.updateApiLogsData(
            {
                response: JSON.stringify({
                    status: message.ERROR,
                    msg: errorMsg,
                })
            },
            { id: req.dataValues }
        );
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
            status: message.ERROR,
            msg: errorMsg,
        });
    }
};

// edit paymentSchedule
exports.paymentScheduleUpdate = async (req, res) => {
    try {
        const decode = req.user;
        let body, formdata, module, claim_number, payment_number, payment_status, remarks;

        body = req.body;
        formdata = req.body.formdata;

        claim_number = formdata.claim_number;
        payment_number = body.id;
        payment_status = formdata.payment_status;
        remarks = formdata.remarks;
        account_holder_name = formdata.account_holder_name;
        bank_account_number = formdata.bank_account_number;
        bank_branch_code = formdata.bank_branch_code;

        if (commonService.isEmpty(req.body)) {

            throw {
                message: `Body can't be empty`,
            };
        }

        module = await moduleService.getModuleByName(
            body.module.toLowerCase()
        );

        if (commonService.isEmpty(module)) {
            throw {
                message: `${body.module} module not found`,
            };
        }
        const claim = await claimService.getClaimData({ claim_number });

        if (body.module == 'paymentschedule' && body.method == 'paymentschedule_edit') {
            const payment = await paymentScheduleService.getPaymentScheduleData({
                claim_number, payment_number, deleted: 0
            });
            if (commonService.isEmpty(payment)) {

                throw {
                    message: `${body.id} payment no found`,
                };
            }
            if (payment.payment_status != 'Payment Disbursed') {
                let updateData = {
                    payment_date: formdata.payment_date,
                    utr_no: formdata.utr_no,
                    bank_name: formdata.bank_name,
                    remarks,
                    account_holder_name,
                    bank_account_number,
                    bank_branch_code,
                    payment_status,
                    source: "WEB",
                    modified: utils.getUTCDateTime(),
                    modified_by: decode.id
                };
                response = await paymentScheduleService.updatePayment(updateData, { payment_number, claim_number });
                /* update claim */
                let assignToFlag ;
                let nextStatus= await commonService2.getNextClaimPhase_ClaimStatus(decode.role_id, claim.status, claim.substatus);
                let nextSubStatusId = await commonService2.getSubstatusIdBystatusSubstatus(nextStatus, payment_status);
                if(nextSubStatusId==30){
                    assignToFlag = await commonService2.getNextPhase({claimNumber: claim.claim_number, currentPhase: 'P'});
                }
                else{
                    assignToFlag='NA';
                }
                let assignTo = await commonService2.getNextAssignTo(claim.client_program_id, decode.role_id, nextSubStatusId, assignToFlag);
                let caseSubStatus = await claimService.getSubStatus({ id: nextSubStatusId });

                let nextPaymentPart;
                let nextPaymentDue = await claimService.getOnePaymentInfo({id:await claimService.getNextPaymentDue(claim.claim_number,payment.id)});
                if(payment_status != 'Payment Disbursed'){
                    nextPaymentPart = payment.payment_serial
                }else{
                    nextPaymentPart = nextPaymentDue.payment_serial
                }
                await claimService.updateClaimData(
                    { status: caseSubStatus.pname, substatus: caseSubStatus.name, assigned_to: assignTo, payment_due: nextPaymentPart },
                    { claim_number: claim.claim_number }
                );
                // await claimService.updateClaimData(
                //     { status: caseSubStatus.pname, substatus: caseSubStatus.name, assigned_to: assignTo, payment_due: payment.payment_serial },
                //     { claim_number: claim.claim_number }
                // );
                await communicationCtrl.pushTemplateCommQueue({ ...req, claimNumber: claim_number });
                /* insert into claim status history */
                let historyData = {
                    case_id: claim.id,
                    case_status_id: caseSubStatus.pid,
                    case_substatus_id: caseSubStatus.id,
                    case_status: caseSubStatus.pname,
                    case_substatus: caseSubStatus.name,
                    payment_review_no: payment.payment_serial,
                    assigned_to: assignTo,
                    modified: utils.getUTCDateTime(),
                    modified_by: req.user.id || 1,
                    remarks,
                    source: req.source || "WEB",
                }
                await claimService.createStatusHistoryData(historyData);

                //update api log
                await commonService.updateLogsData(
                    {
                        status: 'Success',
                        error_type: 'Success'
                    },
                    { id: req.dataValues }
                );
                await commonService.updateApiLogsData(
                    {
                        response: JSON.stringify({
                            responseCode: httpStatus.OK,
                            responseMessage: message.DATA_SAVED,
                        })
                    },
                    { id: req.dataValues }
                );

                res.status(httpStatus.OK).json({
                    responseCode: httpStatus.OK,
                    responseMessage: message.DATA_SAVED,
                });
            }
            else {
                //update api log
                await commonService.updateLogsData(
                    {
                        status: 'Success',
                        error_type: 'Success'
                    },
                    { id: req.dataValues }
                );
                await commonService.updateApiLogsData(
                    {
                        response: JSON.stringify({
                            responseCode: httpStatus.OK,
                            responseMessage: message.NOT_ACCESSIBLE,
                            responseData: {}
                        })
                    },
                    { id: req.dataValues }
                );
                return res.status(httpStatus.OK).json({
                    responseCode: httpStatus.OK,
                    responseMessage: message.NOT_ACCESSIBLE,
                    responseData: {}
                });
            }
        }
        else {
            //update api log
            await commonService.updateLogsData(
                {
                    status: 'Success',
                    error_type: 'Success'
                },
                { id: req.dataValues }
            );
            await commonService.updateApiLogsData(
                {
                    response: JSON.stringify({
                        responseCode: httpStatus.OK,
                        responseMessage: message.NOT_ACCESSIBLE,
                        responseData: {}
                    })
                },
                { id: req.dataValues }
            );
            return res.status(httpStatus.OK).json({
                responseCode: httpStatus.OK,
                responseMessage: message.NOT_ACCESSIBLE,
                responseData: {}
            });
        }


    }
    catch (err) {
        const errorMsg = err.errors ? err.errors[0].message : err.message;

        //update api log
        await commonService.updateLogsData(
            {
                status: 'Failed',
                error_type: 'Failed'
            },
            { id: req.dataValues }
        );
        await commonService.updateApiLogsData(
            {
                response: JSON.stringify({
                    responseCode: httpStatus.INTERNAL_SERVER_ERROR,
                    responseMessage: errorMsg,
                    responseData: {}
                })
            },
            { id: req.dataValues }
        );
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
            responseCode: httpStatus.INTERNAL_SERVER_ERROR,
            responseMessage: errorMsg,
            responseData: {}
        });
    }
};

// bulk payment update
exports.paymentBulkUpdate = async (req, res) => {
    try {
        const claim = await claimService.getClaimData({ claim_number: req.body["Claim Number"] });
        if (commonService.isEmpty(claim)) {
            return {
                responseCode: bulkUploadResponseCode.error_records,
                message: `${req.body["Claim Number"]} claim not found.`,
            }
        }
        if (claim.assigned_to != 2) {
            return {
                responseCode: bulkUploadResponseCode.error_records,
                message: `Permission denied.`,
            }
        }
        //checking claim status that are allowed for payment
        if (claim.status != "Payment" && claim.status != "L2 Adjudication" && claim.status != "Review") {
            return {
                responseCode: bulkUploadResponseCode.error_records,
                message: `${claim.claim_number} is not in defined status.`,
            }
        }
        //checking claim substatus that are allowed for payment
        if (claim.substatus != "Bank verified" && claim.substatus != "Approved" && claim.substatus != "Payment Disbursed" && claim.substatus != "Review Completed Insured Still Disabled") {
            return {
                responseCode: bulkUploadResponseCode.error_records,
                message: `${claim.claim_number} is not in defined sub status.`,
            }
        }

        const payment = await paymentScheduleService.getPaymentScheduleData({ payment_number: req.body["Payment Number"] });
        //if single payment schedule is completed then return payment is already disbursement process
        // if (payment.payment_status == "completed") {
        //     return {
        //         responseCode:bulkUploadResponseCode.skipped_records,
        //         message: `${claim.claim_number} is already in payment disbursement status.`,
        //     }
        // }
        if (commonService.isEmpty(payment)) {
            return {
                responseCode: bulkUploadResponseCode.error_records,
                message: `${req.body["Payment Number"]} not found.`,
            }
        }
        if (parseFloat(req.body["Amount"]) != payment.amount) {
            return {
                responseCode: bulkUploadResponseCode.error_records,
                message: `Amount does not matches with the payment.`,
            }
        }
        
        if (payment.payment_serial != claim.payment_due) {
            return {
                responseCode: bulkUploadResponseCode.error_records,
                message: `${claim.claim_number} claim payment due does not matches.`,
            }
        }
        if (payment.payment_status == "Payment Disbursed") {
            return {
                responseCode: bulkUploadResponseCode.skipped_records,
                message: `${req.body["Payment Number"]} is already disbursed`,
            }
        }

        /* update payment */
        await paymentScheduleService.updatePayment(
            {
                utr_no: req.body["UTR Number"],
                bank_name: req.body["Bank Name"],
                account_holder_name: req.body["Account Holder Name"],
                bank_branch_code: req.body["Bank/Branch Code"],
                bank_account_number: req.body["Bank Account Number"],
                payment_status:"Payment Disbursed",
                payment_date: moment(req.body["Payment Date"], "DD-MM-YYYY").format("YYYY-MM-DD"),
                amount: req.body["Amount"],
                remarks: req.body["Remarks"]
            },
            {
                payment_number: payment.payment_number,
            }
        );
        /* update claim */
        let assignToFlag = await commonService2.getNextPhase({ claimNumber: claim.claim_number, currentPhase: 'P' });
        let financeRoleId = 2;
        let nextStatus = await commonService2.getNextClaimPhase_ClaimStatus(financeRoleId, claim.status, claim.substatus);
        let nextSubStatusId = await commonService2.getSubstatusIdBystatusSubstatus(nextStatus, "Payment Disbursed");
        let assignTo = await commonService2.getNextAssignTo(claim.client_program_id, financeRoleId, nextSubStatusId, assignToFlag);
        let caseSubStatus = await claimService.getSubStatus({ id: nextSubStatusId });
        let nextPaymentPart;
        let nextPaymentDue = await claimService.getOnePaymentInfo({id:await claimService.getNextPaymentDue(claim.claim_number,payment.id)});
        if(!nextPaymentDue){
            nextPaymentPart = payment.payment_serial
        }else{
            nextPaymentPart = nextPaymentDue.payment_serial
        }
        await claimService.updateClaimData(
            { status: caseSubStatus.pname, substatus: caseSubStatus.name, assigned_to: assignTo, payment_due: nextPaymentPart },
            { claim_number: claim.claim_number }
        );
        /* insert into claim status history */
        let historyData = {
            case_id: claim.id,
            case_status_id: caseSubStatus.pid,
            case_substatus_id: caseSubStatus.id,
            case_status: caseSubStatus.pname,
            case_substatus: caseSubStatus.name,
            payment_review_no: payment.payment_serial,
            assigned_to: assignTo,
            modified: utils.getUTCDateTime(),
            modified_by: 2,
            remarks: req.body["Remark"],
            source: req.source || "WEB",
        }
        await claimService.createStatusHistoryData(historyData);
        return {
            responseCode: bulkUploadResponseCode.uploaded_records,
            message: `${req.body["Payment Number"]} updated successfully`,
        }
    } catch (err) {
        throw err;
    }
}
