const httpStatus = require("http-status");
const utils = require("../../common/utils");
const pickService = require("../../service/picklist/picklist.service");
const commonService = require("../../common/utils");
const commonService2 = require("../../service/common/common.service");
const claimService = require("../../service/claim/claim.service");
const paymentScheduleService = require("../../service/paymentSchedule/paymentSchedule.service");
const { QueryTypes } = require("sequelize");
const db = require("../../model");
const message = require("../../common/messages");
const sequelize = db.sequelize;
const {
  getClaimData
} = require("../../service/claimView/claimView.service");

exports.paymentCreateFormRender = async (req, res) => {
    try {

      let { id, module, method, request_type } = req.body;

      const data = await paymentScheduleService.getPaymentScheduleData({ payment_number: id,deleted:0});

      if (commonService.isEmpty(data)) {

        throw {
            message: `${req.body.id} payment no found`,
        };
      }
      const claimDetail = await claimService.getClaimData({
        claim_number: data.claim_number,
      });


      if(method == "create_individual_paymentschedule" && (request_type == "edit" || request_type=='view') && module == "paymentschedule")
      {
          const getPaymentFormSectionData = await sequelize.query(
          `SELECT
          clm_section.type,
          clm_section.title ,
          clm_section.content ,
          clm_section.name ,
          clm_section.displayType ,
          clm_section.styles,
          clm_section.disabled ,
          clm_section.hidden,
          clm_section.hidetoggle,
          clm_section.expanded,
          clm_section.fields
          FROM
          clm_section
          INNER JOIN clm_module
          ON clm_module.id= clm_section.module_id
          WHERE LOWER(clm_module.module)='paymentschedule' and clm_section.type='section'`,
            {
                type: QueryTypes.SELECT,
            });

          let paymentFormGroup  = [];
          for(const row of getPaymentFormSectionData){
                let newObj = {};
                newObj["type"] = row.type ? row.type : '';
                newObj["title"] = row.title ? row.title : '';
                newObj["content"] = row.content ? row.content : false;
                newObj["name"] = row.name ? row.name : false;
                newObj["displayType"] = row.displayType ? row.displayType : false;
                newObj["styles"] = row.styles ? JSON.parse(row.styles) : null;
                newObj["disabled"] = row.disabled === 1 ? true : false;
                newObj["hidden"] = row.hidden === 1 ? true : false;
                newObj["hidetoggle"] = row.hidetoggle === 1 ? true : false;
                newObj["expanded"] = row.expanded === 1 ? true : false;
                newObj["fields"] = row.fields ? await getFieldDataBySectionFieldId(row.fields,req,claimDetail) : "";
                paymentFormGroup.push(newObj);

            }

        let actionsButton = '{"type": "button","name": "action","inputType": "button","displayType": "default","styles": {},"options": [{"type": "button","name": "button","inputType": "button","label": "Save","icon": "","disabled": false,"styles": {	"color": "primary","css": {"background": "rgb(4, 171, 233)"}},"callbacks": [{"redirectURL": "claims/view","method": "paymentschedule_edit","action": "api/paymentSchedule/update","type": "submit","fieldData": null}],"action": "submit"}]}';
        let paymentFormStyle = '{"id": "paymentForm","class": ["dynmaic-form"]}';

        let paymentCreateFormObj = {
        name: "payment_form",
        title: "Create Payment",
        styles: JSON.parse(paymentFormStyle),
        groups: paymentFormGroup,
        actions : JSON.parse(actionsButton)
        }

      const response = {
        responseCode: 200,
        responseMessage: "Form Json",
        responseData: paymentCreateFormObj,
      };
      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
        utils.responseWithJsonBody(res, 200 ,response )
      }
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  };

  const getFieldDataBySectionFieldId = async (sectionFieldIds,req=null,claimDetail=null) => {
  let fieldData  = [];
    const getFieldDataByFieldId = await sequelize.query(
      `SELECT
      clm_field.field_id AS id,
      clm_field.type ,
      clm_uitype_master.inputtype AS 'inputType' ,
      clm_field.fieldname AS 'name' ,
      clm_field.fieldlabel AS 'label' ,
      clm_field.mandatory AS 'required',
      clm_field.placeholder ,
      clm_field.minimumlength AS 'minlength',
      clm_field.maximumlength AS 'maxlength',
      clm_field.readonly,
      clm_field.helpinfo AS 'hint',
      clm_field.disabled,
      clm_field.hidden,
      clm_field.pattern,
      clm_field.validations,
      clm_field.styles,
      clm_field.callbacks,
      clm_field.options
      FROM
      clm_field
      INNER JOIN clm_uitype_master
      ON clm_uitype_master.id = clm_field.uitype
      WHERE clm_field.field_id IN(`+sectionFieldIds+`) ORDER BY sequence`,
          {
              type: QueryTypes.SELECT,
          });
         for(const row of getFieldDataByFieldId){
            let fieldObj = {};

            fieldObj["id"] = row.id ? row.id : '';
            fieldObj["type"] = row.type ? row.type : '';
            fieldObj["inputType"] = row.inputType ? row.inputType : '';
            fieldObj["name"] = row.name ? row.name : '';
            fieldObj["label"] = row.label ? row.label : '';
            fieldObj["required"] = row.required === 1 ? true : false;
            fieldObj["value"] = '';
            fieldObj["placeholder"] = row.placeholder ? row.placeholder : '';
            fieldObj["minlength"] = row.minlength ? row.minlength : 0;
            fieldObj["maxlength"] = row.maxlength ? row.maxlength : 0;
            fieldObj["readonly"] = row.readonly === 1 ? true : false;
            fieldObj["disabled"] = row.disabled === 1 ? true : false;
            fieldObj["hidden"] = row.hidden === 1 ? true : false;
            fieldObj["pattern"] = row.pattern ? row.pattern : null;
            fieldObj["hint"] = row.hint ? row.hint : '';
            fieldObj["validations"] = row.validations ? JSON.parse(row.validations) : null;
            fieldObj["styles"] = row.styles ? JSON.parse(row.styles) : null;
            fieldObj["callbacks"] = row.callbacks ? JSON.parse(row.callbacks) : false;

            if(row.name == 'payment_status')
            {
                //fieldObj["options"] = await pickService.getClaimSubStatusByCP(null, "AND pname = 'Payment'");
                const subStatusId = await commonService2.getSubstatusIdBystatusSubstatus(claimDetail.status,claimDetail.substatus);
                const pickList = await commonService2.getPickListDataByStatusAndSubStatus(req.user.role_id,subStatusId,claimDetail.client_program_id);
                fieldObj["options"] = pickList ? JSON.parse(pickList) : false;
              }
            else{
                fieldObj["options"] = row.options ? JSON.parse(row.options) : false;
            }

            fieldData.push(fieldObj);
        };
        return fieldData;
}

exports.callback = async (req, res) => {
  try{
    const fieldname = req?.body?.fieldname;
    switch (fieldname) {
    case "payment_status":
        responseData = await paymentStatusFieldCallBack(req, res);
        break;
    default:
        responseData = "";
        break;
    }

    response = {"responseCode": httpStatus.OK,
    "responseMessage": "PaymentScheduleForm Json",
    "responseData":responseData }

    //update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.OK).json(response);

} catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: "error",
        msg: errorMsg,
      }) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: "error",
      msg: errorMsg,
    });
  }
};

const paymentStatusFieldCallBack = async (req,res) =>{
  try
  {
      const { fieldvalue, formdata} = req.body;
      let responseDataObj = {};
      let responseData = [];
      
      const getValue = await getClaimData(formdata.claim_number);
      if(getValue) {
        utils.getDecryptedJson(getValue[0]);
      }
      
      if (fieldvalue.toLowerCase() == "payment disbursed")
      {
        responseData = [
            {
              fieldname: "payment_date",
              fieldtype: "date",
              defaultvalue: "",
              fieldvalue: "",
              validations: [{action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true},{action: "max",value: 0}]
            },
            {
                fieldname: "utr_no",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true}]
            },
            {
                fieldname: "bank_name",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getValue[0]['updt_bank_name'] ? getValue[0]['updt_bank_name'] : "",
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: false}]
            },
            {
                fieldname: "account_holder_name",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getValue[0]['account_holder_name'] ? getValue[0]['account_holder_name'] : "",
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: false}]
            }, {
                fieldname: "bank_account_number",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getValue[0]['updt_account_no'] ? getValue[0]['updt_account_no'] : "",
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: false}]
            }, {
                fieldname: "bank_branch_code",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: getValue[0]['updt_branch_code'] ? getValue[0]['updt_branch_code'] : "",
                validations: [{action: "hidden",value: false},{action: "disabled",value: true},{action: "required",value: false}]
            }, {
              fieldname: "upload_documents",
              fieldtype: "file",
              defaultvalue: "",
              fieldvalue: "",
              validations: [{action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: false}]
            }
        ];
      }
      else{
          responseData = [
            {
              fieldname: "payment_date",
              fieldtype: "date",
              defaultvalue: "",
              fieldvalue: "",
              validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false},{action: "max",value: 0}]
            },
            {
                fieldname: "utr_no",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false}]
            },
            {
                fieldname: "bank_name",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false}]
            },
            {
                fieldname: "account_holder_name",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false}]
            }, {
                fieldname: "bank_account_number",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false}]
            }, {
                fieldname: "bank_branch_code",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false}]
            }, {
              fieldname: "upload_documents",
              fieldtype: "file",
              defaultvalue: "",
              fieldvalue: "",
              validations: [{action: "hidden",value: true},{action: "disabled",value: true},{action: "required",value: false}]
            }
        ];
      }

      responseData.push(responseDataObj);
      return responseData;
  }catch(err){
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: message.ERROR,
        msg: errorMsg,
      });
    }
}
