const httpStatus = require("http-status");
const claimService = require("../../service/claim/claim.service");
const moment = require("moment");
const commonService = require("../../common/utils");
const {
  dashboardStatusColour,
  dashboardOnHold,
  ageBucket,
  pendingClaimDataColumn,
} = require("../../uirender/dashboard");
const message = require("../../common/messages");

exports.dashboard = async (req, res) => {
  try {
    const { filter } = req.body;
    let decode = req.user;
    let cpid_str=decode.id_str;
    let start_date_time = filter.start_date;
    let end_date_time = filter.end_date; 
    const start_date = moment(start_date_time, "YYYY-MM-DD").format("YYYY-MM-DD");
    const end_date = moment(end_date_time, "YYYY-MM-DD").format("YYYY-MM-DD");
    const claimData = await claimService.claimStatusCount(start_date, end_date,cpid_str);
    const statusData = await claimService.getDashboarBox();
    const statusResponse = [];

    statusData.forEach((element) => {
      let statusObj = {};
      statusObj["casestatus"] = element.dashboard_box;
      statusObj["count"] = 0;
      statusObj["colour"] = "";
      claimData.forEach((ele) => {
        if (statusObj["casestatus"] == ele.dashboard_box) {
          statusObj["count"] = ele.count;
        }
      });
      dashboardStatusColour.forEach((col) => {
        if (statusObj["casestatus"] == col.status) {
          statusObj["colour"] = col.colour;
        }
      });
      statusResponse.push(statusObj);
    });
    let response = {
      responseCode: httpStatus.OK,
      responseMessage: message.STATUS_SUCCESS_API,
      responseData: statusResponse,
    };
    // update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );

    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    // update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: "error",
        msg: errorMsg,
      }) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: "error",
      msg: errorMsg,
    });
  }
};

exports.pendingClaimBucket = async (req, res) => {
  try {
    let response = {
      responseCode: httpStatus.OK,
      responseMessage: message.JSON,
      responseData: null,
    };
    let decode = req.user;
    let cpid_str=decode.id_str;
    const pendingClaim = await claimService.pendingClaim(cpid_str);
    
    let responseArray = [];
    for (const data of pendingClaim) {
      data["total_claim"] = data.total_claim.toString();
      const roleClaimDetails = await claimService.roleClaimDetails(
        data.assign_to,cpid_str
      );
      const cliamDetailsArray = [];
      for (const ele of roleClaimDetails) {
        ele["tat"] = ele.tat.toString();
        cliamDetailsArray.push(ele);
      }
      let obj = {};
      let fielddetails = [
        {
          key: "estimation_history",
          label: "",
          value: {
            columns: pendingClaimDataColumn,
            rows:cliamDetailsArray,
          },
          type: "formarray"
        },
      ];
      delete data.assign_to;                          
      const pendingClaims = Object.assign(obj, data);
      pendingClaims["fielddetails"] = fielddetails;

      responseArray.push(pendingClaims);
    }

    response["responseData"] = {
      title: "PENDING CLAIM LIST",
      type: "table",
      headers: dashboardOnHold,
      data: responseArray,
      
    };
    // update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    // update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
	
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: "error",
        msg: errorMsg,
      }) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: "error",
      msg: errorMsg,
    });
  }
};

exports.dashboardAgeBucket = async (req, res) => {
  try {
    let decode = req.user;
    let cpid_str=decode.id_str;
    let response = {
      responseCode: httpStatus.OK,
      responseMessage: message.STATUS_SUCCESS_API,
      responseData: null,
    };

    response["responseData"] = {
      columns: ageBucket,
      rows: await claimService.dashboardAgeBucket(cpid_str),
    };
    // update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
	
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );

    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    // update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
	
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: "error",
        msg: errorMsg,
      }) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: "error",
      msg: errorMsg,
    });
  }
};
