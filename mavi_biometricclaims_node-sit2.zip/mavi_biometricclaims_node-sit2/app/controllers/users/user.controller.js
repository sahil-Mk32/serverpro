const httpStatus = require("http-status");
const commonService = require("../../common/utils");
const bcrypt = require("bcrypt");
const moment = require("moment");
const userService = require("../../service/user/user.service");
const otpService = require("../../service/otp/otp.service");
const tokenService = require("../../service/userOneTimeToken/token.service");
const emailTemplates = require("../../model/email/emailTemplate");
const templateService = require("../../service/template/template.service");
const env = process.env.ENV.toUpperCase();
const message = require("../../common/messages");
const utils = require("../../common/utils");
const pickService = require("../../service/picklist/picklist.service");
const { UserListRenderHeaderData } = require('../../uirender/user_userListRendering');
const communicationService = require("../../service/communication/communication.service");
const { Op } = require("sequelize");
const db = require("../../model");
const { QueryTypes } = require("sequelize");
const { use } = require("bcrypt/promises");
const sequelize = db.sequelize;

exports.resendUserOtp = async (req, res) => {
  try {
    const { token } = req.body;
    const tokenData = await tokenService.getOneTimeToken({
      token,
      status: "active",
    });

    if (!tokenData) {
      const response = commonService.response(
        0,
        message.INVALID_TOKEN,
        null,
        message.ERROR
      );

      //update api log
      await commonService.updateLogsData(
        {
          status: 'Failed',
          error_type: 'Failed'
        },
        { id: req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.OK).json(response);
    }
    id_str = tokenData.id_str;

    const user = await userService.getUser({ id_str });
    

    // update api log user id
    await commonService.updateLogsData(
      { user_id: JSON.stringify(user.id) },
      { id: req.dataValues }
    );


    const currentTime = moment().utc().format("YYYY-MM-DD H:mm:ss");

    const OldOtpExpire = await sequelize.query(
      `UPDATE clm_otp_log SET clm_otp_log.otp_status = "expire", clm_otp_log.modified = '` + currentTime + `'
       WHERE LOWER(clm_otp_log.record_type)='user' AND clm_otp_log.otp_status = 'send' 
       AND clm_otp_log.record_id = '`+ user.id + `'`,
      {
        type: QueryTypes.UPDATE,
      });

    const otp = commonService.generateOTP();
    const expireTime = moment().add(process.env["USER_LOGIN__OTP_EXPIRETIME_" + env], "hour").format("YYYY-MM-DD h:mm:ss");
    const emailData = await templateService.emailTemplate({ template_name: "OTP Generation", });
    await otpService.createOTP({
      record_id: user.id,
      templateid: emailData.id,
      record_type: "user",
      mobile: user.mobile,
      emailid: user.email,
      otp,
      expirytime: expireTime,
      created: new Date(),
      modified: new Date(),
    });

    let templateBody = emailData.body;
    const object = {
      USER_FIRSTNAME: user.first_name,
      OPT: otp,
    };

    for (const key in object) {
      templateBody = templateBody ? templateBody.replace(new RegExp(`{${key}}`, "g"), `${object[key]}`) : null;
    }
    if (templateBody) {
      await commonService.sendMail(user.email, "loginOTP", templateBody);
    }
    await userService.createUserCommunication("loginOTP", templateBody, user.email);

    const response = {
      token,
      otp,
      responseCode: httpStatus.OK,
      responseMessage: message.SUCCESS,
    };
    await commonService.updateLogsData(
      {
        status: 'Success',
        error_type: 'Success'
      },
      { id: req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );

    res.status(httpStatus.OK).json(response);


  }catch(err){
   // commonService.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log
    await commonService.updateLogsData(
      {
        status: 'Failed',
        error_type: 'Failed'
      },
      { id: req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: errorMsg,
      }) },
      { id: req.dataValues}
    );
    
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });

  }
}

exports.logIn = async (req, res) => {
  // create a row in api log table
  const saveApiLog = await commonService.createApiLogs(req);
  try {

    const { username, password } = req.body;
    await userService.loginHistoryData({
      username: req.body.username,
      user_ip: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
      login_time: new Date(),
      status: "LogIn",
      source: "web",
      user_agent: req.headers["user-agent"],
    });

    const user = await userService.getUser({ username });
    const last_attempt = utils.getUTCDateTime();
    let remaingingAttempt;
    if(user.wrong_attempt>=4 && moment(last_attempt).diff(user.last_attempt,'minutes') <1){
      const response = commonService.response(
        0,
        'Your account has been blocked.Please try after 1 minutes.',
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:saveApiLog.dataValues.id }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.OK).json(response);
    }
    if (!user) {
      const response = commonService.response(
        0,
        message.USER_NOT_FOUND,
        null,
        message.ERROR
      );
      //update api log
      await commonService.updateLogsData(
        {
          status: 'Failed',
          error_type: 'Failed'
        },
        { id: saveApiLog.dataValues.id }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.OK).json(response);
    }

    const decrypt = commonService.cryptoPasswordDecrypt(password);

    const isMatch = await bcrypt.compare(decrypt, user.password);

    if (!isMatch) {
      if(user.wrong_attempt==null){
        user.wrong_attempt=0;
      }
      let faileLogInAttempt = user.wrong_attempt+1;
      let remaingingAttempt = 5-faileLogInAttempt;
      
      await userService.updateUser(
        {wrong_attempt:faileLogInAttempt,
          last_attempt,
        },
        { id_str: user.id_str }
        );
      await userService.userWrongPwdAttemptsData({
        uid: user.id,
        attempt_date: new Date(),
        created: new Date(),
        modified: new Date()
      });
      const response = commonService.response(
        0,
        "Please enter correct Username and Password. Your account will be blocked after "+ remaingingAttempt +" attempt.",
        null,
        message.ERROR
      );
      //update api log status4

      await commonService.updateLogsData(
        {
          status: 'Failed',
          error_type: 'Failed'
        },
        { id: saveApiLog.dataValues.id }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.OK).json(response);
    }


    //after 45 days password change
    let currDate = moment();
    let passChangedPrevDate = moment(user.last_password_change);
    var daysDiff = currDate.diff(passChangedPrevDate, 'days')
    if(daysDiff>=45){
      const createToken = commonService.createToken(
        user,
        process.env["JWT_SECRET_" + env]
      );
      const response = commonService.response(
        0,
        message.PASSWORD_EXPIRED,
        {token:createToken},
        message.CHANGE_PASSWORD
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.OK).json(response);
    }

    // console.log("==moment date 1",currDate.utc().format());
    // console.log("==moment date 2",passChangedPrevDate.utc().format());
    // console.log("number of days",daysDiff);

    const token = commonService.generateUserId();
    await tokenService.saveToken({
      id_str: user.id_str,
      token,
      created: new Date(),
      modified: new Date(),
    });


    const otp = commonService.generateOTP();
    const currentTime = commonService.getUTCDateTime();
    const expireTime = moment(currentTime)
      .add(process.env["USER_LOGIN__OTP_EXPIRETIME_" + env], "hour")
      .format("YYYY-MM-DD h:mm:ss");

    const emailData = await templateService.emailTemplate({
      template_name: "OTP Generation",
    });
    const smsData = await templateService.smsTemplate({
      template_name: "Income Protection OTP",
    });

    await otpService.createOTP({
      record_id: user.id,
      templateid: emailData.id,
      record_type: "user",
      mobile: user.mobile,
      emailid: user.email,
      otp,
      expirytime: expireTime,
      created: currentTime,
      modified: currentTime,
    });

    let templateBody = emailData.body;
    let smsBody = smsData.template;

    const object = {
      USER_FIRSTNAME: user.first_name,
      OPT: otp,
    };
    for (const key in object) {
      templateBody = templateBody ? templateBody.replace(new RegExp(`{${key}}`, "g"), `${object[key]}`) : null;
      smsBody = smsBody ? smsBody.replace(new RegExp(`{${key}}`, "g"), `${object[key]}`) : null;

    }
    if (templateBody) {
      await communicationService.sendMail(user.email, "loginOTP", templateBody);
    }

    if (smsBody) {
      await communicationService.sendSms(user.mobile, smsBody, smsData.template_id);
    }
   
   const mobileNo= await commonService.maskemailmobile(user.mobile,'sms');
   const emailId= await commonService.maskemailmobile(user.email,'email');
    const response = {
      token,
      otp,
      responseCode: httpStatus.OK,
      responseMessage: message.SUCCESS,
      mobileNo,
      emailId

    };
    await userService.updateUser(
      {wrong_attempt:0,
        last_attempt
      },
      { id_str: user.id_str }
      );
    //update api log status4
    //let successStatus = 'Success'
    await commonService.updateLogsData(
      {
        status: 'Success',
        user_id: JSON.stringify(user.id),
        error_type: 'Success'
      },
      { id: saveApiLog.dataValues.id }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    req.user = user;
    res.status(httpStatus.OK).json(response);
  } catch (err) {
    //commonService.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      {
        status: 'Failed',
        error_type: 'Failed'
      },
      { id: saveApiLog.dataValues.id }
    );
    await commonService.updateApiLogsData(
      {
        response: JSON.stringify({
          status: message.ERROR,
          msg: err.errors ? err.errors[0].message : err.message,
        })
      },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.verifyOTP = async (req, res) => {
  try {
    const saveApiLog = await commonService.createApiLogs(req);

    const { otp, token } = req.body;

    const tokenData = await tokenService.getOneTimeToken({
      token,
      status: "active",
    });

    if (!tokenData) {
      const response = commonService.response(
        0,
        message.INVALID_TOKEN,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        {
          status: 'Failed',
          error_type: 'Failed'
        },
        { id: saveApiLog.dataValues.id }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }

    let user = await userService.getUser({
      id_str: tokenData.id_str,
    });
    const existingOTP = await otpService.getExistingOtp({
      otp: otp,
      record_id: user.id,
      mobile: user.mobile,
      otp_status: "send",
    });

    if (!existingOTP) {
      const response = commonService.response(
        0,
        message.INVALID_OTP,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        {
          status: 'Failed',
          error_type: 'Failed'
        },
        { id: saveApiLog.dataValues.id }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }

    const date = moment().format("YYYY-MM-DD h:mm:SS A");

    const expireTime = moment(existingOTP.expirytime).format(
      "YYYY-MM-DD h:mm:SS A"
    );
    if (date > expireTime) {
      await otpService.updateOtp({ otp_status: "expire" }, { id: existingOTP.id })
      return commonService.response(res, httpStatus.OK, 0, message.OTP_EXPIRE, message.ERROR);
    }

    await otpService.updateOtp(
      { otp_status: "verified" },
      { id: existingOTP.id }
    );

    const clientProgramCode = await userService.clientProgramCode(user.id_str);

    user["client_code"] = clientProgramCode[0].client_code;
    user["login_token"] = commonService.generateUserId();

    await userService.updateUser(
      { login_token: user["login_token"] },
      { id_str: user.id_str }
    );

    await tokenService.updateOneTimeToken(
      { status: "verified" },
      { id: tokenData.id }
    );

    const getMenuData = await userService.menuData(user?.id);

    let menuStructure = {};

    getMenuData.forEach((element) => {
      let newObj = {};
      newObj["module"] = element.module_access === 1 ? true : false;
      newObj["view"] = element.read_access === 1 ? true : false;
      newObj["create"] = element.write_access === 1 ? true : false;
      newObj["edit"] = element.write_access === 1 ? true : false;
      newObj["delete"] = element.delete_access === 1 ? true : false;
      newObj["import"] = element.import_access === 1 ? true : false;

      menuStructure[element.name] = newObj;
    });

    let userObj = {
      first_name: user?.first_name ? user?.first_name : null,
      middle_name: user?.middle_name ? user?.middle_name : null,
      last_name: user?.last_name ? user?.last_name : null,
      menu_structure: menuStructure,
    };

    user["user"] = userObj;
    const createToken = commonService.createToken(
      user,
      process.env["JWT_SECRET_" + env]
    );

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.USER_SUCCESS_LOGIN,
      createToken,
    };
    //update api log 
    await commonService.updateLogsData(
      {
        status: 'Success',
        user_id: JSON.stringify(user.id),
        error_type: 'Success'
      },
      { id: saveApiLog.dataValues.id }
    );

    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    commonService.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      {
        status: 'Failed',
        error_type: 'Failed'
      },
      { id: saveApiLog.dataValues.id }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: errorMsg,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.forgotPassword = async (req, res) => {
  const saveApiLog = await commonService.createApiLogs(req);
  try {


    const { base_url, method, formdata } = req.body;

    let where = {};
    if (formdata.username) {
      where.username = formdata.username;
    }
    if (formdata.email) {
      where.email = formdata.email;
    }
    const user = await userService.getUser(where);

    if (!user) {
      const response = commonService.response(
        0,
        message.USER_NOT_FOUND,
        null,
        message.ERROR
      );

      await commonService.updateLogsData(
        {
          status: 'Failed',
          error_type: 'Failed'
        },
        { id: saveApiLog.dataValues.id }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.OK).json(response);
    }
    const code = commonService.generateOTP();

    const startTime = moment()
      .add(process.env["USER_LOGIN__OTP_EXPIRETIME_" + env], "hour")
      .format("YYYY-MM-DD h:mm:ss");

    await otpService.createOTP({
      mobile: user.mobile,
      templateid: emailTemplates.id,
      otp: code,
      record_id: user.id,
      record_type: "user",
      expirytime: startTime,
      created: utils.getUTCDateTime(),
      modified: utils.getUTCDateTime()
    });

    const emailData = await templateService.emailTemplate({
      template_name: "OTP Generation",
    });
    const smsData = await templateService.smsTemplate({
      template_name: "Income Protection OTP",
    });
    let templateBody = emailData?.body;
    let smsBody = smsData.template;


    const object = {
      USER_FIRSTNAME: user.first_name,
      OPT: code,
    };
    for (const key in object) {
      templateBody = templateBody
        ? templateBody.replace(new RegExp(`{${key}}`, "g"), `${object[key]}`)
        : null;
      smsBody = smsBody ? smsBody.replace(new RegExp(`{${key}}`, "g"), `${object[key]}`) : null;
    }

    commonService.sendMail(user.email, "loginOTP", templateBody);
    if (smsBody) {
      await communicationService.sendSms(user.mobile, smsBody, smsData.template_id);
    }


    await userService.createUserCommunication("loginOTP", templateBody, user.email);
    await userService.createUserCommunication2("loginOTP", smsBody, user.mobile);

    const token = commonService.generateUserId();

    await userService.updateUser(
      { forget_password_token: token },
      { id_str: user.id_str }
    );

    const link = `${base_url}/validate/otp/forgotpassword/${token}?requestType=${method}`;
    let bitlyurl = await commonService.Bitlylink(link);
    const passwordData = await templateService.emailTemplate({
      template_name: "Forgot Password",
    });
    const smspasswordData = await templateService.smsTemplate({
      template_name: "currently pending consent",
    });

    let template = passwordData?.body;
    let smstemp = smspasswordData.template;


    const objectData = {
      USER_FIRSTNAME: user.first_name,
      FORGET_PASSWORD_URL: link,
    };
    const objectDatasms = {
      USER_FIRSTNAME: user.first_name,
      FORGET_PASSWORD_URL: bitlyurl.shortened_url,
    }

    for (const key in objectData) {
      template = template ? template.replace(new RegExp(`{${key}}`, "g"), `${objectData[key]}`) : null;
    }
    for (const key in objectDatasms) {
      smstemp = smstemp ? smstemp.replace(new RegExp(`{${key}}`, "g"), `${objectDatasms[key]}`) : null;
    }

    if (template) {
      commonService.sendMail(user.email, "Forgot Password", template);
    }
    if (smsBody) {
      await communicationService.sendSms(user.mobile, smstemp, smspasswordData.template_id);
    }

    await userService.createUserCommunication("Forgot Password", template, user.email);
    await userService.createUserCommunication2("loginOTP", smstemp, user.mobile);
    const mobileNo= await commonService.maskemailmobile(user.mobile,'sms');
    const emailId= await commonService.maskemailmobile(user.email,'email');
    const response = {
      responseCode: httpStatus.OK,
      responseData: null,
      responseMessage: `${message.SENT_USER_PASSWORD_OTP}${emailId}`,
    };

    await commonService.updateLogsData(
      {
        status: 'Success',
        user_id: JSON.stringify(user.id),
        error_type: 'Success'
      },
      { id: saveApiLog.dataValues.id }
    );

    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.OK).json(response);

  } catch (err) {
    //update api log
    commonService.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      {
        status: 'Failed',
        error_type: 'Failed'
      },
      { id: saveApiLog.dataValues.id }
    );
    await commonService.updateApiLogsData(
      {
        response: JSON.stringify({
          status: message.ERROR,
          msg: errorMsg,
        })
      },
      { id: saveApiLog.dataValues.id }
    );
   
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.forgotPasswordValidation = async (req, res) => {
  const saveApiLog = await commonService.createApiLogs(req);
  try {

    const { method, formdata, token } = req.body;

    const user = await userService.getUser({ forget_password_token: token });
    if (!user) {
      const response = commonService.response(
        0,
        message.USER_NOT_FOUND,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        {
          status: 'Failed',
          error_type: 'Failed'
        },
        { id: saveApiLog.dataValues.id }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.OK).json(response);
    }
    await commonService.updateLogsData(
      {
        user_id: JSON.stringify(user.id)
      },
      { id: saveApiLog.dataValues.id }
    );

    const existingOTP = await otpService.getExistingOtp({
      otp: formdata?.otp,
      record_id: user?.id,
      mobile: user?.mobile,
      otp_status: "send",
    });

    if (!existingOTP) {
      const response = commonService.response(
        0,
        message.INVALID_OTP,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        {
          status: 'Failed',
          error_type: 'Failed'
        },
        { id: saveApiLog.dataValues.id }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }

    const date = moment().format("YYYY-MM-DD h:mm:SS A");

    const expireTime = moment(existingOTP.expirytime).format(
      "YYYY-MM-DD h:mm:SS A"
    );
    if (date > expireTime) {
      await otpService.updateOtp({ otp_status: "expire" }, { id: existingOTP.id })
      return res.status(httpStatus.BAD_REQUEST).json({
        message: message.OTP_EXPIRE,
      });
    }

    await otpService.updateOtp(
      { otp_status: "verified" },
      { id: existingOTP.id }
    );

    await userService.updateUser(
      { forget_password_token: null },
      { id_str: user.id_str }
    );

    const createToken = commonService.createToken(
      user,
      process.env["JWT_SECRET_" + env]
    );

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.VALIDATE_USER_PASSWORD_OTP,
      responseData: null,
      token: createToken,
    };

    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.OK).json(response);

  } catch (err) {
    commonService.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      {
        status: 'Failed',
        error_type: 'Failed'
      },
      { id: saveApiLog.dataValues.id }
    );
    //update api log user id
    await commonService.updateApiLogsData(
      {
        response: JSON.stringify({
          status: message.ERROR,
          msg: err.errors ? err.errors[0].message : err.message,
        })
      },
      { id: saveApiLog.dataValues.id }
    );
    
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.changePassword = async (req, res) => {
  try {
    const saveApiLog = await commonService.createApiLogs(req);

    const { method, formdata } = req.body;
    const token = req.body.token ? req.body.token : req.headers["x-access-token"];
    const decode = commonService.decodeToken(token);

    if (!decode) {
      const response = commonService.response(
        0,
        message.INVALID_TOKEN,
        null,
        message.ERROR
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }

    const currentPassword = commonService.cryptoPasswordDecrypt(
      formdata.current_password
    );

    const confirmPassword = commonService.cryptoPasswordDecrypt(
      formdata.confirm_current_password
    );

    if (currentPassword !== confirmPassword) {
      const response = commonService.response(
        0,
        message.MISMATCH_PASSWORD,
        null,
        message.ERROR
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }

    if (typeof formdata.old_password !== 'undefined') {
      const user = await userService.getUser({ username: decode.username });
      const decrypt = commonService.cryptoPasswordDecrypt(formdata.old_password);
      const isMatch = await bcrypt.compare(decrypt, user.password);

      if (!isMatch) {
        const response = {
          responseCode: 0,
          responseMessage: message.MISMATCH_OLD_PASSWORD,
          responseData: null,
        };

        await commonService.updateApiLogsData(
          { response: JSON.stringify(response) },
          { id: saveApiLog.dataValues.id }
        );
        return res.status(httpStatus.OK).json(response);
      }
    }

    const checkPassword = await commonService.passowrdValidation(
      currentPassword
    );

    if (checkPassword.length > 0) {
      const response = commonService.response(
        0,
        message.MISMATCH_PASSWORD,
        { invalidField: checkPassword },
        message.ERROR
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.OK).json(response);
    }
    const encryptPassword = commonService.hashPassword(currentPassword);

    await userService.updateUserPassword(
      { 
        password: encryptPassword,
        last_password_change:new Date()
      },
      { id: decode.id }
    );

    await userService.userPasswordHistoryData({
      uid_str: decode.id_str,
      password: formdata.current_password,
      modified_by: decode.id,
      created: new Date(),
    });

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.PASSWORD_CHANGED,
      responseData: null,
    };


    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.OK).json(response);

  } catch (err) {
    //commonService.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    //update api log user id
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: errorMsg,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

exports.logOut = async (req, res) => {

  try {
    //const saveApiLog = await commonService.createApiLogs(req);
    const user = req.user;
    await userService.updateUser(
      { login_token: "logout" },
      { id_str: user.id_str }
    );

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.LOGGED_OUT,
      responseData: null,
    };
    await commonService.updateLogsData(
      {
        status: 'Success',
        error_type: 'Success'
      },
      { id: req.dataValues }
    );

    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.OK).json(response);
  } catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log table
    await commonService.updateLogsData(
      {
        status: 'Failed',
        error_type: 'Failed'
      },
      { id: req.dataValues }
    );
    await commonService.updateApiLogsData(
      {
        response: JSON.stringify({
          status: message.ERROR,
          msg: err.errors ? err.errors[0].message : err.message,
        })
      },
      { id: req.dataValues }
    );

   
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};


// user list
exports.getUserList = async (req, res) => {
  try {
    const module_nm = req.body.module === "users" ? "User" : "";
    getRoleListData = await pickService.getRoleList();

    let keys = Object.keys(UserListRenderHeaderData);
    if (Object.keys(UserListRenderHeaderData[4]).includes("options")) {
      UserListRenderHeaderData[4].options = getRoleListData;
    }


    getUserData = await userService.getUserList(req);

      let fieldObj = {};
      fieldObj["filters"] = [];
      fieldObj["size"] = req.body.size;
      fieldObj["page"] = req.body.page;
      //fieldObj["per_page"] = 10;
      fieldObj["total"] = getUserData[1];
      fieldObj["styles"] = {};
      fieldObj["rows"] = getUserData[0];
      fieldObj["headers"] = UserListRenderHeaderData;
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: 'User List Data',
          responseData : fieldObj
        }) },
        { id: req.dataValues }
      );
     
      return res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: 'User List Data',
        responseData : fieldObj
      });
  }
  catch(err){
    const errorMsg = err.errors ? err.errors[0].message : err.message;
        await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id: req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: req.dataValues }
    );
    await commonService.updateLogsData(
      {
        status: 'Success',
        error_type: 'Success'
      },
      { id: req.dataValues }
    );
    return res.status(httpStatus.OK).json({
      responseCode: httpStatus.OK,
      responseMessage: 'User List Data',
      responseData: fieldObj
    });
  }
 
};

exports.getUserDetails = async (req, res) => {
  try {
    const { id_str, request_type, module } = req.body;
    let userData = {}
    if (module == "users" && request_type == "view") {
      userData = await userService.getUser({
        id_str: id_str,
      });
    }

    //request json decrypted
    //utils.getDecryptedJson(userData);

    //update api log
    await commonService.updateLogsData(
      {
        status: 'Success',
        error_type: 'Success'
      },
      { id: req.dataValues }
    );
    await commonService.updateApiLogsData(
      {
        response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: message.USER_RECEIVED,
          responseData: userData
        })
      },
      { id: req.dataValues }
    );

    return res.status(httpStatus.OK).json({
      responseCode: httpStatus.OK,
      responseMessage: message.USER_RECEIVED,
      responseData: userData
    });
  } catch (err) {
    //utils.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log
    await commonService.updateLogsData(
      {
        status: 'Failed',
        error_type: 'Failed'
      },
      { id: req.dataValues }
    );
    await commonService.updateApiLogsData(
      {
        response: JSON.stringify({
          status: message.errorMsg,
          msg: err.errors ? err.errors[0].message : err.message,
        })
      },
      { id: req.dataValues }
    );

    
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.errorMsg,
      msg: errorMsg,
    });
  }
};


exports.userCreate = async (req, res) => {
  try {

    //const saveApiLog = await commonService.createApiLogs(req);
    const decode = req.user;
    const formdata = req.body.formdata;
    if (!decode.id == 1) {
      const response = commonService.response(
        0,
        message.INVALID_TOKEN,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }

    let userPayload = {
      role_id: formdata?.role_id,
      repairer_id: formdata?.repairer_id ? formdata?.repairer_id : null,
      username: formdata?.username,
      first_name: formdata?.first_name,
      middle_name: formdata?.middle_name ? formdata?.middle_name : "",
      last_name: formdata?.last_name,
      email: formdata?.email,
      mobile: formdata?.mobile,
      reports_to: formdata?.reports_to ? formdata?.reports_to : "",
      status: formdata?.status,
      is_admin: formdata?.is_admin ? formdata?.is_admin : "off",
      web_access: formdata?.web_access ? formdata?.web_access : "yes",
      mobile_access: formdata?.mobile_access ? formdata?.mobile_access : "no",
      last_password_change: utils.getUTCDateTime(),
      modified: utils.getUTCDateTime(),
      modified_by: decode?.id,
      time_zone: formdata?.time_zone ? formdata?.time_zone : "IST",
      time_zone_name: formdata?.time_zone_name
        ? formdata?.time_zone_name
        : "Asia/Kolkata",
      currency: formdata?.currency ? formdata?.currency : null,
      date_format: formdata?.date_format ? formdata?.date_format : null,
      profile_image: formdata?.profile_image ? formdata?.profile_image : null,
      salutation: formdata?.salutation ? formdata?.salutation : null,
      dob: formdata?.dob ? formdata?.dob : null,
      gender: formdata?.gender ? formdata?.gender : "male",
      latitude: formdata?.latitude ? formdata?.latitude : null,
      longitude: formdata?.longitude ? formdata?.longitude : null,
      rating: formdata?.rating ? formdata?.rating : "0",
      ip: req.dataValues.ip,// here change saveApilog into req.dataValues
      user_agent: req.headers["user-agent"],
      source: formdata?.source ? formdata?.source : "web",
      timeslot_flag: formdata?.timeslot_flag ? formdata?.timeslot_flag : "0",
    };


    //request json encrypted
   // utils.getEncryptedJson(userPayload);
    let response = "";
    if (formdata.id_str == "" || null) {
      const decrypt = commonService.cryptoPasswordDecrypt(
        formdata.current_password
      );
      const encryptPassword = commonService.hashPassword(decrypt);
      (userPayload["id_str"] = utils.generateUserId()),
        (userPayload["created"] = utils.getUTCDateTime()),
        (userPayload["created_by"] = decode.id),
        (userPayload["password"] = encryptPassword),
        (response = await userService.createUser(userPayload))
      response = response.dataValues;
    }
    else {
      response = await userService.updateUser(userPayload, {
        id_str: formdata.id_str,
      });

      const updateUserCliData = await userService.getUser({
        id_str: formdata.id_str,
      });

      response = updateUserCliData
      await userService.deleteUserCliData({
        id_str: formdata.id_str,
      });
    }
    const clientProgramArray = formdata.client_program;
    const clientProgram = clientProgramArray.map(async (clientProgram) => {
      if (clientProgram == "") return null;
      return await userService.createUserClientProgram({
        id_str: formdata?.id_str ? formdata?.id_str : userPayload["id_str"],
        clientprogram_id: clientProgram,
        created: utils.getUTCDateTime(),
        modified: utils.getUTCDateTime(),
      });
    });
 

      Promise.all(clientProgram);
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: formdata.id_str
            ? message.USER_UPDATED
            : message.USER_CREATED,
          responseData: response,
        }) },
        { id: req.dataValues }
      );
    return res.status(httpStatus.OK).json({
      responseCode: httpStatus.OK,
      responseMessage: formdata.id_str
        ? message.USER_UPDATED
        : message.USER_CREATED,
      responseData: response,
    });
  } catch (err) {
    //utils.dumpError(err);
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );

    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.errorMsg,
        msg: errorMsg,
      }) },
      { id: req.dataValues }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.errorMsg,
      msg: errorMsg,
    });
  }
};

exports.checkFun = async (req, res) => {
  try {
    const { q } = req.query;
    // JSON.parse(req.body.newKey);
    let userPayload = {
      first_name: "Tej",
      last_name: "Pratap",
      full_name: "Tej Pratap",
      email: "tej@gmail.com",
      mobile: "23232323"
    }

    let encryptData = {
      first_name: "Www4v4MeBFken8cU9Np2HA==",
      last_name: "MvApe81wlAzbtRTcxN0WYQ==",
      full_name: "Tej Pratap",
      email: "nPWnTM9ocGh4vRzgG9eTyQ==",
      mobile: "MBwHY+4CjACJ3E7hLEkI5w=="
    }

    let processType;
    let data;
    if (q == "enc") {
      processType = "Encryption";
      data = utils.getEncryptedJson(req.body);
    }

    if (q == "dec") {
      processType = "Decryption";
      data = utils.getDecryptedJson(req.body);
    }
    return res.status(200).json({
      status: "success",
      processType,
      data,
      //decryptedData:decryptedData
    })

  } catch (err) {
    console.log(err);
    return res.status(500).json({
      err: err?.message
    })
  }

}

