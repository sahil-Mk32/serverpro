const httpStatus = require("http-status");
const commonService = require("../../common/utils");
const claimService = require("../../service/claim/claim.service");
const message = require("../../common/messages");
const env = process.env.ENV.toUpperCase();
const { Op } = require("sequelize");


exports.list = async (req, res) => {
  const saveApiLog = await commonService.createApiLogs(req);
    try {
      let postReq = {};
      timestamp = Math.floor(Date.now()/1000);
      const decode = commonService.decodeToken(req.headers['x-access-token']);
      if (!decode) {
        //update api log
        await commonService.updateLogsData(
          { status: 'Failed',
            error_type:'Failed'
          },
          { id:saveApiLog.dataValues.id }
        );
        await commonService.updateApiLogsData(
          { response: JSON.stringify({
            message: "Invalid or expired token",
          }) },
          { id: saveApiLog.dataValues.id }
        );
        return res.status(400).json({
          message: "Invalid or expired token",
        });
      }
      
      let headerToken = commonService.createExposeHeaderToken(timestamp,'CLAIM');

      let clientprogram_code = decode.clientprogram_code;
      //let clientprogram_code=["CLP1","CLP2","CLP3"]
      req.body= {...req.body, clientprogram_code};
      let baseUrl = process.env['BASE_URL_PHP_' + env];
      postReq["api_name"] = "getContractList";
      postReq["api_data_key"] = 100001;
      postReq["expose"] = "php";
      postReq["base_url"] = baseUrl;
      postReq["url"] = "/biometric_webapi/v1/get_salesdata_by_claim_api.php";
     
      postReq["headers"] = {
        Authorization: headerToken,
        ContentType: 'application/json',
        Timestamp: timestamp
      };

      let apiConsumeRes = await commonService.postAPI(req.body, postReq);
      if(apiConsumeRes.responseCode == 200){
        for(const row of apiConsumeRes.responseData.rows){
          let isCreatePermission = await claimService.isCreatePermission({policy_no: row.policy_no,status: { [Op.notIn]: ["Claim Closed"] }},row.policy_end_date,row.qualifying_end_date);
          (isCreatePermission==1 && decode.role_id == 9) ? row.action.create = true : row.action.create = false;
        }
      }
      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:saveApiLog.dataValues.id }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(apiConsumeRes) },
        { id: saveApiLog.dataValues.id }
      );
      return res.json(apiConsumeRes);
    }
    catch (err) {
      ///const errorMsg = err.errors ? err.errors[0].message : err.message;
      //updating api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:saveApiLog.dataValues.id }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: err.message,
        }) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: err.message,
      });
    }
};
  
exports.detail = async (req, res) => {
  const saveApiLog = await commonService.createApiLogs(req);
  try {
    let postReq = {};
    timestamp = Math.floor(Date.now()/1000);
    const decode = commonService.decodeToken(req.headers['x-access-token']);
    if (!decode) {
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:saveApiLog.dataValues.id }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          message: "Invalid or expired token",
        }) },
        { id: saveApiLog.dataValues.id }
      );
      return res.status(400).json({
        message: "Invalid or expired token",
      });
    }
    
    let headerToken = commonService.createExposeHeaderToken(timestamp,'CLAIM');

    let clientprogram_code = decode.clientprogram_code;
    req.body= {...req.body, clientprogram_code};
    let baseUrl = process.env['BASE_URL_PHP_' + env];
    postReq["api_name"] = "getContractDetail";
    postReq["api_data_key"] = 100002;
    postReq["expose"] = "php";
    postReq["base_url"] = baseUrl;
    postReq["url"] = "/biometric_webapi/v1/get_salesdata_by_claim_api.php";
   
    postReq["headers"] = {
      Authorization: headerToken,
      ContentType: 'application/json',
      Timestamp: timestamp
    };
    let apiConsumeRes = await commonService.postAPI(req.body, postReq);
    if(apiConsumeRes.responseCode == 200){
        let isCreatePermission = await claimService.isCreatePermission({policy_no: apiConsumeRes.responseData.policy_no,status: { [Op.notIn]: ["Claim Closed"] }},apiConsumeRes.responseData.policy_end_date,apiConsumeRes.responseData.qualifying_period_end_date);
        if(!isCreatePermission || decode.role_id != 9) {
          //update api log
          await commonService.updateLogsData(
            { status: 'Failed',
              user_id: JSON.stringify(decode.id),
              error_type:'Failed'
            },
            { id:saveApiLog.dataValues.id }
          );
          await commonService.updateApiLogsData(
            { response: JSON.stringify(apiConsumeRes) },
            { id: saveApiLog.dataValues.id }
          );
          return res.status(httpStatus.OK).json({
            responseCode: 0,
            responseMessage: message.NOT_ACCESSIBLE,
            responseData: {}
          });
        }
    }
    //update api log
    await commonService.updateLogsData(
      { status: 'Success',
        user_id: JSON.stringify(decode.id),
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify(apiConsumeRes) },
      { id: saveApiLog.dataValues.id }
    );
    return res.json(apiConsumeRes);
  }
  catch (err) {
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    //updating api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: "error",
        msg: err.message,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: "error",
      msg: err.message,
    });
  }
};