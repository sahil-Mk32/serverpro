const httpStatus = require("http-status");
const salesMasterService = require("../../service/sales/sales.service");
const {
  createApiLogs,
  updateApiLogsData,
  dumpError,
} = require("../../common/utils");
const message = require("../../common/messages");
const db = require("../../model");
const business = db.salesBusiness;
const client = db.salesClient;
const clientProgram = db.salesClientprogram;
const operationalCountry = db.salesOperationalCountry;
const plan = db.salesPlan;
const program = db.salesProgram;
const programPlan = db.salesProgramplan;
const commonService =require("../../common/utils");

exports.salesBusiness = async (req, res) => {
  const saveApiLog = await createApiLogs(req);
  try {
    
    const body = req.body;
    await salesMasterService.salesMasterUpsert(business,
      {
        business_name: body?.businessName,
        business_id: body?.businessId,
        business_code: body?.businessCode,
        business_theme_color1: body?.businessThemeColor1,
        business_category: body?.businessCategory,
        business_status: body?.businessStatus,
        business_theme_color2: body?.businessThemeColor2,
        business_description: body?.businessDescription,
        business_icon: body?.businessIcon,
        source: body?.source,
        created_by: body?.createdBy,
        modified_by: body?.modifiedBy,
      },
      { business_id: body?.businessId }
    );

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DATA_UPSERTED,
    };
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );

    res.status(httpStatus.OK).json(response);
  } catch (err) {
    //dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};

exports.salesClient = async (req, res) => {
  const saveApiLog = await createApiLogs(req);
  try {
    
    const body = req.body;
    await salesMasterService.salesMasterUpsert(client,
      {
        client_code: body?.clientCode,
        operationcountryid: body?.operationcountryid,
        businessid: body?.businessid,
        client_display_name: body?.clientDisplayName,
        client_agreement_status: body?.clientAgreementStatus,
        source: body?.source,
        created_by: body?.createdBy,
        modified_by: body?.modifiedBy,
      },
      {
        client_code: body?.clientCode,
      }
    );

    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DATA_UPSERTED,
    };
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    res.status(httpStatus.OK).json(response);
  } catch (err) {
    console.log(err);
    //dumpError(err);
    
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg:err.message
      }) },
      { id: saveApiLog.dataValues.id}
    );

    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};

exports.salesClientProgram = async (req, res) => {
  const saveApiLog = await createApiLogs(req);
  try {
    const body = req.body;
    await salesMasterService.salesMasterUpsert(clientProgram,
      {
        clientprogram_code: body?.clientprogramCode,
        program_code: body?.programCode,
        program_name: body?.programName,
        client_code: body?.clientCode,
        client_account_name: body?.clientAccountName,
        client_program_status: body?.clientProgramStatus,
        source: body?.source,
        created_by: body?.createdBy,
        modified_by: body?.modifiedBy,
      },
      {
        clientprogram_code: body?.clientprogramCode,
      }
    );
    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DATA_UPSERTED,
    };
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    res.status(httpStatus.OK).json(response);
  } catch (err) {
    //dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};

exports.salesOperationalCountry = async (req, res) => {
  const saveApiLog = await createApiLogs(req);
  try {
    const body = req.body;

    await salesMasterService.salesMasterUpsert(operationalCountry,
      {
        country_id: body?.countryId,
        country_name: body?.countryName,
        currency: body?.currency,
        postalcode: body?.postalcode,
        accounting_date: body?.accountingDate,
        dateformat: body?.dateformat,
        timezone: body?.timezone,
        region: body?.region,
        mobile_regex: body?.mobileRegex,
        pincode_regex: body?.pincodeRegex,
        status: body?.status,
        source: body?.source,
        created_by: body?.createdBy,
        modified_by: body?.modifiedBy,
      },
      {
        country_id: body?.countryId,
      }
    );
    
    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DATA_UPSERTED,
    };
    //update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    res.status(httpStatus.OK).json(response);
  } catch (err) {
    //dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};

exports.salesPlan = async (req, res) => {
  const saveApiLog = await createApiLogs(req);
  try {
    const body = req.body;
    await salesMasterService.salesMasterUpsert(plan,
      {
        plan_code: body?.planCode,
        plan_name: body?.planName,
        benefit_period: body?.benefitPeriod,
        waiting_period: body?.waitingPeriod,
        plan_month_period: body?.planMonthPeriod,
        source: body?.source,
        plan_status: body?.planStatus,
        gpb_value: body?.gpbValue,
        created_by: body?.createdBy,
        modified_by: body?.modifiedBy,
      },
      {
        plan_code: body?.planCode,
      }
    );
    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DATA_UPSERTED,
    };
    //update api log
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    res.status(httpStatus.OK).json(response);
  } catch (err) {
    //dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};

exports.salesProgram = async (req, res) => {
  const saveApiLog = await createApiLogs(req);
  try {
    const body = req.body;
    await salesMasterService.salesMasterUpsert(program,
      {
        program_code: body?.programCode,
        program_description: body?.programDescription,
        program_name: body?.programName,
        program_status: body?.programStatus,
        program_type: body?.programtype,
        created_by: body?.createdBy,
        modified_by: body?.modifiedBy,
        source: body?.source,
        sum_insured_percentage: body?.sumInsuredPercentage,
      },
      {
        program_code: body?.programCode,
      }
    );
    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DATA_UPSERTED,
    };

    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    res.status(httpStatus.OK).json(response);
  } catch (err) {
    //dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};

exports.salesProgramPlan = async (req, res) => {
  const saveApiLog = await createApiLogs(req);
  try {
    const body = req.body;
    await salesMasterService.salesMasterUpsert(programPlan,
      {
        programplan_code: body?.programplanCode,
        program_code: body?.programCode,
        programname: body?.programname,
        plan_code: body?.planCode,
        plan_name: body?.planName,
        programplan_status: body?.programplanStatus,
        source: body?.source,
        created_by: body?.createdBy,
        modified_by: body?.modifiedBy,
      },
      {
        programplan_code: body?.programplanCode,
      }
    );
    const response = {
      responseCode: httpStatus.OK,
      responseMessage: message.DATA_UPSERTED,
    };
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify(response) },
      { id: saveApiLog.dataValues.id }
    );
    res.status(httpStatus.OK).json(response);
  } catch (err) {
    //dumpError(err);
    //const errorMsg = err.errors ? err.errors[0].message : err.message;

    //update api log
    //update api log
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:saveApiLog.dataValues.id }
    );
    await updateApiLogsData(
      { response: JSON.stringify({
        status: message.ERROR,
        msg: err.message,
      }) },
      { id: saveApiLog.dataValues.id }
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: err.message,
    });
  }
};
