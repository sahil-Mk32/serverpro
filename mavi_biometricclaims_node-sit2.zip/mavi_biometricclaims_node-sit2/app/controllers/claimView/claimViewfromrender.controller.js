const httpStatus = require("http-status");
const utils = require("../../common/utils");
const claimViewSer = require("../../service/claimView/claimView.service");
const claimService = require("../../service/claim/claim.service");
const commonSer = require("../../service/common/common.service");
const message = require("../../common/messages");
const pickService = require("../../service/picklist/picklist.service");
const { getUser } = require("../../service/user/user.service");
const { QueryTypes } = require("sequelize");
const db = require("../../model");
const sequelize = db.sequelize;
const commonService = require("../../common/utils");

exports.claimViewApprovalHistoryFromRender = async (req, res) => {
try {

    let { id, module, method, section,request_type, mode, sectionid } = req.body;
    mode = mode.toUpperCase();
    const decode = req.user;

    let claimData = await claimViewSer.getClaimColumnData(id);
    let clm_id_str = claimData[0]['id_str'];
    let clm_status = claimData[0]['status'];
    let clm_substatus = claimData[0]['substatus'];
    let client_program_id = claimData[0]['client_program_id'];
    let roleid  = decode.role_id;

    //let roleid  =7;

    if(module == "claims" && method == "view_individual_approval_history" && request_type == "view")
    {
        let pickListDataArray = [];
        let case_sub_status_id = await commonSer.getSubstatusIdBystatusSubstatus(clm_status,clm_substatus);
        if(clm_status == 'Payment' || clm_status == 'Review' || ( clm_status== 'L2 Adjudication' &&  clm_substatus== 'Approved')){
            pickListDataArray = [];
        }else{
            pickListDataArray = await commonSer.getPickListDataByStatusAndSubStatus(roleid,case_sub_status_id,client_program_id);
        }
        
                
            const getApprovalHistorySectionData = await sequelize.query(
                `SELECT  
            clm_section.type,
            clm_section.title ,
            clm_section.content ,
            clm_section.name ,
            clm_section.displayType ,
            clm_section.styles,
            clm_section.disabled ,
            clm_section.hidden,
            clm_section.hidetoggle, 
            clm_section.expanded,
            clm_section.fields  
            FROM 
            clm_section 
            INNER JOIN clm_module 
            ON clm_module.id= clm_section.module_id
            WHERE LOWER(clm_module.name)='claims' and clm_section.type='accordian' and 
            parent_section_id=`+sectionid+` order by clm_section.sequence asc`,
            {
                type: QueryTypes.SELECT,
            });
            
            let ApprovalHistoryGroup  = [];
            for(const row of getApprovalHistorySectionData){
                let newObj = {};
                newObj["type"] = row.type ? row.type : '';
                newObj["title"] = row.title ? row.title : '';
                newObj["content"] = row.content ? row.content : false;
                newObj["name"] = row.name ? row.name : false;
                newObj["displayType"] = row.displayType === 1 ? row.displayType : false;
                newObj["styles"] = row.styles ? JSON.parse(row.styles) : null;
                newObj["disabled"] = row.disabled === 1 ? true : false;
                newObj["hidetoggle"] = row.hidetoggle === 1 ? true : false;
                newObj["expanded"] = row.expanded === 1 ? true : false;
                if(pickListDataArray.length > 0)
                {
                    let pickListData = pickListDataArray;
                    newObj["hidden"] = row.hidden === 1 ? true : false;
                    
                    let formArrayFields = row.fields ? await getFormGroupTableFrmRender(sectionid, row.fields, pickListData, clm_status,clm_id_str,claimData) : "";
                    let sectionFields = await getFieldDataBySectionFieldId(row.fields, pickListData, clm_status,clm_id_str);                           
                    let fields = [...formArrayFields, ...sectionFields]

                    newObj["fields"] = fields;                   
                }
                else
                {
                    newObj["hidden"] = true
                    newObj["fields"] = "";
                }       
                ApprovalHistoryGroup.push(newObj);
            }

            let actionsButton = {};
            if(pickListDataArray.length > 0)
            {
                 actionsButton = JSON.parse('{"type": "button","name": "action","inputType": "button","displayType": "default","styles": {},"options": [{"type": "button","name": "button","inputType": "button","label": "Save","icon": "","disabled": false,"styles": {	"color": "primary","css": {"background": "rgb(4, 171, 233)"}},"callbacks": [{"redirectURL": "claims/view","method": "approvalhistory","action": "api/claimView/approvalhistorysubmit","type": "submit","fieldData": null}],"action": "draft"}]}');
            }

            
            let claimFormStyle = '{"id": "approvalHistoryForm","class": ["dynmaic-form"]}';

            let approvalHistoryFormObj = {
            name: "claim_view",
            title: "Approval History",
            styles: JSON.parse(claimFormStyle),
            groups: ApprovalHistoryGroup,
            actions : actionsButton
            }

            const response = {
            responseCode: 200,
            responseMessage: "Ok",
            responseData: approvalHistoryFormObj,
            };

            //update api log
            await commonService.updateLogsData(
                { status: 'Success',
                  error_type:'Success'
                },
                { id:req.dataValues }
              );
            await commonService.updateApiLogsData(
                { response: JSON.stringify(response) },
                { id: req.dataValues}
            );
            return res.status(httpStatus.OK).json(response);
    }
} catch (err) {
    //update api log
    await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
    await commonService.updateApiLogsData(
        { response: JSON.stringify({
            status: "error",
            msg: err.errors ? err.errors[0].message : err.message,
            }) },
        { id: req.dataValues}
      );
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
    status: "error",
    msg: errorMsg,
    });
}
};

const getFieldDataBySectionFieldId = async (sectionFieldIds,pickListData,clm_status,clm_id_str,page=null) => {
    let fieldData  = [];
      const getFieldDataByFieldId = await sequelize.query(
        `SELECT  
        clm_field.field_id AS id,
        clm_field.type ,
        clm_uitype_master.inputtype AS 'inputType' ,
        clm_field.fieldname AS 'name' ,
        clm_field.fieldlabel AS 'label' ,
        clm_field.mandatory AS 'required',
        clm_field.placeholder ,
        clm_field.minimumlength AS 'minlength',
        clm_field.maximumlength AS 'maxlength', 
        clm_field.readonly,
        clm_field.disabled,
        clm_field.hidden,
        clm_field.pattern,
        clm_field.validations,
        clm_field.styles,
        clm_field.callbacks,
        clm_field.options  
        FROM 
        clm_field
        INNER JOIN clm_uitype_master
        ON clm_uitype_master.id = clm_field.uitype
        WHERE clm_field.field_id IN(`+sectionFieldIds+`) ORDER BY sequence`,
            {
                type: QueryTypes.SELECT,
            });
           for(const row of getFieldDataByFieldId){
              let fieldObj = {};
              let disabled = readonly = 1;   
              fieldObj["id"] = row.id ? row.id : '';
              fieldObj["type"] = row.type ? row.type : '';
              fieldObj["inputType"] = row.inputType ? row.inputType : '';
              fieldObj["name"] = row.name ? row.name : '';
              fieldObj["label"] = row.label ? row.label : '';
              fieldObj["required"] = row.required === 1 ? true : false;
              if(row.name == 'status'){ fieldObj["value"] = clm_status;}
              else if(row.name == 'id_str'){ fieldObj["value"] = clm_id_str;}else{fieldObj["value"] = '';}
              fieldObj["placeholder"] = row.placeholder ? row.placeholder : '';
              fieldObj["minlength"] = row.minlength ? row.minlength : 0;
              fieldObj["maxlength"] = row.maxlength ? row.maxlength : 0;
              fieldObj["readonly"] = row.readonly === 1 ? true : false;
              fieldObj["disabled"] = row.disabled === 1 ? true : false;
              fieldObj["hidden"] = row.hidden === 1 ? true : false;
              fieldObj["pattern"] = row.pattern ? row.pattern : null;
              
              if(page=='approval_history' && row.name == 'disability')
              { 
                fieldObj["width"] = 25;
                fieldObj["readonly"] = true;
                fieldObj["disabled"] = true;
              }
              else if(page=='approval_history' && row.name == 'is_date_disability_diff_by_csr')
              { 
                fieldObj["width"] = 15;
              }
              else if(page=='approval_history' && row.name == 'date_disability_as_per_review')
              { 
                fieldObj["width"] = 20;
              }
              else if(page=='approval_history' && row.name == 'icd_code')
              { 
                fieldObj["width"] = 10;
              }
              else if(page=='approval_history' && row.name == 'icd_code_description')
              { 
                fieldObj["width"] = 30;
              }
              
              fieldObj["validations"] = row.validations ? JSON.parse(row.validations) : null;
              fieldObj["styles"] = row.styles ? JSON.parse(row.styles) : null;
              fieldObj["callbacks"] = row.callbacks ? JSON.parse(row.callbacks) : false;
              if(row.name == 'substatus')
              {
                  fieldObj["options"] = pickListData ? JSON.parse(pickListData) : null;
              }
              else if(row.name == 'disability')
              {
                  fieldObj["options"] = await pickService.getPickListAllData(row.name);
              }
              else if(row.name == 'icd_code')
                {
                    fieldObj["options"] = await pickService.getPickListAllData(row.name, 10);
                }
              else{
                  fieldObj["options"] = row.options ? JSON.parse(row.options) : '';    
              }
              
              fieldData.push(fieldObj);
          };
          return fieldData;
  }

  const getFormGroupTableFrmRender = async (sectionid, fields, pickListData = null, clm_status = null, clm_id_str = null, claimData =null) => {
    let newObj ={};
    let fieldData = {};
    let groupData  = [];
    
    const getApprovalHistoryFormArraySectionData = await sequelize.query(
    `SELECT  
    clm_section.type,
    clm_section.title ,
    clm_section.content ,
    clm_section.name ,
    clm_section.displayType ,
    clm_section.styles,
    clm_section.disabled ,
    clm_section.hidden,
    clm_section.hidetoggle, 
    clm_section.expanded,
    clm_section.fields  
    FROM 
    clm_section 
    INNER JOIN clm_module 
    ON clm_module.id= clm_section.module_id
    WHERE LOWER(clm_module.name)='claims' and clm_section.type='formarray' and 
    parent_section_id=`+sectionid+` order by clm_section.sequence asc`,
    {
        type: QueryTypes.SELECT,
    });
    let ApprovalHistoryGroup  = [];
    for(const row of getApprovalHistoryFormArraySectionData){
        let newObj = {};
        newObj["type"] = 'formarray';
        newObj["inputType"] = '';
        newObj["displayType"] = row.displayType,
        newObj["icon"] = '';
        newObj["placeholder"] = '';
        newObj["title"] = row.title,
        newObj["name"] = row.name,
        newObj["label"] = row.title,
        newObj["styles"] = null;
        newObj["disabled"] = false;
        newObj["hidden"] = false;
        newObj["hidetoggle"] = false;
        newObj["expanded"] = true;
        newObj["callbacks"] = [];
        
        fieldData['fields'] = await getFieldDataBySectionFieldId(row.fields,pickListData,null,null,'approval_history');
        newObj["formgroups"] = fieldData;

        let tableAttributes = ["id", "disability", "is_date_disability_diff_by_csr", "doctor_confirmed_disability_date", "date_disability_as_per_review", "icd_code", "icd_code_description"];
        const getClaimDisabilitiesData = await claimService.getClaimDisabilitiesData({case_id: claimData[0].id}, tableAttributes);
        
        let dataRow = []
        for (const row of getClaimDisabilitiesData) {
          let fieldObj = {};
          fieldObj["id"] = row.id,
          fieldObj["disability"] = row.disability,
          fieldObj["is_date_disability_diff_by_csr"] = row.is_date_disability_diff_by_csr,
          fieldObj["date_disability_as_per_review"] = (row.date_disability_as_per_review!== null && row.date_disability_as_per_review !=='') ? row.date_disability_as_per_review : row.doctor_confirmed_disability_date,
          fieldObj["icd_code"] = row.icd_code,
          fieldObj["icd_code_description"] = row.icd_code_description
          dataRow.push(fieldObj);
        }
        
        newObj["fieldData"] = dataRow;
        
        groupData.push(newObj);  
    }
        
    return groupData;
  }
