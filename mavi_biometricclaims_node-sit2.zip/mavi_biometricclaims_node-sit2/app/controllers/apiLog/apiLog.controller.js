const httpStatus = require("http-status");
const utils = require("../../common/utils");
const message = require("../../common/messages");
const apiLogService = require("../../service/api/apiLog.service");
const hashingService = require("../../common/hashing");

// payment schedule list
exports.getapiLogDetail = async (req, res) => {
    try {
        const { id, request_type, module } = req.body;
        let response = {
            responseCode: httpStatus.OK,
            responseMessage: message.NOT_DETAILS_RETRIEVED,
            responseData: null,
        };
        if (module == "apiLog" && request_type == "view") {
            const data = await apiLogService.getApiLogData({ id: id});
            data.req_body = hashingService.decrypt(data.req_body);
            data.response = hashingService.decrypt(data.response);
            response["responseMessage"] = message.DETAILS_RETRIEVED;
            response["responseData"] = data;
        }
        return res.status(httpStatus.OK).json(response);
    } 
    catch (err) {
        utils.dumpError(err);
        const errorMsg = err.errors ? err.errors[0].message : err.message;
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
            status: message.ERROR,
            msg: errorMsg,
        });
    }
}