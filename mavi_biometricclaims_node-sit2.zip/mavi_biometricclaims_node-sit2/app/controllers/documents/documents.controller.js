const httpStatus = require("http-status");
const utils = require("../../common/utils");
const moment = require("moment");
const moduleService = require("../../service/module/module.service");
const { documentHistoryRenderHeaderData } = require("../../uirender/claim_documetsFormRendering");
const FormData = require("form-data");
const env = process.env.ENV.toUpperCase();
const documentService = require("../../service/documents/documents.service");
const claimService = require("../../service/claim/claim.service");
const { getUser } = require("../../service/user/user.service");
const message = require("../../common/messages");
const commonSer = require("../../service/common/common.service");
const reviewScheduleServie = require("../../service/reviewSchedule/reviewSchedule.service");
const commonService = require("../../common/utils");
const paymentScheduleService = require("../../service/paymentSchedule/paymentSchedule.service");

class Documents {
	constructor() { }

	async documentsCreateOne(req, res) {
		try {
			//update api log
			await commonService.updateLogsData(
				{ status: 'Success',
				  error_type:'Success'
				},
				{ id:req.dataValues }
			  );
			await commonService.updateApiLogsData(
				{ response: JSON.stringify({
					responseCode: httpStatus.OK,
					responseMessage: message.DOCUMENT_CREATED,
				}) },
				{ id: req.dataValues }
			);
			res.status(httpStatus.OK).json({
				responseCode: httpStatus.OK,
				responseMessage: message.DOCUMENT_CREATED,
			});
		} catch (err) {
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			//update api log
			await commonService.updateLogsData(
				{ status: 'Failed',
				  error_type:'Failed'
				},
				{ id:req.dataValues }
			  );
			await commonService.updateApiLogsData(
				{ response: JSON.stringify({
					status: "error",
					msg: errorMsg,
				}) },
				{ id: req.dataValues }
			);
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async documentsUpload(req, res) {
		try {
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}
			if (req.body.data) {
				if (utils.isEmpty(JSON.parse(req.body.data))) {
					throw {
						message: `Data can't be empty`,
					};
				}
				req.body = JSON.parse(req.body.data);
			} else {
				throw {
					message: `Data can't be empty`,
				};
			}
			for (let key in req.body) {
				if (req.body[key] == "" || req.body[key] == null) {
					throw {
						message: `${key} can't be null or empty`,
					};
				}
			}
			// req.body.module = "Claims";
			let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);
			if (utils.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
			let { id: moduleId, module:moduleName } = module;
			let claimNumber = '';

			if(moduleName.toLowerCase() == 'reviewschedule'){
				let reviewSchedule = await reviewScheduleServie.getReview({reviewScheduleAttributes: null, picklistReviewModeAttributes: null, whereCondition: { review_number: req.body.id }});
				if (utils.isEmpty(reviewSchedule)) {
					throw {
						message: `${req.body.id} review not found`,
					};
				}
				claimNumber = reviewSchedule.claim_number;
			}else if(moduleName.toLowerCase() == 'paymentschedule'){
				let paymentSchedule = await paymentScheduleService.getPaymentScheduleData({ payment_number: req.body.id,deleted:0});
				if (utils.isEmpty(paymentSchedule)) {
					throw {
						message: `${req.body.id} payment not found`,
					};
				}
				claimNumber = paymentSchedule.claim_number;
			}
			else{
				claimNumber = req.body.id;
			}


			const claimDetail = await claimService.getClaimData({
				claim_number: claimNumber
			});
			if((claimDetail.status == 'New Case Request' && claimDetail.substatus == 'Document Pending') || (claimDetail.substatus  && req.body.method=='other_documents') || (claimDetail.substatus && req.body.method=='upload_documents'))
			{
				let apiCallpayload = {
					base_url: process.env["BASE_URL_DS_" + env],
					url: "/api/document/upload",
					headers: { "Content-Type": "multipart/form-data" },
				};
				let data = {
					method: req.body.method,
					module: moduleId,
					parent_id:claimNumber,
					application_id: process.env["DS_APPLICATION_ID_" + env],
					reference_id: req.body.id,
					user_id: req.user.id,
				};

				let formData = new FormData();
				formData.append("data", JSON.stringify(data));
				formData.append("file", req.files[req.body.method].data, req.files[req.body.method].name);
				let mimeType = req.files[req.body.method].mimetype.split("/");
				let response = await utils.postAPI(formData, apiCallpayload);
				if (response && !utils.isEmpty(response.responseData)) {
					documentService.createDocument({
						ds_refid: response.responseData.id,
						module_id: moduleId,
						claim_number: claimNumber,
						type: response.responseData.type,
						filename: response.responseData.name,
						original_filename: response.responseData.fileName,
						filepath: response.responseData.path,
						filesize: req.files[req.body.method].size,
						extension: mimeType[mimeType.length - 1],
						assigned_to: req.user.id,
						status: 'active',
						created: moment().utc().format('YYYY-MM-DD hh:mm:ss'),
						modified: moment().utc().format('YYYY-MM-DD hh:mm:ss'),
						created_by: req.user.id,
						modified_by: req.user.id,
						deleted: 0,
					});
				}
				//update api log
				await commonService.updateLogsData(
					{ status: 'Success',
					  error_type:'Success'
					},
					{ id:req.dataValues }
				  );
				await commonService.updateApiLogsData(
					{ response: JSON.stringify(response) },
					{ id: req.dataValues }
				);
				res.status(httpStatus.OK).json(response);
			}
			else{
				//update api log
				await commonService.updateLogsData(
					{ status: 'Success',
					  error_type:'Success'
					},
					{ id:req.dataValues }
				  );
				await commonService.updateApiLogsData(
					{ response: JSON.stringify({
						responseCode: 0,
						responseMessage: message.NOT_ACCESSIBLE,
						responseData: {}
					}) },
					{ id: req.dataValues }
				);
				res.status(httpStatus.OK).json({
					responseCode: 0,
					responseMessage: message.NOT_ACCESSIBLE,
					responseData: {}
				});
			}
		} catch (err) {
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			//update api log
			await commonService.updateLogsData(
				{ status: 'Failed',
				  error_type:'Failed'
				},
				{ id:req.dataValues }
			  );
			await commonService.updateApiLogsData(
				{ response: JSON.stringify({
					status: "error",
					msg: errorMsg,
				}) },
				{ id: req.dataValues }
			);
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async documentsList(req, res) {
		try {
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}

			let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);

			if (utils.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
			let { id: moduleId } = module;
			let postReq = {};
			let data = {
				module: moduleId,
				application_id: process.env["DS_APPLICATION_ID_" + env],
				reference_id: req.body.id
			};

			let timestamp = Math.floor(Date.now()/1000);
			let headerToken = utils.createExposeHeaderToken(timestamp,'DS');
			let baseUrl = process.env['BASE_URL_DS_' + env];
			postReq["api_name"] = "getDocumentList";
			postReq["api_data_key"] = 100002;
			postReq["expose"] = "node_ds";
			postReq["base_url"] = baseUrl;
			postReq["url"] = "/api/document/list";

			postReq["headers"] = {
				authorization: headerToken,
				ContentType: 'application/json',
				timestamp: timestamp
			};

			let response = await utils.postAPI(data, postReq);
			let responseData = response.responseData;
			if (response.responseStatus == 'success') {

				let claimants_statement = [];
				let clinical_abstract_form = [];
				let doctors_statement_or_attending_physician_statement = [];
				let medical_reports = [];
				let police_report = [];
				let deputy_appointment = [];
				let salary_slips = [];
				let other_documents = [];

				for (const ele of responseData) {
					if (ele.type == 'claimants_statement') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						claimants_statement.push(obj);
					}
					else if (ele.type == 'clinical_abstract_form') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						clinical_abstract_form.push(obj);
					}
					else if (ele.type == 'doctors_statement_or_attending_physician_statement') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						doctors_statement_or_attending_physician_statement.push(obj);
					}
					else if (ele.type == 'medical_reports') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						medical_reports.push(obj);
					}
					else if (ele.type == 'police_report') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						police_report.push(obj);
					}
					else if (ele.type == 'deputy_appointment') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						deputy_appointment.push(obj);
					}
					else if (ele.type == 'salary_slips') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						salary_slips.push(obj);
					}
					else if (ele.type == 'other_documents') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						other_documents.push(obj);
					}

				}

				// update api log
				await commonService.updateLogsData(
					{ status: 'Success',
					  error_type:'Success'
					},
					{ id:req.dataValues }
				  );
				await commonService.updateApiLogsData(
					{ response: JSON.stringify({
						responseCode: httpStatus.OK,
						responseStatus: "success",
						responseMessage: message.DOCUMENT_RECEIVED,
						responseData: {
							claimants_statement,
							clinical_abstract_form,
							doctors_statement_or_attending_physician_statement,
							medical_reports,
							police_report,
							deputy_appointment,
							salary_slips,
							other_documents
						},
					}) },
					{ id: req.dataValues }
				);

				res.status(httpStatus.OK).json({
					responseCode: httpStatus.OK,
					responseStatus: "success",
					responseMessage: message.DOCUMENT_RECEIVED,
					responseData: {
						claimants_statement,
						clinical_abstract_form,
						doctors_statement_or_attending_physician_statement,
						medical_reports,
						police_report,
						deputy_appointment,
						salary_slips,
						other_documents
					},
				});
			}
			else {
				await commonService.updateLogsData(
					{ status: 'Success',
					  error_type:'Success'
					},
					{ id:req.dataValues }
				  );
				await commonService.updateApiLogsData(
					{ response: JSON.stringify(response) },
					{ id: req.dataValues }
				);
				res.status(httpStatus.OK).json(response);
			}

		} catch (err) {
			await commonService.updateLogsData(
				{ status: 'Failed',
				  error_type:'Failed'
				},
				{ id:req.dataValues }
			  );
			await commonService.updateApiLogsData(
				{ response: JSON.stringify({
					status: "error",
					msg: err.errors ? err.errors[0].message : err.message,
				}) },
				{ id: req.dataValues }
			);
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async documentsHistory(req, res) {
		try {
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}

			let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);

			if (utils.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
			let { id: moduleId } = module;

			const getDocumentHistoryData = await documentService.getDocumentHistoryList(req,moduleId);

			let fieldObj = {};

			fieldObj["headers"] = documentHistoryRenderHeaderData;
			fieldObj["data"] = getDocumentHistoryData[0];
			fieldObj["page"] = 1;
			fieldObj["per_page"] = 10;
			fieldObj["total"] = getDocumentHistoryData[1];
			fieldObj["type"] = "table";

			//update api log
			await commonService.updateLogsData(
				{ status: 'Success',
				  error_type:'Success'
				},
				{ id:req.dataValues }
			  );
			await commonService.updateApiLogsData(
				{ response: JSON.stringify({
					responseCode: httpStatus.OK,
					responseMessage: 'Document History Data',
					responseData : fieldObj
				}) },
				{ id: req.dataValues }
			);


			return res.status(httpStatus.OK).json({
				responseCode: httpStatus.OK,
				responseMessage: 'Document History Data',
				responseData : fieldObj
			});

		} catch (err) {
			//update api log
			await commonService.updateLogsData(
				{ status: 'Failed',
				  error_type:'Failed'
				},
				{ id:req.dataValues }
			  );
			await commonService.updateApiLogsData(
				{ response: JSON.stringify({
					status: "error",
					msg: err.errors ? err.errors[0].message : err.message,
				}) },
				{ id: req.dataValues }
			);
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async documentsDelete(req, res) {
		try {
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}
			let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);

			if (utils.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
			let { id: moduleId, module:moduleName } = module;
			let claimNumber = '';

			if(moduleName.toLowerCase() == 'reviewschedule'){
				let reviewSchedule = await reviewScheduleServie.getReview({reviewScheduleAttributes: null, picklistReviewModeAttributes: null, whereCondition: { review_number: req.body.claim_id }});
				if (utils.isEmpty(reviewSchedule)) {
					throw {
						message: `${req.body.id} review not found`,
					};
				}
				claimNumber = reviewSchedule.claim_number;
			}
			else{
				claimNumber = req.body.claim_id;
			}

			const claimDetail = await claimService.getClaimData({
				claim_number: claimNumber
			});
			if((claimDetail.status == 'New Case Request' && claimDetail.substatus == 'Document Pending') || (moduleName.toLowerCase() == 'reviewschedule'))
			{
				let postReq = {};
				let data = {
					id: req.body.formdata.id,
					module: moduleId,
					application_id: process.env["DS_APPLICATION_ID_" + env],
					reference_id: req.body.claim_id,
					filepath: req.body.formdata.path,
					user_id: req.user.id
				};

				let timestamp = Math.floor(Date.now()/1000);
				let headerToken = utils.createExposeHeaderToken(timestamp,'DS');
				let baseUrl = process.env['BASE_URL_DS_' + env];
				postReq["api_name"] = "getDocumentDelete";
				postReq["api_data_key"] = 100003;
				postReq["expose"] = "node_ds";
				postReq["base_url"] = baseUrl;
				postReq["url"] = "/api/document/delete";

				postReq["headers"] = {
					authorization: headerToken,
					ContentType: 'application/json',
					timestamp: timestamp
				};

				let response = await utils.postAPI(data, postReq);
				await commonService.updateLogsData(
					{ status: 'Success',
					  error_type:'Success'
					},
					{ id:req.dataValues }
				  );

				await commonService.updateApiLogsData(
					{ response: JSON.stringify(response) },
					{ id: req.dataValues }
				);
				return res.json(response);
			}
			else{
				await commonService.updateLogsData(
					{ status: 'Success',
					  error_type:'Success'
					},
					{ id:req.dataValues }
				  );
				  await commonService.updateApiLogsData(
					{ response: JSON.stringify({
						responseCode: 0,
						responseMessage: message.NOT_ACCESSIBLE,
						responseData: {}
					}) },
					{ id: req.dataValues }
				);
				res.status(httpStatus.OK).json({
					responseCode: 0,
					responseMessage: message.NOT_ACCESSIBLE,
					responseData: {}
				});
			}
		} catch (err) {
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			await commonService.updateLogsData(
				{ status: 'Failed',
				  error_type:'Failed'
				},
				{ id:req.dataValues }
			);

			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async documentSubmit(req, res) {
		try {
			const saveApiLog = await utils.createApiLogs(req);
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}
			let claim = await claimService.getClaimData({
				claim_number: req.body.id,
			});
			if (utils.isEmpty(claim)) {
				throw {
					message: `${req.body.id} claim no found`,
				};
			}
			if (claim.status == 'New Case Request' && claim.substatus == 'Document Pending') {

				let caseSubStatus = await claimService.getSubStatus({pname: 'New Case Request', name: "Document Submitted"});
				const assignTo = await commonSer.getNextAssignTo(claim.client_program_id,req.user.role_id,caseSubStatus.id,"NA");

				/* update claim table */
				await claimService.updateClaimData(
                    {substatus: "Document Submitted", assigned_to: assignTo, modified: utils.getUTCDateTime(),modified_by: req.user.id || 1},
                    {claim_number: claim.claim_number}
                );

				/* insert into claim status history */
                let historyData = {
                    case_id: claim.id,
                    case_status_id: caseSubStatus.pid,
                    case_substatus_id: caseSubStatus.id,
                    case_status: caseSubStatus.pname,
                    case_substatus: caseSubStatus.name,
                    assigned_to: assignTo,
                    modified: utils.getUTCDateTime(),
                    modified_by: req.user.id || 1,
                    source: req.source || "WEB",
                }
                await claimService.createStatusHistoryData(historyData);

				let response = {
					responseCode: httpStatus.OK,
					responseMessage: message.DATA_SAVED_DOCUMENTS
				};
				await commonService.updateLogsData(
					{ status: 'Success',
					  error_type:'Success'
					},
					{ id:req.dataValues }
				  );
				await utils.updateApiLogsData({response: JSON.stringify(response)},{id:saveApiLog.dataValues.id});
				res.status(httpStatus.OK).json(response);
			}
			else {

				return res.status(httpStatus.OK).json({
					responseCode: httpStatus.OK,
					responseMessage: message.NOT_ACCESSIBLE,
					responseData: {}
				});
			}
		} catch (err) {
			await commonService.updateLogsData(
				{ status: 'Failed',
				  error_type:'Failed'
				},
				{ id:req.dataValues }
			  );
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			await utils.updateApiLogsData({response: JSON.stringify({
				status: "error",
				msg: errorMsg,
			})},{id:saveApiLog.dataValues.id});
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async getReviewScheduleDocumentList(req, res) {
		try {
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}

			let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);

			if (utils.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
			let { id: moduleId } = module;
			let postReq = {};
			let data = {
				module: moduleId,
				application_id: process.env["DS_APPLICATION_ID_" + env],
				reference_id: req.body.id
			};

			let timestamp = Math.floor(Date.now()/1000);
			let headerToken = utils.createExposeHeaderToken(timestamp,'DS');
			let baseUrl = process.env['BASE_URL_DS_' + env];
			postReq["api_name"] = "getDocumentList";
			postReq["api_data_key"] = 100002;
			postReq["expose"] = "node_ds";
			postReq["base_url"] = baseUrl;
			postReq["url"] = "/api/document/list";

			postReq["headers"] = {
				authorization: headerToken,
				ContentType: 'application/json',
				timestamp: timestamp
			};

			let response = await utils.postAPI(data, postReq);
			let documents = [];
			if (response && response.responseData) {
				for (let document of response.responseData) {
					documents.push({
						id: document.id,
						name: document.original_filename,
						path: document.filepath,
					});
				}
			}
			return documents;
		} catch (err) {
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async getCustomerDocumentList(req, res) {
		try {
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}

			let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);

			if (utils.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
			let { id: moduleId } = module;
			let postReq = {};
			let data = {
				module: moduleId,
				application_id: process.env["DS_APPLICATION_ID_" + env],
				reference_id: req.body.id
			};

			let timestamp = Math.floor(Date.now()/1000);
			let headerToken = utils.createExposeHeaderToken(timestamp,'DS');
			let baseUrl = process.env['BASE_URL_DS_' + env];
			postReq["api_name"] = "getDocumentList";
			postReq["api_data_key"] = 100002;
			postReq["expose"] = "node_ds";
			postReq["base_url"] = baseUrl;
			postReq["url"] = "/api/document/list";

			postReq["headers"] = {
				authorization: headerToken,
				ContentType: 'application/json',
				timestamp: timestamp
			};

			let response = await utils.postAPI(data, postReq);
			let responseData = response.responseData;
			let claimants_statement = [];
			let clinical_abstract_form = [];
			let doctors_statement_or_attending_physician_statement = [];
			let medical_reports = [];
			let police_report = [];
			let deputy_appointment = [];
			let salary_slips = [];
			if (response.responseStatus == 'success') {
				for (const ele of responseData) {
					if (ele.type == 'claimants_statement') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						claimants_statement.push(obj);
					}
					else if (ele.type == 'clinical_abstract_form') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						clinical_abstract_form.push(obj);
					}
					else if (ele.type == 'doctors_statement_or_attending_physician_statement') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						doctors_statement_or_attending_physician_statement.push(obj);
					}
					else if (ele.type == 'medical_reports') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						medical_reports.push(obj);
					}
					else if (ele.type == 'police_report') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						police_report.push(obj);
					}
					else if (ele.type == 'deputy_appointment') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						deputy_appointment.push(obj);
					}
					else if (ele.type == 'salary_slips') {
						let obj = {
							id: ele.id,
							name: ele.original_filename,
							path: ele.filepath
						};
						salary_slips.push(obj);
					}
				}
			}
			const documentList = {
				claimants_statement,
				clinical_abstract_form,
				doctors_statement_or_attending_physician_statement,
				medical_reports,
				police_report,
				deputy_appointment,
				salary_slips
			}
			return documentList;
		} catch (err) {
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async customerDocumentsUpload(req, res) {
		try {
			const saveApiLog = await utils.createApiLogs(req);
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}
			if (req.body.data) {
				if (utils.isEmpty(JSON.parse(req.body.data))) {
					throw {
						message: `Data can't be empty`,
					};
				}
				req.body = JSON.parse(req.body.data);
			} else {
				throw {
					message: `Data can't be empty`,
				};
			}
			for (let key in req.body) {
				if (req.body[key] == "" || req.body[key] == null) {
					throw {
						message: `${key} can't be null or empty`,
					};
				}
			}
			const { token} = req.body;
    		const claimData = await claimService.getToken(token);
			const userData = await getUser({ username: 'customer_user' });
			if (claimData.length <= 0) {
				const response = utils.response(
					200,message.CLAIM_NOT_FOUND,null,message.ERROR
				);
				await utils.updateApiLogsData(
					{ response: JSON.stringify(response) },
					{ id: saveApiLog.dataValues.id }
				);
				return res.status(httpStatus.OK).json(response);
			}

			req.body = {...req.body,id:claimData[0].claim_number};

			let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);
			if (utils.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}
			let { id: moduleId } = module;
			let apiCallpayload = {
				base_url: process.env["BASE_URL_DS_" + env],
				url: "/api/document/upload",
				headers: { "Content-Type": "multipart/form-data" },
			};
			let data = {
				method: req.body.method,
				module: moduleId,
				application_id: process.env["DS_APPLICATION_ID_" + env],
				reference_id: req.body.id,
				user_id: userData.id
			};

			let formData = new FormData();

			formData.append("data", JSON.stringify(data));
			formData.append("file", req.files[req.body.method].data, req.files[req.body.method].name);
			let mimeType = req.files[req.body.method].mimetype.split("/");
			let response = await utils.postAPI(formData, apiCallpayload);
			if (response && !utils.isEmpty(response.responseData)) {
				documentService.createDocument({
					ds_refid: response.responseData.id,
					module_id: moduleId,
					claim_number: req.body.id,
					type: response.responseData.type,
					filename: response.responseData.name,
					original_filename: response.responseData.fileName,
					filepath: response.responseData.path,
					filesize: req.files[req.body.method].size,
					extension: mimeType[mimeType.length - 1],
					assigned_to: claimData[0].created_by,
					status: 'active',
					created: moment().utc().format('YYYY-MM-DD hh:mm:ss'),
					modified: moment().utc().format('YYYY-MM-DD hh:mm:ss'),
					created_by: claimData[0].created_by,
					modified_by: claimData[0].created_by,
					deleted: 0,
				});
			}
			await utils.updateApiLogsData(
				{ response: JSON.stringify(response) },
				{ id: saveApiLog.dataValues.id }
			);
			res.status(httpStatus.OK).json(response);
		} catch (err) {
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

	async customerDocumentsDelete(req, res) {
		try {
			if (utils.isEmpty(req.body)) {
				throw {
					message: `Body can't be empty`,
				};
			}

			let module = await moduleService.getModuleByName(
				req.body.module.toLowerCase()
			);

			if (utils.isEmpty(module)) {
				throw {
					message: `${req.body.module} module not found`,
				};
			}

			let { id: moduleId } = module;
			let postReq = {};

			const claimData = await claimService.getToken(req.body.token);
			const userData = await getUser({ username: 'customer_user' });
			if (claimData.length <= 0) {
				const response = utils.response(
					200,message.CLAIM_NOT_FOUND,null,message.ERROR
				);
				await utils.updateApiLogsData(
					{ response: JSON.stringify(response) },
					{ id: saveApiLog.dataValues.id }
				);
				return res.status(httpStatus.OK).json(response);
			}

			let data = {
				id: req.body.formdata.id,
				module: moduleId,
				application_id: process.env["DS_APPLICATION_ID_" + env],
				reference_id: claimData[0].claim_number,
				filepath: req.body.formdata.path,
				user_id: userData.id
			};

			let timestamp = Math.floor(Date.now()/1000);
			let headerToken = utils.createExposeHeaderToken(timestamp,'DS');
			let baseUrl = process.env['BASE_URL_DS_' + env];
			postReq["api_name"] = "getDocumentDelete";
			postReq["api_data_key"] = 100003;
			postReq["expose"] = "node_ds";
			postReq["base_url"] = baseUrl;
			postReq["url"] = "/api/document/delete";

			postReq["headers"] = {
				authorization: headerToken,
				ContentType: 'application/json',
				timestamp: timestamp
			};
			let response = await utils.postAPI(data, postReq);
			return res.json(response);

		} catch (err) {
			const errorMsg = err.errors ? err.errors[0].message : err.message;
			return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
				status: "error",
				msg: errorMsg,
			});
		}
	}

}

exports.documentsCtrl = new Documents();