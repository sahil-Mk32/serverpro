const httpStatus = require("http-status");
const commonService = require("../../common/utils");
const commonService2 = require("../../service/common/common.service");
const claimService = require("../../service/claim/claim.service");
const moduleService = require("../../service/module/module.service");
const { SectionService } = require("../../service/section/section.service");
const { FieldService } = require("../../service/field/field.service");
const { sectionData } = require("../../uirender/claim_reviewScheduleCreateFormRendering");
const picklistService = require("../../service/picklist/picklist.service");
const reviewScheduleServie = require("../../service/reviewSchedule/reviewSchedule.service");

class ReviewScheuleFormRender {
  constructor() {}

  reviewScheduleCreateFrmRender = async (req, res) => {
    try {
      if (commonService.isEmpty(req.body)) {
        
        throw {
          message: `Body can't be empty`,
        };
      }
      let module = await moduleService.getModuleByName(
        req.body.module.toLowerCase()
      );
      if (commonService.isEmpty(module)) {
        
        throw {
          message: `${req.body.module} module not found`,
        };
      }
      let claim = await claimService.getClaimData({
        claim_number: req.body.parent_id,
      });
      if (commonService.isEmpty(claim)) {
        
        throw {
          message: `${req.body.parent_id} claim not found`,
        };
      }
      // let reviewSchedule = await reviewScheduleServie.getReview({ review_number: req.body.id });
      let reviewSchedule = await reviewScheduleServie.getReview({reviewScheduleAttributes: null, picklistReviewModeAttributes: null, whereCondition: { review_number: req.body.id }});
      if (commonService.isEmpty(reviewSchedule)) {
        
        throw {
          message: `${req.body.id} review not found`,
        };
      }
      let sections = await SectionService.getAllSection({
        module_id: module.id,
      });
      let groups = [];
      for (let section of sections) {
        let group = {
          // ...sectionData,
          type: section.type,
          title: section.title,
          styles: section.styles ? JSON.parse(section.styles) : null,
          name: section.name,
          hidetoggle: section?.hidetoggle ? true : false,
          hidden: section?.hidden ? true : false,
          expanded: section?.expanded ? true : false,
          displayType: section.displayType,
          disabled: section?.disabled ? true : false,
          fields: await (this.getFieldDataBySectionFieldId(section?.fields, reviewSchedule.review_status, req, claim)),
        };
        groups.push(group);
      }
      let responseData = {
        ...sectionData,
        groups,
        name: "complaint_form",
        styles: { id: "complaintForm", class: ["dynmaic-form"] },
        title: "Create Complaint",
      };
      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: 200,
          responseMessage: "Form Json",
          responseData: responseData,
        }) },
        { id: req.dataValues }
      );
      res.status(200).json({
        responseCode: 200,
        responseMessage: "Form Json",
        responseData: responseData,
      });
    } catch (err) {
      console.log(err);
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  getFieldDataBySectionFieldId = async (sectionFieldIds, reviewScheduleStatus, req = null, claimDetail = null) => {
    try {
      let fieldData = [];
      if (sectionFieldIds) {
        let fieldTableAttributes = [
          ["field_id", "id"],
          "type",
          "icon",
          ["fieldname", "name"],
          ["fieldlabel", "label"],
          ["mandatory", "required"],
          "placeholder",
          ["minimumlength", "minlength"],
          ["maximumlength", "maxlength"],
          "disabled",
          "readonly",
          "hidden",
          "pattern",
          "validations",
          "styles",
          "callbacks",
          "options",
        ];
        let uiTableAttributes = [["inputtype", "inputType"]];
        let fields = await FieldService.getFieldsByIds({fieldTableAttributes, uiTableAttributes, sectionFieldIds});
        for (let field of fields) {
          let options = JSON.parse(field.options);
          let fieldName = field.get("name");
          if (field.type == "select") { 
            if (fieldName == "review_mode_id") {
              options = await picklistService.getPickListAllData("review_mode");
            } else if (fieldName == "review_status") {
              const subStatusId = await commonService2.getSubstatusIdBystatusSubstatus(claimDetail.status,claimDetail.substatus);
              const pickList = await commonService2.getPickListDataByStatusAndSubStatus(req.user.role_id,subStatusId,claimDetail.client_program_id);            
              options = pickList ? JSON.parse(pickList) : false;
            }
          }
          fieldData.push({
            id: field.get("id") ? field.get("id") : "",
            type: field.type ? field.type : "",
            icon: field.icon ? field.icon : "",
            inputType: field.clm_uitype_master.get("inputType") || "",
            name: fieldName || "",
            label: field.get("label") ? field.get("label") : "",
            required: field.get("required") ? true : false,
            value: "",
            placeholder: field.placeholder ? field.placeholder : "",
            minlength: field.get("minlength") || 0,
            maxlength: field.get("maxlength") || 100,
            readonly: field.readonly ? true : false,
            disabled: field.disabled ? true : false,
            hidden: field.hidden ? true : false,
            pattern: field.pattern ? field.pattern : "",
            validations: JSON.parse(field.validations),
            styles: JSON.parse(field.styles),
            callbacks: JSON.parse(field.callbacks),
            options,
          });
        }
      }
      return fieldData;
    } catch (error) {
      throw error;
    }
  }
}

exports.ReviewScheuleFormRender = new ReviewScheuleFormRender();
