const httpStatus = require("http-status");
const commonService = require("../../common/utils");
const commonService2 = require("../../service/common/common.service");
const message = require("../../common/messages");
const moment = require("moment");
const claimService = require("../../service/claim/claim.service");
const moduleService = require("../../service/module/module.service");
const reviewScheduleService = require("../../service/reviewSchedule/reviewSchedule.service");
const paymentScheduleService = require("../../service/paymentSchedule/paymentSchedule.service");
const { communicationCtrl } = require("../../controllers/communication/communication.controller");
const { documentsCtrl } = require("../../controllers/documents/documents.controller");
const { PicklistReviewModeServie } = require("../../service/picklistReviewMode/picklistReviewMode.service");
const { ReviewScheduleListRenderHeaderData, ReviewScheduleListRenderFilterData } = require("../../uirender/claim_reviewScheduleListRendering");
class ReviewSchedule {
  constructor() {}

  async createReviewScheduleOne(req, res) {
    try {
        
        let validStatus = 'L2 Adjudication';
        let validSubStatus = 'Approved';
        let validRoleId = '5';

      if (commonService.isEmpty(req.body)) {
        throw {
          message: `Body can't be empty`,
        };
      }
      for (let key in req.body) {
        if (req.body[key] == "" || req.body[key] == null) {
          throw {
            message: `${key} can't be null or empty`,
          };
        }
      }
      let claim = await claimService.getClaimData({
        claim_number: req.body.claim_no,
      });
      if (commonService.isEmpty(claim)) {
        throw {
          message: `${req.body.claim_no} claim no found`,
        };
      }
      if (claim.status == validStatus && claim.substatus == validSubStatus && req.user.role_id == validRoleId) {
        let reviewInterval = req.body.review_frequency_in_days;
        let paymentStartDate = req.body.payment_start_date;
        let actualNoOfReview = await reviewScheduleService.getActualNoReview(req);
        var i = 1;
        let review_due = '1/'+actualNoOfReview;
        for (const reviewIntervalKey in reviewInterval) {
          let review_serial = i+'/'+actualNoOfReview;
          let review_due_date = moment(req.body.claim_approved_date).add(reviewInterval[reviewIntervalKey], "d").format("YYYY-MM-DD") ;
          
          if(moment(review_due_date) >= moment(req.body.payment_end_date))
          { break;}

          let review_type = (moment(review_due_date) <= moment(paymentStartDate)) ? "pre" : "periodic";

          let { name: review_status } = await claimService.getSubStatus({
            pname: "Review",
            name: "Unassigned",
          });

          let data = {
            review_number: await claimService.moduleEntityNum({
              module_name: "ReviewSchedule",
            }),
            claim_number: req.body.claim_no,
            review_serial,
            review_due_date,
            review_type,
            review_status,
            source: req.body.mode,
            created: moment().utc().format("YYYY-MM-DD H:mm:ss"),
            modified: moment().utc().format("YYYY-MM-DD H:mm:ss"),
            created_by: req.user.id,
            modified_by: req.user.id,
          };
          await reviewScheduleService.createReview(data);
          i++;
        }

        /* update claim */     
        let assignToFlag = await commonService2.getNextPhase({claimNumber: claim.claim_number, currentPhase: 'R'});
        let caseSubStatus = await claimService.getSubStatus({pname: validStatus, name: validSubStatus});			
        let assignTo = await commonService2.getNextAssignTo(claim.client_program_id,req.user.role_id,caseSubStatus.id,assignToFlag);
        
        await claimService.updateClaimData(
          {assigned_to: assignTo, review_due: review_due, payment_end_date: req.body.payment_end_date, payment_due: req.body.payment_due},
          {claim_number: claim.claim_number}
        );
        //update api log
        await commonService.updateLogsData(
          { status: 'Success',
            error_type:'Success'
          },
          { id:req.dataValues }
        );
        await commonService.updateApiLogsData(
          { response: JSON.stringify({
            responseCode: httpStatus.OK,
            responseMessage: message.REVIEW_SCHEDULE_CREATED,
          }) },
          { id: req.dataValues }
        );

        res.status(httpStatus.OK).json({
          responseCode: httpStatus.OK,
          responseMessage: message.REVIEW_SCHEDULE_CREATED,
        });
      }

    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );

      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  async getAllReviewSchedule(req, res) {
    try {
     
      if (commonService.isEmpty(req.body)) {
        throw {
          message: `Body can't be empty`,
        };
      }
      if (!req.body.id) {
        throw {
          message: `Case id can't be empty`,
        };
      }
      let claim = await claimService.getClaimData({
        claim_number: req.body.id,
      });
      if (commonService.isEmpty(claim)) {
        
        throw {
          message: `${req.body.id} claim not found`,
        };
      }

      req.body.module = "ReviewSchedule";
      let module = await moduleService.getModuleByName(
          req.body.module.toLowerCase()
      );
      let { id: moduleId } = module;
      
      // check status_wise edit permission
      const subStatusId = await commonService2.getSubstatusIdBystatusSubstatus(claim.status,claim.substatus); 
      let editPermission = await commonService2.getClaimStatusAndSubStatusWiseEditPermession(moduleId,req.user.role_id,claim.client_program_id,subStatusId);
      editPermission = editPermission === 1 ? true : false;
      
      let rows = [];
      let firstEditable = 1;
      let actionBtn;
      let reviewSchedules = await reviewScheduleService.getReviewList({ claimNumber: claim.claim_number });
      
      const getUpcomingPayment = await paymentScheduleService.getUpcomingPaymentSchedule(claim.claim_number);
      
      for (let reviewSchedule of reviewSchedules) {
        if(editPermission && !commonService.getReviewNotEditableStatus().includes(reviewSchedule.review_status) && firstEditable == 1){
          actionBtn = (moment(reviewSchedule.review_due_date) <= moment(getUpcomingPayment[0].payment_due_date)) ? {"edit": true} : {"edit": false}
          firstEditable++
        }
        else{
          actionBtn = {"edit": false};
        }
        rows.push({
          review_id: reviewSchedule.get("review_id"),
          review_due_date: reviewSchedule.review_due_date,
          actual_review_date: reviewSchedule.actual_review_date,
          mode_review: reviewSchedule.clm_picklist_review_mode ? reviewSchedule.clm_picklist_review_mode.get("mode_review") : null,
          review_done_by: reviewSchedule.review_done_by,
          // status: reviewSchedule.clm_claim_sub_status ? reviewSchedule.clm_claim_sub_status.get("status") : null,
          status: reviewSchedule.review_status,
          tat: reviewSchedule.tat ?? moment(reviewSchedule.review_due_date).diff(moment(), "days"),
          action: actionBtn
        });
      }
      let response = {
        columns: ReviewScheduleListRenderHeaderData,
        filters: ReviewScheduleListRenderFilterData,
        page: req.body.page || 1,
        per_page: req.body.size || 10,
        rows,
        total: (await reviewScheduleService.getReviewListCount({ claimNumber: claim.claim_number })) || 0,
      };

      //update api log
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: `Json`,
          responseData: response,
        }) },
        { id: req.dataValues }
      );
      res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: `Json`,
        responseData: response,
      });
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;

      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  async getReviewScheduleDetails(req, res) {
    try {
      if (commonService.isEmpty(req.body)) {
         
        throw {
          message: `Body can't be empty`,
        };
      }
      let module = await moduleService.getModuleByName(
        req.body.module.toLowerCase()
      );
      if (commonService.isEmpty(module)) {
        
        throw {
          message: `${req.body.module} module not found`,
        };
      }
      let claim = await claimService.getClaimData({
        claim_number: req.body.parent_id,
      });
      if (commonService.isEmpty(claim)) {
        
        throw {
          message: `${req.body.parent_id} claim not found`,
        };
      }
      let picklistReviewModeAttributes = [
        ["name", "review_mode_id"]
      ];
      let reviewSchedule = await reviewScheduleService.getReview({reviewScheduleAttributes: null, picklistReviewModeAttributes, whereCondition: { review_number: req.body.id }});
      if (commonService.isEmpty(reviewSchedule)) {

        throw {
          message: `${req.body.id} review not found`,
        };
      }
      let response = {
        review_number: reviewSchedule.review_number,
        claim_number: reviewSchedule.claim_number,
        actual_review_date: reviewSchedule.actual_review_date,
        review_due_date: reviewSchedule.review_due_date,
        review_mode_id: reviewSchedule.clm_picklist_review_mode ? reviewSchedule.clm_picklist_review_mode.get("review_mode_id") : null,
        review_done_by: reviewSchedule.review_done_by,
        remarks: reviewSchedule.remarks,
        review_serial: reviewSchedule.review_serial,
        review_status: reviewSchedule.review_status,
        upload_documents: await documentsCtrl.getReviewScheduleDocumentList(req, res),
      };
     //update api log
     await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
     await commonService.updateApiLogsData(
      { response: JSON.stringify({
        responseCode: httpStatus.OK,
        responseMessage: `Json`,
        responseData: response,
      }) },
      { id: req.dataValues }
    ); 
      res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: `Json`,
        responseData: response,
      });
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
     await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: "error",
        msg: errorMsg,
      }) },
      { id: req.dataValues }
    );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  async updateReviewSchedule(req, res) {
    try {
      const decode = req.user;
      let body = req.body;
      let formdata = req.body.formdata;
      
      let review_done_by = formdata.review_done_by;
      let claim_number = formdata.claim_number;
      let review_number = body.id;
      let actual_review_date = formdata.actual_review_date;
      let review_status = formdata.review_status;
      let remarks = formdata.remarks;

      if (commonService.isEmpty(body)) {
        
        throw {
          message: `Body can't be empty`,
        };
      }
      if (commonService.isEmpty(formdata)) {
        
        throw {
          message: `Form data can't be empty`,
        };
      }
      let module = await moduleService.getModuleByName(
        body.module.toLowerCase()
      );
      if (commonService.isEmpty(module)) {
        
        throw {
          message: `${body.module} module not found`,
        };
      }

      console.log("module",module);
      
      if(body.module == 'reviewschedule' && body.method == 'review_edit'){
        // console.log("inside if block======")
        const claim = await claimService.getClaimData({claim_number});
        let reviewSchedule = await reviewScheduleService.getReview({reviewScheduleAttributes: null, picklistReviewModeAttributes: null, whereCondition: {review_number, claim_number}});
        // console.log("review got",reviewSchedule);
        if (commonService.isEmpty(reviewSchedule)) {
          
          throw {
            message: `${review_number} review not found`,
          };
        }
        if(!commonService.getReviewNotEditableStatus().includes(reviewSchedule.review_status)){
          // console.log("inside common service if block");
          let reviewMode = await PicklistReviewModeServie.getReviewMode({name: formdata.review_mode_id});
          let modeOfReview;
          if(reviewMode){modeOfReview = reviewMode.id;} else{modeOfReview = '';}
          let data = {
            review_mode_id: modeOfReview,
            review_done_by,
            actual_review_date,
            tat: (review_status == "Review Completed Insured Recovered") ? moment(actual_review_date).diff(moment(reviewSchedule.review_due_date), "days") : null,
            review_status,
            remarks,
            modified: commonService.getUTCDateTime(),
            modified_by: decode.id
          }

          // console.log("full data",data);
          
          let response = await reviewScheduleService.updateReview(data, { id: reviewSchedule.id });
          
          /* update claim */
          let nextStatus= await commonService2.getNextClaimPhase_ClaimStatus(decode.role_id, claim.status, claim.substatus);
          let nextSubStatusId = await commonService2.getSubstatusIdBystatusSubstatus(nextStatus, review_status);
          //console.log("next status",nextStatus);
          //console.log("next substatus",nextSubStatusId);
          let assignToFlag = 'NA';
          if(nextSubStatusId == 30 || nextSubStatusId == 15 || nextSubStatusId == 40)
          {
            assignToFlag = await commonService2.getNextPhase({claimNumber: claim.claim_number, currentPhase: 'R'});
          }          
          let assignTo = await commonService2.getNextAssignTo(claim.client_program_id, decode.role_id, nextSubStatusId, assignToFlag);
          let caseSubStatus = await claimService.getSubStatus({id: nextSubStatusId});
          //console.log("assign to",assignTo);
          //console.log("case sub status",caseSubStatus);


          
          await claimService.updateClaimData(
            {status: caseSubStatus.pname, substatus: caseSubStatus.name, assigned_to: assignTo, review_due: reviewSchedule.review_serial},
            {claim_number: claim.claim_number}
          );

          /* insert into claim status history */
          let historyData = {
            case_id: claim.id,
            case_status_id: caseSubStatus.pid,
            case_substatus_id: caseSubStatus.id,
            case_status: caseSubStatus.pname,
            case_substatus: caseSubStatus.name,
            payment_review_no: reviewSchedule.review_serial,
            assigned_to: assignTo,
            modified: commonService.getUTCDateTime(),
            modified_by: decode.id || 1,
            remarks,
            source: req.source || "WEB",
          }
          await claimService.createStatusHistoryData(historyData);
          //update api log
          await commonService.updateLogsData(
            { status: 'Success',
              error_type:'Success'
            },
            { id:req.dataValues }
          );
          await commonService.updateApiLogsData(
            { response: JSON.stringify({
              responseCode: httpStatus.OK,
              responseMessage: message.REVIEW_SCHEDULE_UPDATED,
              responseData: response,
            }) },
            { id: req.dataValues }
          );

          let paymentCountRemaining = await paymentScheduleService.getAllPaymentScheduleData({ claim_number: claim_number,payment_status:'Open',deleted:0});
          //console.log("payment schedule",paymentCountRemaining);
          // email trigger function
          await communicationCtrl.pushTemplateCommQueue({...req,claimNumber:claim_number,commPaymentCountRemaining:paymentCountRemaining.length,commPaymentInstallmentAmount:claim.payment_installment});

          res.status(httpStatus.OK).json({
            responseCode: httpStatus.OK,
            responseMessage: message.REVIEW_SCHEDULE_UPDATED,
            responseData: response,
          });
        }
        else{

          //update api log
          await commonService.updateLogsData(
            { status: 'Success',
              error_type:'Success'
            },
            { id:req.dataValues }
          );
          await commonService.updateApiLogsData(
            { response: JSON.stringify({
              responseCode: httpStatus.OK,
              responseMessage: message.NOT_ACCESSIBLE,
              responseData: {}
            }) },
            { id: req.dataValues }
          );
          return res.status(httpStatus.OK).json({
            responseCode: httpStatus.OK,
            responseMessage: message.NOT_ACCESSIBLE,
            responseData: {}
          });
        }
      }
      else{
        //update api log
        await commonService.updateLogsData(
          { status: 'Success',
            error_type:'Success'
          },
          { id:req.dataValues }
        );
        await commonService.updateApiLogsData(
          { response: JSON.stringify({
            responseCode: httpStatus.OK,
            responseMessage: message.NOT_ACCESSIBLE,
            responseData: {}
          }) },
          { id: req.dataValues }
        );
        return res.status(httpStatus.OK).json({
          responseCode: httpStatus.OK,
          responseMessage: message.NOT_ACCESSIBLE,
          responseData: {}
        });
      }
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      //update api log
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          status: "error",
          msg: errorMsg,
        }) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  callback = async (req, res) => {
    try{
      const fieldname = req?.body?.fieldname;
      let responseData,response;
      switch (fieldname) {
      case "review_status":
          responseData = await this.reviewStatusFieldCallBack(req, res);
          break;
      default:
          responseData = "";
          break;
      }
  
      response = {"responseCode": httpStatus.OK,
      "responseMessage": "ReviewScheduleForm Json",
      "responseData":responseData }
      return res.status(httpStatus.OK).json(response);
  
    } catch (err) {
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
    }
  }

  reviewStatusFieldCallBack = async (req, res) => {
  try
  {
      const { fieldvalue } = req.body;
      let responseDataObj = {};
      let responseData = [];

      if (fieldvalue.toLowerCase() == "review completed insured recovered" || fieldvalue.toLowerCase() == "review completed insured still disabled") 
      {
        responseData = [
            {
                fieldname: "actual_review_date",
                fieldtype: "date",
                validations: [{action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true},{action: "max",value: 0}]
            },
            {
                fieldname: "review_done_by",
                fieldtype: "input",
                validations: [{action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true}]
            },
            {
                fieldname: "review_mode_id",
                fieldtype: "select",
                validations: [{action: "hidden",value: false},{action: "disabled",value: false},{action: "required",value: true}]
            }
        ];
      }
      else{
          responseData = [
            {
              fieldname: "actual_review_date",
              fieldtype: "date",
              defaultvalue: "",
              fieldvalue: "",
              validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false},{action: "max",value: 0}]
            },
            {
                fieldname: "review_done_by",
                fieldtype: "input",
                defaultvalue: "",
                fieldvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false}]
            },
            {
                fieldname: "review_mode_id",
                fieldtype: "select",
                defaultvalue: "",
                validations: [{action: "hidden",value: true},{action: "disabled",value: false},{action: "required",value: false}]
            }
        ];
      }

      responseData.push(responseDataObj);
      return responseData;
  }catch(err){
      const errorMsg = err.errors ? err.errors[0].message : err.message;
      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: message.ERROR,
        msg: errorMsg,
      });
    }
  }

}


exports.ReviewScheduleCtrl = new ReviewSchedule();
