const httpStatus = require("http-status");
const { Op, json } = require("sequelize");
//const commonService = require("../../common/claimUtils");
const commonService = require("../../common/utils");
const moment = require("moment");
const claimService = require("../../service/claim/claim.service");
const db = require("../../model");
const emailTemplates = require("../../model/email/emailTemplate");
const templateService = require("../../service/template/template.service");
const otpService = require("../../service/otp/otp.service");
const message = require("../../common/messages");
const tokenService = require("../../service/userOneTimeToken/token.service");
const {ClaimListRenderHeaderData} = require('../../uirender/claim_claimListRendering.js');
const pickService = require("../../service/picklist/picklist.service");
const env = process.env.ENV.toUpperCase();
const moduleSearch= require("../../service/claimView/claimView.service")
const utils = require("../../common/utils");
const claimModel = db.claimsModel;
const { communicationCtrl } = require("../../controllers/communication/communication.controller");
const communicationService = require("../../service/communication/communication.service");;
const { QueryTypes } = require("sequelize");
//const db = require("../../model");
const sequelize = db.sequelize;

// create claim
exports.clmCreateOne = async (req, res) => {
  try {
   
    /*console.log(moment().utc().format("YYYY-MM-DD H:mm:ss"));
    return false;*/
      const decode = req.user;
      const body = req.body;
      const formdata = body.formdata;
      const multiple_disablities = formdata.illness_and_injury_details;
      const base_url = body.base_url;
      const method = body.method;
      const clientprogram_code = formdata?.clientprogram_code;
      //validation for on policy number claim is in process  
      let claim_no = ""
      const cpid = await claimService.getClientProgramId({ clientprogram_code });
      if(! await claimService.isUserProgramExists(req,cpid.id)){
        const response = commonService.response(
          0,
          message.CLIENT_PROGRAM_NOT_FOUND,
          null,
          message.ERROR
        );
        return res.status(httpStatus.OK).json(response);
      }

      // multiple disabilities validation
      if (!multiple_disablities?.length) {
        const response = commonService.response(
          0,message.NOT_CLAIM_DISABILITY,null,message.ERROR
        );        
        await commonService.updateApiLogsData(
          { response: JSON.stringify(response),status: 'Success', error_type:'Success' },
          { id: req.dataValues}
        );
        return res.status(httpStatus.OK).json(response);
      }
      
      let isDisabilityDateVaild = await claimService.isDisabilityDateVaild(multiple_disablities);
      if (!isDisabilityDateVaild) {
        const response = commonService.response(
          0,message.DISABILITY_DATE_OUT_OF_RANGE,null,message.ERROR
        );        
        await commonService.updateApiLogsData(
          { response: JSON.stringify(response),status: 'Success', error_type:'Success' },
          { id: req.dataValues}
        );
        return res.status(httpStatus.OK).json(response);
      }
      
      const module_name = body.module;
      const currentTime = moment().utc().format("YYYY-MM-DD H:mm:ss");

      let claimPayload = {
        client_program_id: cpid.id, // create function get client-id
        policy_no: formdata?.policy_no,
        policyholder_full_name: formdata?.policyholder_full_name,
        plan_name: formdata?.plan_name,
        policy_start_date: formdata?.policy_start_date,
        policy_end_date: formdata?.policy_end_date,
        benefit_period: formdata?.benefit_period,
        sum_insured: formdata?.sum_insured,
        reserve_amount: formdata?.reserve_amount,
        deferment_payment_period: formdata?.deferment_payment_period ? formdata?.deferment_payment_period : " ",
        qualifying_period_start_date: formdata?.qualifying_period_start_date ? formdata?.qualifying_period_start_date : " ",
        qualifying_period_end_date: formdata?.qualifying_period_end_date ? formdata?.qualifying_period_end_date: " ",
        policy_issue_date: formdata?.policy_issue_date,
        insured_full_name: formdata?.insured_full_name,
        nric_fin_no: formdata?.nric_fin_no,
        email_id: formdata?.email_id,
        mobile_no: formdata?.mobile_no,
        address_1: formdata?.address_1,
        address_2: formdata?.address_2,
        pin_zip_code: formdata?.pin_zip_code,
        city: formdata?.city,
        state: formdata?.state,
        country: formdata?.country,
        account_holder_name: formdata?.account_holder_name ?  formdata?.account_holder_name : " ",
        bank_name: formdata?.bank_name,
        branch_code: formdata?.branch_code,
        account_no: formdata?.account_no,
        claimed_amount: formdata?.claimed_amount,
        description_of_claim: formdata?.description_of_claim,
        same_account_details: formdata?.same_account_details,
        account_holder: formdata?.account_holder,
        relation_with_insured: formdata?.relation_with_insured,
        specify_relationship: formdata?.specify_relationship,
        name_of_next_of_kin: formdata?.name_of_next_of_kin,   
        //source: formdata?.source,
        source: "WEB",
        updt_mobile_no: formdata?.updt_mobile_no,
        updt_bank_name: formdata?.updt_bank_name,
        updt_account_no: formdata?.updt_account_no,
        updt_branch_code: formdata?.updt_branch_code,

        status: 'New Case Request',
        substatus: 'Consent Pending',
        modified:utils.getUTCDateTime(),
        modified_by: decode?.id,
        assigned_to: decode?.id
      }

      let response = "";
      let claim_method = module_name === "claims" ? "Claims" : "";
      const moduleData = await moduleSearch.getModule({
        name: claim_method
      });

      if (formdata.id_str == "" || null) {
        const customerClaimData = await claimService.getClaimData({
          policy_no: formdata?.policy_no,
          status: {
            [Op.ne]: "Claim Closed",
          },
        });

        if (customerClaimData) {
          const response = commonService.response(
            0,
            message.CLAIM_IN_PROCESS,
            null,
            message.ERROR
          );
          // update apilog response 
          await commonService.updateLogsData(
            { status: 'Success',
              error_type:'Success'
            },
            { id:req.dataValues }
          );
          await commonService.updateApiLogsData(
            { response: JSON.stringify(response) },
            { id: req.dataValues}
          );
          return res.status(httpStatus.OK).json(response);
        }
        
        claim_no = await claimService.moduleEntityNum({module_name});
        (claimPayload["id_str"] = commonService.generateUserId()),
        (claimPayload["claim_number"] = claim_no),
        (claimPayload["created"] = utils.getUTCDateTime()),
        (claimPayload["created_by"] = decode.id),
        
        utils.getEncryptedJson(claimPayload);
        (response = await claimService.createClaim(claimPayload));
        response = response.dataValues;

        let claimDisablitiesPayload = await claimService.claimDisablitiesPayload(multiple_disablities,decode,response.id);
        await claimService.createClaimDisablities(claimDisablitiesPayload);

          const statusHistoryData = {
            case_id: response.id,
            case_status_id: 1,
            case_substatus_id:1,
            case_status:'New Case Request',
            case_substatus:'Draft',
            assigned_to: decode.id,
            modified: new Date(),
            modified_by: decode.id,
            source: 'WEB',
            remarks:'Claim Create'
          };
          await claimService.createStatusHistoryData(statusHistoryData);

          const basicModetrackerCreate = await claimService.createModeTrackerBasicData({
            module_id: moduleData.id,
            refid: response.id,
            whodid: decode.id,
            changedone: new Date(),
            status: "c",
            source: response.source,
          });
        
        for (const key in response) {
          const fieldData = await claimService.getFieldData({ fieldname: key });
          await claimService.createModtrackerDetailData({
            basicid: basicModetrackerCreate?.dataValues?.id,
            fieldname: fieldData?.fieldlabel ? fieldData?.fieldlabel : key,
            changedone: moment().utc().format("YYYY-MM-DD H:mm:ss"),
            prevalue: "",
            postvalue: response[key]? response[key] : "",
          });
        }
      }
      else {
        const claimData = await claimService.getClaimData({
          id_str: formdata.id_str,
        });   
        utils.getEncryptedJson(claimPayload);
        response = await claimService.updateClaimData(claimPayload, {
          id_str: formdata.id_str,
        });

        const basicModetrackerUpdate =
          await claimService.createModeTrackerBasicData({
            module_id: moduleData.id,
            refid: response.id,
            whodid: decode.id,
            changedone: new Date(),
            status: "m",
            source: response.source,
          });

        for (const key in claimData) {
          if (
            claimData.hasOwnProperty(key) &&
            claimData[key] !== response[key]
          ) {
            if (key !== "created" && key !== "modified") {
              const fieldData = await claimService.getFieldData({ fieldname: key });
              await claimService.createModtrackerDetailData({
                basicid: basicModetrackerUpdate?.dataValues?.id,
                fieldname: fieldData?.fieldlabel ? fieldData?.fieldlabel : key,
                changedone: moment().utc().format("YYYY-MM-DD H:mm:ss"),
                prevalue: claimData[key],
                postvalue: response[key],
              });
            }
          }
        }
      }
    let claim_number = response.updt_claim_number ? response.updt_claim_number : response.claim_number;
    // email trigger function
    await communicationCtrl.pushTemplateCommQueue({...req,claimNumber:claim_number});

    const statusHistoryData = {
      case_id: response.id,
      case_status_id: 1,
      case_substatus_id:2,
      case_status:'New Case Request',
      case_substatus:'Consent Pending',
      assigned_to: decode.id,
      modified: new Date(),
      modified_by: decode.id,
      source: 'WEB',
      remarks:'Bitly Link Send to Customer'
    };

    await claimService.createStatusHistoryData(statusHistoryData);
    // update apilog response 
    await commonService.updateLogsData(
      { status: 'Success',
        error_type:'Success'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        responseCode: httpStatus.OK,
        responseMessage: formdata.id_str
          ? message.CLAIM_UPDATED
          : message.CLAIM_CREATED,
        responseData: {
          claim_no: formdata.id_str ? response.claim_number : claim_no,

        },
      }) },
      { id: req.dataValues}
    );

      res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: formdata.id_str
          ? message.CLAIM_UPDATED
          : message.CLAIM_CREATED,
        responseData: {
          claim_no: formdata.id_str ? response.claim_number : claim_no,
        },
      });
    
  }catch (err) {
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
     // update api log table
     await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        responseCode: httpStatus.INTERNAL_SERVER_ERROR,
        responseMessage: err.message,
        responseData:{}
      }) },
      { id: req.dataValues}
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      responseCode: httpStatus.INTERNAL_SERVER_ERROR,
      responseMessage: err.message,
      responseData:{}
    });
  }
};

// resend customer portal bitly link
exports.resendBitlyLink = async (req,res)=>{
  try{
        const decode = req.user;
    const base_url = req.body.base_url;
    const module = req.body.module;
    claim_number = req.body.formdata.claim_number;
    const claimRow = await claimService.getClaimData({claim_number: claim_number});
    utils.getDecryptedJson(claimRow);
    const otpMobile = claimRow.updt_mobile_no ? claimRow.updt_mobile_no : claimRow.mobile_no;
    const otpEmail = claimRow.updt_email_id ? claimRow.updt_email_id : claimRow.email_id;
    const otpName = claimRow.policyholder_full_name;
    const expireTime = moment().add(process.env["CUST_BITLYLINK_EXPIRETIME_" + env], "hour").format("YYYY-MM-DD H:mm:ss");
    const currentTime = moment().format("YYYY-MM-DD H:mm:ss");

  
    //code start Bitly Link send on mail after claim creation
    const OldBitlyLinkOtpExpire = await sequelize.query(
      `UPDATE clm_otp_log INNER JOIN clm_bitly_link ON clm_bitly_link.id= clm_otp_log.record_id
       SET clm_otp_log.otp_status = "expire",clm_otp_log.modified = '`+currentTime+`'
       WHERE LOWER(clm_bitly_link.ref_module)='claims' AND clm_otp_log.otp_status = 'send' 
       AND clm_bitly_link.status='send' AND clm_bitly_link.ref_id = `+claimRow.id+``,
      {
        type: QueryTypes.UPDATE,
    });
    const oldBitlyLinkExpire = await sequelize.query(
      `UPDATE clm_bitly_link SET clm_bitly_link.status="expire", clm_bitly_link.otp_status="expire",
       clm_bitly_link.modified='`+currentTime+`'
       WHERE LOWER(clm_bitly_link.ref_module)='claims' 
       AND clm_bitly_link.status='send' AND clm_bitly_link.ref_id = `+claimRow.id+``,
      {
        type: QueryTypes.UPDATE,
    });
    //sms trigger function push to commqueue
    await communicationCtrl.pushTemplateCommQueue({...req,claimNumber:claim_number});

    // update apilog response 
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: message.BITLY_RESEND},
        { id: req.dataValues}
      );
    
    
    res.status(httpStatus.OK).json({
      responseCode: httpStatus.OK,
      responseMessage: message.BITLY_RESEND,
      responseData:{}
    });
    

  }catch(err){
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    //update log table
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        responseCode: httpStatus.INTERNAL_SERVER_ERROR,
        responseMessage: err.message,
        responseData:{}
      }) },
      { id: req.dataValues}
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      responseCode: httpStatus.INTERNAL_SERVER_ERROR,
      responseMessage: err.message,
      responseData:{}
    });
  }
};

// bitly link verify

exports.verifyBitlyLink = async (req,res)=>{
  try{
    const { module,method, formdata} = req.body;
    const moduleNm  = "Claims";
    const currentTime = moment().format("YYYY-MM-DD H:mm:ss");
    const existingLink = await claimService.getBitlyLinkData({
      token: formdata?.token,
      ref_module: moduleNm,
      status:{[Op.in]: ["send","verified"]}
    });
    //finding user id from token
    const user_id= await claimService.getuseridByTokendata(formdata.token);
   
    const user=await claimService.getuserdata(user_id[0].id);
    if (!existingLink) {
      // update apilog response 
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed',
          user_id:JSON.stringify(user_id[0].id),
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.BAD_REQUEST,
          responseMessage: message.INVALID_CUST_BITLYLINK,
          responseData :{}       
        }) },
        { id: req.dataValues}
      );

      return res.status(httpStatus.BAD_REQUEST).json({
        responseCode: httpStatus.BAD_REQUEST,
        responseMessage: message.INVALID_CUST_BITLYLINK,
        responseData :{}       
      });
    }
    else
    {
      const expireTime = moment(existingLink.expiry_datetime).format("YYYY-MM-DD H:mm:ss");
      if(moment(expireTime).isSameOrBefore(currentTime)) {
        await claimService.updateBitlyLinkData({ status: "expire" }, { id: existingLink.id });

        //update api log
        await commonService.updateLogsData(
          { status: 'Failed',
            error_type:'Failed',
            user_id:JSON.stringify(user_id[0].id),
          },
          { id:req.dataValues }
        );
        await commonService.updateApiLogsData(
          { response: JSON.stringify({
            responseCode: 0,
            responseMessage: message.EXPIRE_CUST_BITLYLINK,
            responseData :{}
          }) },
          { id: req.dataValues}
        );
        return res.status(httpStatus.OK).json({
          responseCode: 0,
          responseMessage: message.EXPIRE_CUST_BITLYLINK,
          responseData :{}
        });
      }
      else
      {
        await claimService.updateBitlyLinkData({ modified:currentTime }, { id: existingLink.id });
        const mobileNo= await commonService.maskemailmobile(user_id[0].mobileNo,'sms');
        const emailId= await commonService.maskemailmobile(user_id[0].emailId,'email');
        await commonService.updateLogsData(
          { status: 'Success',
            error_type:'Success',
            user_id:JSON.stringify(user_id[0].id),
          },
          { id:req.dataValues }
        );
        await commonService.updateApiLogsData(
          { response: JSON.stringify({
            responseCode: httpStatus.OK,
            responseMessage: message.VERIFIED_CUST_BITLYLINK,
            responseData :{}
          }) },
          { id: req.dataValues}
        );
        return res.status(httpStatus.OK).json({
          responseCode: httpStatus.OK,
          responseMessage: message.VERIFIED_CUST_BITLYLINK,
          responseData :{},
          mobileNo,
          emailId
        });
      }  
    }
  }catch(err){
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        responseCode: httpStatus.INTERNAL_SERVER_ERROR,
        responseMessage: err.message,
        responseData :{}
      }) },
      { id: req.dataValues}
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      responseCode: httpStatus.INTERNAL_SERVER_ERROR,
      responseMessage: err.message,
      responseData :{}
    });
    
  }
};

// otp send
exports.otpSend = async (req,res)=>{
  try{
    const { module,method, formdata} = req.body;
    const moduleNm  = "Claims";
    const existingLink = await claimService.getBitlyLinkData({
      token: formdata?.token,
      ref_module: moduleNm,
      status:'send'
    });
    const user_id= await claimService.getuseridByTokendata(formdata.token);

      const currentTime = moment().format("YYYY-MM-DD H:mm:ss");
      const expireTime = moment(existingLink.expiry_datetime).format("YYYY-MM-DD H:mm:ss");
      if(moment(expireTime).isSameOrBefore(currentTime)) {
        await claimService.updateBitlyLinkData({ status: "expire" }, { id: existingLink.id });
        // update apilog response 
        await commonService.updateLogsData(
          { status: 'Failed',
            error_type:'Failed',
            user_id:JSON.stringify(user_id[0].id),
          },
          { id:req.dataValues }
        );
        await commonService.updateApiLogsData(
          { response: JSON.stringify({
            responseCode: 0,
            responseMessage: message.EXPIRE_CUST_BITLYLINK,
            responseData :{}
          }) },
          { id: req.dataValues}
        );
        return res.status(httpStatus.OK).json({
          responseCode: 0,
          responseMessage: message.EXPIRE_CUST_BITLYLINK,
          responseData :{}
        });
      }
      else
      {
        await otpService.updateOtp(
          { otp_status: "expire" },
          { record_id: existingLink.id, otp_status:"send" }
        );

        //code start OTP send on mail after claim creation
        const emailData = await templateService.emailTemplate({
          template_name: "OTP Generation",
        });
        const smsData = await templateService.smsTemplate({
          template_name: "Income Protection OTP",
        });
        const claimRow = await claimService.getClaimData({id: existingLink.ref_id});
        utils.getDecryptedJson(claimRow);
        const otpMobile = claimRow.updt_mobile_no ? claimRow.updt_mobile_no : claimRow.mobile_no;
        const otpEmail = claimRow.updt_email_id ? claimRow.updt_email_id : claimRow.email_id;
        const otpName = claimRow.policyholder_full_name;

       
        const expireTimeOtp = moment().add(process.env["CUST_OTP_EXPIRETIME_" + env], "hour").format("YYYY-MM-DD H:mm:ss");
        const otp = await commonService.generateOTP();
        await otpService.createOTP({
          record_id: existingLink.id,
          templateid: emailData.id,
          record_type: "BitlyLink",
          mobile: otpMobile,
          emailid: otpEmail,
          otp:otp,
          expirytime: expireTimeOtp,
          created: currentTime,
          modified: currentTime,
        });
        await claimService.updateBitlyLinkData({ otp_status: "send"}, { id: existingLink.id })

        let templateBody = emailData?.body;
        let smsBody = smsData.template;
        const object = {
          USER_FIRSTNAME: otpName,
          OPT: otp,
        };
        for (const key in object) {
          templateBody = templateBody
            ? templateBody.replace(new RegExp(`{${key}}`, "g"), `${object[key]}`)
            : null;
            smsBody = smsBody ? smsBody.replace(new RegExp(`{${key}}`, "g"), `${object[key]}`) : null;

        }
        commonService.sendMail(otpEmail, "OTP - Customer Portal Verify", templateBody);
        if(smsBody){
          await communicationService.sendSms(otpMobile, smsBody,smsData.template_id);
        }
        //code end OTP send on mail after claim creation

        // update apilog response 
        await commonService.updateLogsData(
          { status: 'Success',
            error_type:'Success',
            user_id:JSON.stringify(user_id[0].id),
          },
          { id:req.dataValues }
        );
        await commonService.updateApiLogsData(
          { response: JSON.stringify({
            responseCode: httpStatus.OK,
            //responseMessage: message.VERIFIED_CUST_BITLYLINK,
            responseMessage: message.OTP_SEND,
            responseData :{otp:otp}
          }) },
          { id: req.dataValues}
        );
        return res.status(httpStatus.OK).json({
          responseCode: httpStatus.OK,
          //responseMessage: message.VERIFIED_CUST_BITLYLINK,
          responseMessage: message.OTP_SEND,
          responseData :{otp:otp}
        });
    }

  }catch(err){
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    // update apilog response 
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        responseCode: httpStatus.INTERNAL_SERVER_ERROR,
        responseMessage: errorMsg,
        responseData :{}
      }) },
      { id: req.dataValues}
    );
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      responseCode: httpStatus.INTERNAL_SERVER_ERROR,
      responseMessage: errorMsg,
      responseData :{}
    });
  }
};

// otp verify
exports.custOtpVerify = async (req,res) =>{
  try 
  {
    const module = req.body.module;
    const method = req.body.method;
    const token = req.body.formdata.token;
    const otp = req.body.formdata.otp;

    const moduleNm = "Claims";
    const existingLink = await claimService.getBitlyLinkData({
      token: token,
      ref_module: moduleNm,
      status:'send'
    });
    const user_id= await claimService.getuseridByTokendata(token);
    if(user_id.length >=1){
      await commonService.updateLogsData(
        { 
          user_id:JSON.stringify(user_id[0].id)
        },
        { id:req.dataValues }
      );
    }
   
    const currentTime = moment().format("YYYY-MM-DD H:mm:ss");
    const expireTimeBitly = moment(existingLink.expiry_datetime).format("YYYY-MM-DD H:mm:ss");

     
    if(moment(expireTimeBitly).isSameOrBefore(currentTime))
    {
      await claimService.updateBitlyLinkData({ status: "expire", modified:currentTime }, { id: existingLink.id });
      const existingOTP = await otpService.getExistingOtp({
        otp: otp,
        record_id: existingLink.id,
        otp_status: "send",
      });
      await otpService.updateOtp({ otp_status: "expire", modified:currentTime }, { id: existingOTP.id })

      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed',
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
				{ response: JSON.stringify({
          responseCode: 0,
          responseMessage: message.EXPIRE_CUST_BITLYLINK,
          responseData :{}
        }) },
				{ id: req.dataValues }
			);
	
      return res.status(httpStatus.OK).json({
        responseCode: 0,
        responseMessage: message.EXPIRE_CUST_BITLYLINK,
        responseData :{}
      });
    }
    else
    {
      const existingOTP = await otpService.getExistingOtp({
        otp: otp,
        record_id: existingLink.id,
        otp_status: "send",
      });
      if(!existingOTP) {
        await commonService.updateLogsData(
          { status: 'Failed',
            error_type:'Failed'
          },
          { id:req.dataValues }
        );
        await commonService.updateApiLogsData(
          { response: JSON.stringify({
            responseCode: 0,
            responseMessage: message.INVALID_OTP,
            responseData :{},
          }) },
          { id: req.dataValues }
        );
    

        return res.status(httpStatus.OK).json({
          responseCode: 0,
          responseMessage: message.INVALID_OTP,
          responseData :{},
        });
      }
      else
      {
        const expireTime = moment(existingOTP.expirytime).format("YYYY-MM-DD H:mm:ss");
        if(moment(expireTime).isSameOrBefore(currentTime)){
            await otpService.updateOtp({ otp_status: "expire",modified:currentTime }, { id: existingOTP.id })
            await commonService.updateLogsData(
              { status: 'Failed',
                error_type:'Failed'
              },
              { id:req.dataValues }
            );
            await commonService.updateApiLogsData(
              { response: JSON.stringify({
                responseCode: 0,
                responseMessage: message.OTP_EXPIRE,
                responseData :{},
              }) },
              { id: req.dataValues }
            );
            return res.status(httpStatus.OK).json({
            responseCode: 0,
            responseMessage: message.OTP_EXPIRE,
            responseData :{},
          });
        }else{
          await otpService.updateOtp({ otp_status: "verified",modified:currentTime },{ id: existingOTP.id });
          let verify_token = commonService.generateUserId();
          await claimService.updateBitlyLinkData({ status:"verified", otp_status: "verified",verify_token:verify_token,modified:currentTime }, { id: existingLink.id });
          await commonService.updateLogsData(
            { status: 'Success',
              error_type:'Success'
            },
            { id:req.dataValues }
          );
          await commonService.updateApiLogsData(
            { response: JSON.stringify({
              responseCode: httpStatus.OK,
              responseMessage: message.OTP_VERIFIED,
              responseData: {login_token:verify_token}
            }) },
            { id: req.dataValues }
          );
      
          return res.status(httpStatus.OK).json({
            responseCode: httpStatus.OK,
            responseMessage: message.OTP_VERIFIED,
            responseData: {login_token:verify_token}
          });
        }
      }
    }
  } 
  catch (err) {
    const errorMsg = err.errors ? err.errors[0].message : err.message;
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};

// claim list
exports.getClaimList = async(req,res) =>{
  try{
    const module_nm = req.body.module === "claims" ? "Claims" : "";
    const moduleData = await moduleSearch.getModule({name: module_nm});
    const module_id = moduleData.id;
    const clientProgramID = "";
    
    getClaimSubStatusData = await pickService.getClaimSubStatusByCP(clientProgramID);
    getClaimSubStatusData.push({"key": "All","value": "All","selected": true});
    getClaimStatusData= await pickService.getClaimStatus(clientProgramID);
    getClaimStatusData.push({"key": "All","value": "All","selected": true});
    let planName= await pickService.PlanName();
    planName.push({"key": "All","value": "All","selected": true});

    let keys = Object.keys(ClaimListRenderHeaderData);
    if(Object.keys(ClaimListRenderHeaderData[5]).includes("options")) 
    {
      ClaimListRenderHeaderData[5].options = await getClaimStatusData;
    }
    if(Object.keys(ClaimListRenderHeaderData[6]).includes("options")) 
    {
      ClaimListRenderHeaderData[6].options = await getClaimSubStatusData;
    }
    if(Object.keys(ClaimListRenderHeaderData[4]).includes("options")) 
    {
      ClaimListRenderHeaderData[4].options = await pickService.getUserAsPickList(req.user.role_id);
    }
    if(Object.keys(ClaimListRenderHeaderData[7]).includes("options")) 
    {
      ClaimListRenderHeaderData[7].options = await planName;
    }
    getClaimData = await claimService.getClaimList(req,module_id);
      let fieldObj = {};
      fieldObj["filters"] = [];
      fieldObj["size"] = req.body.size;
      fieldObj["page"] = req.body.page;
      //fieldObj["per_page"] = process.env["LIST_SIZE_"+env];
      fieldObj["total"] = getClaimData[1];
      fieldObj["styles"] = {};
      fieldObj["rows"] = getClaimData[0];
      fieldObj["headers"] = ClaimListRenderHeaderData;
      // update apilog response 
      await commonService.updateLogsData(
        { status: 'Success',
          error_type:'Success'
        },
        { id:req.dataValues }
      );
    
      await commonService.updateApiLogsData(
        { response: JSON.stringify({
          responseCode: httpStatus.OK,
          responseMessage: 'Claim List Data',
          responseData : fieldObj
        }) },
        { id: req.dataValues}
      );
      return res.status(httpStatus.OK).json({
        responseCode: httpStatus.OK,
        responseMessage: 'Claim List Data',
        responseData : fieldObj
      });
  }
  catch(err){
    //const errorMsg = err.errors ? err.errors[0].message : err.message;
    await commonService.updateLogsData(
      { status: 'Failed',
        error_type:'Failed'
      },
      { id:req.dataValues }
    );
    await commonService.updateApiLogsData(
      { response: JSON.stringify({
        status: "error",
        msg: errorMsg,
      }) },
      { id: req.dataValues }
    );

      return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: "error",
        msg: errorMsg,
      });
  }
};

