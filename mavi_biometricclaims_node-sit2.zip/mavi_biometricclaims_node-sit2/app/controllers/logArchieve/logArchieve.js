const { stubString } = require("lodash");
const db = require("../../model");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");
const httpStatus = require("http-status");
const variable= require('../../common/variable');
module.exports= async(req,res)=>{
    try{
        //archieve_table=["clm_api_log"];
        const archieve_table=variable;
        for(let i=0;i<archieve_table.length;i++){
            const result= await checktable(archieve_table[i]);
            if(result){
                let arc_table="clm_archieve"+(archieve_table[i]).substring(3,archieve_table[i].length);
                if(await checktable(arc_table)){
                    let sql=`insert into ${arc_table}
                    select * from ${archieve_table[i]} where DATEDIFF(CURDATE(), created)>100`;
                    await sequelize.query(sql);
                    await sequelize.query(`delete from ${archieve_table[i]} where DATEDIFF(CURDATE(), created)>100`);
                    
                }
                else{
                    await sequelize.query(`CREATE TABLE ${arc_table} like ${archieve_table[i]}`
                    );
                    let sql=`insert into ${arc_table}
                    select * from clm_api_log where DATEDIFF(CURDATE(), created)>100`;
                    await sequelize.query(sql);
                    await sequelize.query(`delete from ${archieve_table[i]} where DATEDIFF(CURDATE(), created_date)>100`);

                }
            }
        }
        return res.status(httpStatus.OK).json({
            responseCode: httpStatus.OK,
          });
    }
    catch(err){
        console.log(err);
        return res.status(500).json({
            status:"error",
            message:err.message
        })
    }
    
}
async function checktable(tablename) {
    try {
        let sql = `SHOW TABLES LIKE '${tablename}'`;
         let val= await sequelize.query(sql,{
                    type: QueryTypes.SELECT,
                  }
         );
         return val.length;
    }
     catch (err) {
        return err;
    }
}
