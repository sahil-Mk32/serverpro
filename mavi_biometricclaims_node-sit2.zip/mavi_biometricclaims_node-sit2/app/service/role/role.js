const db = require("../../model");

class RoleService {
  constructor() {}

  getRole = async (whereCondition) => {
    try {
      return await db.role.findOne({
        where: whereCondition,
      });
    } catch (error) {
      throw error;
    }
  };
}

exports.RoleService = new RoleService();