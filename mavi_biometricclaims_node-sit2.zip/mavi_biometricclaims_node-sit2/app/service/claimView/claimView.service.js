const db = require("../../model");
const moment = require("moment")
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");
const comments = db.comments;
const claim_Module = db.module;
const utils = require('../../common/utils');
const claimService = require("../../service/claim/claim.service");

exports.getSummaryFieldDataByFieldId = async (sectionFieldIds) => {
  try {
    return await sequelize.query(
      `SELECT 
        clm_field.field_id AS id,
        clm_field.type,
        clm_uitype_master.inputtype AS 'inputType',
        clm_field.fieldname AS 'name',
        clm_field.fieldlabel AS 'label',
        clm_field.mandatory AS 'required',
        clm_field.placeholder,
        clm_field.minimumlength,
        clm_field.maximumlength,
        clm_field.disabled,
        clm_field.readonly,
        clm_field.hidden,
        clm_field.pattern,
        clm_field.validations,
        clm_field.styles,
        clm_field.callbacks,
        clm_field.options
        FROM
        clm_field
            INNER JOIN
        clm_uitype_master ON clm_uitype_master.id = clm_field.uitype
        WHERE
            clm_field.field_id IN (` +
        sectionFieldIds +
        `)
        ORDER BY sequence`,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.getClaimViewSectionData = async (sectionId) => {
  try {
    return await sequelize.query(
      `SELECT  
        clm_section.type,
        clm_section.title ,
        clm_section.id,
        clm_section.content ,
        clm_section.name ,
        clm_section.displayType ,
        clm_section.styles,
        clm_section.disabled ,
        clm_section.hidden,
        clm_section.hidetoggle, 
        clm_section.expanded,
        clm_section.fields,
        clm_section.parent_section_id
        FROM 
        clm_section 
        WHERE clm_section.parent_section_id='${sectionId}';`,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.getClaimData = async (claim_id) => {
  try {
    return await sequelize.query(
      `SELECT 
        clm_claim.* from clm_claim
    WHERE
        clm_claim.claim_number = '${claim_id}';`,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.getModtrackerData = async (claim_id) => {
  try {
    return await sequelize.query(
      `SELECT 
      subquery.total_records,
       cmb.id,
    cmb.module_id,
    cmb.refid,
    cmb.whodid,
      CONCAT(cu.first_name, ' ', cu.last_name) AS name,
      CASE
          WHEN
              COUNT(cdetails.basicid) > 0
          THEN
              JSON_ARRAYAGG(JSON_OBJECT('previous_value',
                              cdetails.prevalue,
                              'current_value',
                              cdetails.postvalue,
                              'field_name',
                              cdetails.fieldname))
          ELSE '[]'
      END AS field,
      DATE_FORMAT(cmb.changedone, '%e %b %Y, %h.%i%p') AS changedone
  FROM
      clm_modtracker_basic AS cmb
          LEFT JOIN
      clm_user AS cu ON cmb.whodid = cu.id
          LEFT JOIN
      clm_modtracker_detail cdetails ON cmb.id = cdetails.basicid
          INNER JOIN
      (SELECT 
          COUNT(*) AS total_records
      FROM
          clm_modtracker_basic
      WHERE
          refid = ${claim_id}) AS subquery
  WHERE
      cmb.refid = ${claim_id}
  GROUP BY cdetails.basicid
  ORDER BY cmb.changedone DESC
  `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.commentData = async (claim_number) => {
  try {
    return await sequelize.query(
      `SELECT 
      clm_comments.id,
      clm_comments.comments AS body,
      clm_user.username,
      clm_comments.created_by AS userId,
      clm_comments.parrentid AS parentId,
      clm_comments.created As created_at
  FROM
      clm_comments
          INNER JOIN
      clm_claim ON clm_claim.id = clm_comments.ref_id
          INNER JOIN
      clm_user ON clm_user.id = clm_comments.created_by
  WHERE
      clm_claim.claim_number = '${claim_number}'
  `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.createClaimComments = async (createComments) => {
  try {
    await comments.create(createComments);
  } catch (error) {
    throw error;
  }
};

exports.getModule = async (whereCondition) => {
  try {
    return await claim_Module.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.trackClaimData = async (claim_number) => {
  try {
    return await sequelize.query(
      `SELECT 
      claim.substatus,
      user.username,
      csh.case_id,
      csh.case_status,
      csh.case_substatus,
      CONCAT(case_status,' - ',case_substatus,' ',payment_review_no) AS track_claim, 
      csh.modified_by,
      DATE_FORMAT(csh.modified, '%e %b %Y, %h.%i%p') AS modified
  FROM
      clm_claim_status_history AS csh
          INNER JOIN
      clm_claim AS claim ON claim.id = csh.case_id
          INNER JOIN
      clm_user AS user ON user.id = csh.modified_by
  WHERE
      claim.claim_number = '${claim_number}'
  `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.getClaimFormSectionData = async(req) =>{
  try{
    let fieldData  = [];
    const getClaimFormSectionData = await sequelize.query(
      `SELECT
      clm_section.id,
      clm_section.sequence,  
      clm_section.type,
      clm_section.title ,
      clm_section.name ,
      clm_section.content AS 'icon' ,
      clm_section.displayType ,
      clm_section.fields ,
      clm_section.styles ,
      clm_section.callbacks 
      
      FROM 
      clm_section 
      INNER JOIN clm_module 
      ON clm_module.id= clm_section.module_id
      WHERE 
      LOWER(clm_module.name)='claims' 
      AND clm_section.type='tab' 
      AND clm_section.page='claims_view' 
      AND clm_section.status='Active' 
      AND clm_section.deleted='0'
      ORDER BY clm_section.sequence`,
    {
        type: QueryTypes.SELECT,
    });
    for(const row of getClaimFormSectionData){
      let fieldObj = {};
      fieldObj["id"] = row.id ? row.id : '';
      fieldObj["sequence"] = row.sequence ? row.sequence : '';
      fieldObj["type"] = row.type ? row.type : '';
      fieldObj["title"] = row.title ? row.title : '';
      fieldObj["name"] = row.name ? row.name : '';
      fieldObj["content"] = row.content ? row.content : '';
      fieldObj["displayType"] = row.displayType ? row.displayType : '';
      fieldObj["fields"] = row.fields ? row.fields : '';
      fieldObj["styles"] = row.styles ? JSON.parse(row.styles) : '';
      fieldObj["callbacks"] = row.callbacks ? JSON.parse(row.callbacks) : '';
      fieldData.push(fieldObj);
    }
    return fieldData;
  }catch(err){

  }
};

exports.getClaimFormSectionHeaderData = async(req) =>{
  try{
    let fieldData  = [];
    const getClaimFormSectionData = await sequelize.query(
      `SELECT
      clm_section.id,
      clm_section.sequence,  
      clm_section.content AS 'type' ,
      clm_section.displayType ,
      clm_section.title ,
      clm_section.name ,
      clm_section.styles,
      clm_section.fields
      FROM 
      clm_section 
      INNER JOIN clm_module 
      ON clm_module.id= clm_section.module_id
      WHERE 
      LOWER(clm_module.name)='claims' 
      AND clm_section.type='header' 
      AND clm_section.page='claims_view'
      AND clm_section.status='Active' 
      AND clm_section.deleted='0'
      ORDER BY clm_section.sequence`,
    {
        type: QueryTypes.SELECT,
    });
    
    for(const row of getClaimFormSectionData){
      let fieldObj = {};
      fieldObj["id"] = row.id ? row.id : '';
      fieldObj["sequence"] = row.sequence ? row.sequence : '';
      fieldObj["type"] = row.type ? row.type : '';
      fieldObj["displayType"] = row.displayType ? row.displayType : '';
      fieldObj["title"] = row.title ? row.title : '';
      fieldObj["name"] = row.name ? row.name : '';
      fieldObj["styles"] = row.styles ? JSON.parse(row.styles) : '';
      let rowFields = await getFieldDataBySectionHeaderFieldId(req.body.id,row.fields);
      if(row.type == 'upper_header'){
        rowFields.push({"type": "dropdown","name": "dropdownicon","label": "dropdownicon","icon": "keyboard_arrow_down","target": "middle_header"});
      }
      fieldObj["fields"] = rowFields; 

      fieldData.push(fieldObj);
      
    }
    
    return fieldData;
  }catch(err){

  }
};

const setDataInFields = async(fieldData,rowData) =>{
  Object.keys(rowData[0])
  find(key => object[key] === value);
};

const getClaimColumnData = async(claim_no) => {
  const getClaimColumnRow = await sequelize.query(
    `SELECT  
    *
    FROM 
    clm_claim
    WHERE claim_number ='`+claim_no+`'`,
    {
        type: QueryTypes.SELECT,
    });
    utils.getDecryptedJson(getClaimColumnRow[0]);
    return getClaimColumnRow;
};

const getClaimColumnDataHeader = async(claim_no) => {
  const getClaimColumnRow = await sequelize.query(
    `SELECT 
    clm_claim.policy_no,
    clm_claim.policyholder_full_name,
    plan_name,
    clm_claim.benefit_period,
    clm_claim.insured_full_name,
    GROUP_CONCAT(dis.icd_code SEPARATOR ', ') as icd_code,
    clm_claim.status,
    GROUP_CONCAT(disability SEPARATOR ', ') as disability,
    clm_claim.substatus,
    clm_claim.disability_type,
    clm_claim.claim_approved_date,
    payment_due,
    clm_claim.review_due,
    clm_claim.created,
    CONCAT(u1.first_name,'  ',u1.last_name) created_by,
    clm_claim.modified,
    CONCAT(u2.first_name,'  ',u2.last_name) modified_by,
    CONCAT(u3.first_name,'  ',u3.last_name) assigned_to
    FROM clm_claim
    INNER JOIN clm_claim_disabilities dis
    ON dis.case_id = clm_claim.id
    INNER JOIN clm_user u1
    ON u1.id = clm_claim.created_by
    INNER JOIN clm_user u2
    ON u2.id = clm_claim.modified_by
    INNER JOIN clm_user u3
    ON u3.id = clm_claim.assigned_to
    WHERE clm_claim.claim_number ='`+claim_no+`'`,
    {
        type: QueryTypes.SELECT,
    });
    return getClaimColumnRow;
};

const getFieldDataBySectionHeaderFieldId = async (claim_no, sectionFieldIds) => {
  let claimData = await getClaimColumnDataHeader(claim_no);
  let fieldData  = [];
  let columnname='';
    const getFieldDataByFieldId = await sequelize.query(
      `SELECT  
      clm_field.field_id AS id,
      clm_field.type ,
      clm_field.fieldname AS 'name' ,
      clm_field.fieldlabel AS 'label',
      '' AS 'value',
      clm_field.columnname
      FROM 
      clm_field
      INNER JOIN clm_uitype_master
      ON clm_uitype_master.id = clm_field.uitype
      WHERE clm_field.field_id IN(`+sectionFieldIds+`) ORDER BY sequence`,
          {
              type: QueryTypes.SELECT,
          });
          utils.getDecryptedJson(claimData[0]);
          
         for(const row of getFieldDataByFieldId){
            let fieldObj = {};
            fieldObj["id"] = row.id ? row.id : '';
            fieldObj["type"] = row.type ? row.type : '';
            //fieldObj["type"] = "Input";
            fieldObj["name"] = row.name ? row.name : '';
            fieldObj["label"] = row.label ? row.label : '';
            if(row.type == 'multipleautocomplete'){
            fieldObj["value"] = claimData[0][row.name] ? JSON.parse(claimData[0][row.name]) : " ";
            }else{
              fieldObj["value"] = claimData[0][row.name] ? claimData[0][row.name] : " ";
            }
          
            fieldData.push(fieldObj);
        }
        
        return fieldData;
}

exports.getClaimColumnData = async(claim_no)=> {
  return getClaimColumnData(claim_no);
}

exports.getaccessWiseStatusSubStatus = async(roleid,clm_status,clm_substatus,client_program_id)=>{
  const accessWiseStatusSubStatusRow = await sequelize.query(
    `SELECT 
    picklist_data
    FROM 
    clm_role_status_module_picklist_permission
    WHERE 
    status_name = '`+clm_status+`' 
    AND substatus_name='`+clm_substatus+`'
    AND client_program_id='`+client_program_id+`'
    AND role_id = '`+roleid+`'`,
    {
        type: QueryTypes.SELECT,
    });
    return accessWiseStatusSubStatusRow;
}

exports.getApprovalHistoryList = async(req) =>{
  try{

    const claimData = await getClaimColumnData(req.body.id);
    const claimid = claimData[0]['id'];
    const ApprovalHistoryListCount = await getApprovalHistoryListCount(claimid);
    const totalApprovalHistoryListCount = ApprovalHistoryListCount[0].total_count;

    let page = parseInt(req.body.page);
    let size = parseInt(req.body.size);
    let limit_start = ((page*size) - size);
    let limit_end = size;

    const ApprovalHistoryList = await sequelize.query(
      `SELECT
      clm_claim_status_history.id,
      clm_claim_status_history.claim_disabilities_data,
      clm_claim_status_history.case_id,
      CONCAT(clm_user.first_name,' ',clm_user.last_name) AS 'user',
      DATE_FORMAT(clm_claim_status_history.modified,'%d %M %Y') AS 'date',
      TIME_FORMAT(clm_claim_status_history.modified,'%H:%i %p') AS 'time',
      remarks AS 'remarks'
      FROM clm_claim_status_history 
      INNER JOIN clm_user
      ON clm_user.id = clm_claim_status_history.modified_by 
      WHERE 
      remarks !='' 
      AND clm_claim_status_history.case_id='`+claimid+`' 
      ORDER BY clm_claim_status_history.id DESC
       LIMIT `+limit_start+`,`+limit_end+``,
        {
          type: QueryTypes.SELECT,
        });
        let dataRow = []
        for(const row of ApprovalHistoryList){
          let fieldObj = {};
          let fieldDetails = '[{"key":"disabilities_approval_history","label":"","value":{"columns":[{"key":"sr_no","value":"SNo","type":"text"},{"key":"disability","value":"Disability","type":"text"},{"key":"is_date_disability_diff_by_csr","value":"Is Date of Disability different from date reported by CSR?","type":"text"},{"key":"date_disability_as_per_review","value":"Date of Disability as per Review","type":"text"},{"key":"icd_code","value":"ICD Code","type":"text"},{"key":"icd_code_description","value":"ICD Code Description","type":"text"}],"rows":[{"disability":"Mental Illness","is_date_disability_diff_by_csr":"Yes","date_disability_as_per_review":"2024-04-01","icd_code":"A102","icd_code_description":"Typhoid fever with heart involvement","sr_no":1},{"disability":"Mental Illness","is_date_disability_diff_by_csr":"Yes","date_disability_as_per_review":"2024-04-01","icd_code":"A102","icd_code_description":"Typhoid fever with heart involvement","sr_no":2}]},"type":"formarray"}]';
          fieldObj["user"] = row.user ? row.user : '';
          fieldObj["date"] = row.date ? row.date : '';
          fieldObj["time"] = row.time ? row.time : '';
          fieldObj["remarks"] = row.remarks ? row.remarks : '';
          fieldObj["fielddetails"] = await getFormGroupListHistory('disabilities_approval_history', row.claim_disabilities_data);
          dataRow.push(fieldObj);
        }
        return [dataRow,totalApprovalHistoryListCount];
  }catch(err){
    throw error;
  }
}

const getFormGroupListHistory = async (key,rows) => {
  let fieldObj = {};
  let fieldArray = [];
  if(key == 'disabilities_approval_history')
  {
    let formArray = await getFormGroupListValue(key,rows);
    if(Object.keys(formArray).length !== 0)
    {
      fieldObj["key"] = key;
      fieldObj["label"] = "";
      fieldObj["type"] = "formarray";
      fieldObj["value"] = formArray;
      fieldArray.push(fieldObj);
    } 
  }
  return fieldArray;
}

const getFormGroupListValue = async (key,rows) => {
  let valueObj = {};
  if(key == 'disabilities_approval_history')
  {
    let columnsHeader = '[{"key":"sr_no","value":"SNo","type":"text"},{"key":"disability","value":"Disability","type":"text"},{"key":"is_date_disability_diff_by_csr","value":"Is Date of Disability different from date reported by CSR?","type":"text"},{"key":"date_disability_as_per_review","value":"Date of Disability as per Review","type":"text"},{"key":"icd_code","value":"ICD Code","type":"text"},{"key":"icd_code_description","value":"ICD Code Description","type":"text"}]';
    let dataRow = [];
    let sr_no = 1;
    let rowsData = JSON.parse(rows);
    if(rowsData){
      for (const row of JSON.parse(rows)) {
        let fieldObj = {};
        fieldObj["sr_no"] = sr_no;
        fieldObj["disability"] = row.disability,
        fieldObj["is_date_disability_diff_by_csr"] = row.is_date_disability_diff_by_csr,
        fieldObj["date_disability_as_per_review"] = (row.date_disability_as_per_review!== null && row.date_disability_as_per_review !=='') ? moment(row.date_disability_as_per_review).format("YYYY-MM-DD") : moment(row.doctor_confirmed_disability_date).format("YYYY-MM-DD"),
        fieldObj["icd_code"] = row.icd_code,
        fieldObj["icd_code_description"] = row.icd_code_description
        dataRow.push(fieldObj);
        sr_no++;
      }
      valueObj["columns"] = JSON.parse(columnsHeader);
      valueObj["rows"] = dataRow;
    }
  }
  return valueObj;
}

const getApprovalHistoryListCount = async (claimid) => {
  const ApprovalHistoryListCount = await sequelize.query(
    `SELECT
    count(clm_claim_status_history.id) as 'total_count'
    FROM clm_claim_status_history 
    INNER JOIN clm_user
    ON clm_user.id = clm_claim_status_history.modified_by 
    WHERE 
    remarks !='' 
    AND clm_claim_status_history.case_id='`+claimid+`'`,
        {
            type: QueryTypes.SELECT,
        });
       return ApprovalHistoryListCount;
};

