const db = require("../../model");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");
const userTable = db.user;
const passwordPolicy = db.passwordPolicy;
const userPasswordHistory = db.userPasswordHistory;
const userWrongPwdAttempts = db.userWrongPwdAttempts;
const loginHistory = db.loginHistory;
const userProfileRendering = require("../../uirender/userProfileRendering");
const commonService = require("../../common/utils");
const hashingService = require("../../common/hashing");
const communication = db.communication;
const user = db.user;
const userClientProgram = db.userClientProgram;
exports.getUser = async (whereCondition) => {
  try {
    return await userTable.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.updateUser = async (updateData, whereCondition) => {
  try {
     return await userTable.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};

exports.updateUserPassword = async (updateData, whereCondition) => {
  try {
    return await userTable.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};

exports.passwordCheck = async (whereCondition) => {
  try {
    return await passwordPolicy.findAll({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.clientProgramCode = async (userId) => {
  try {
    return await sequelize.query(
      `SELECT 
          clm_user.id_str,
        JSON_ARRAYAGG(clm_sales_clientprogram.clientprogram_code) AS client_code
      FROM
          clm_user
          INNER JOIN
      clm_user_clientprogram ON clm_user.id_str = clm_user_clientprogram.id_str
          LEFT JOIN
        clm_sales_clientprogram ON clm_user_clientprogram.clientprogram_id = clm_sales_clientprogram.id
        WHERE clm_user.id_str= '${userId}'
      GROUP BY clm_user.id_str
      `,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.menuData = async (userId) => {
  try {
    return await sequelize.query(
      `SELECT 
      clm_menu_navigation.name, 
      clm_role_module_access.*
  FROM
      clm_role_module_access
          INNER JOIN
      clm_module ON clm_module.id = clm_role_module_access.module_id
          INNER JOIN
      clm_user ON clm_user.role_id = clm_role_module_access.role_id
          INNER JOIN
      clm_menu_navigation ON (clm_menu_navigation.module_id = clm_role_module_access.module_id
          AND clm_menu_navigation.approval = clm_role_module_access.approval)
  WHERE
      clm_user.id = '${userId}'
  GROUP BY clm_menu_navigation.module_id`
  ,
      {
        type: QueryTypes.SELECT,
      }
    );
  } catch (error) {
    throw error;
  }
};

exports.userPasswordHistoryData = async (createOneTimeTokens) => {
  try {
    await userPasswordHistory.create(createOneTimeTokens);
  } catch (error) {
    throw error;
  }
};

exports.userWrongPwdAttemptsData = async (createOneTimeTokens) => {
  try {
    await userWrongPwdAttempts.create(createOneTimeTokens);
  } catch (error) {
    throw error;
  }
};

exports.loginHistoryData = async (createOneTimeTokens) => {
  try {
    await loginHistory.create(createOneTimeTokens);
  } catch (error) {
    throw error;
  }
};

exports.getUserName = async (whereCondition) => {
  try {
    const userData =  await userTable.findOne({
      where: whereCondition,
      raw: true,
    });
    return `${userData.first_name} ${userData.last_name}`;
  } catch (error) {
    throw error;
  }
};


exports.getMainHeaderFields = async (req) => {

  let fields;
  let userId = req.body.user_id;
  let roleId = req.user.role_id;
  if(userId !== null && userId !== '') {
    fields = (roleId == 1) ? userProfileRendering.fieldsWithoutOldPassword : userProfileRendering.fieldsWithOldPassword;
  }
  else{
    //fields = "unauthorized";
    fields = userProfileRendering.fieldsWithOldPassword;
    req.body.user_id = req.user.id_str;
  }
  return fields;
};

exports.getUserProfileData = async (whereCondition) => {
  try {
    return await userTable.findOne({
      where: whereCondition,
      attributes: ["username", "first_name", "last_name", "email", "mobile", "time_zone"],
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getprofileDetailPageFields = async (profileArr) => {
    let fields = [];
    Object.keys(profileArr).forEach(function(key) {
      let val = profileArr[key];
      
      let label = key.replace('_'," ");
      label = label.split(" ");

      for (var i = 0; i < label.length; i++) {
        label[i] = label[i].charAt(0).toUpperCase() + label[i].slice(1);
      }
      label = label.join(" ");

      let newObj = {};
      newObj["type"] = "text";
      newObj["name"] = key;
      newObj["label"] = label;
      newObj["value"] = val;
      fields.push(newObj);
    });
    return fields;
}

exports.createUserCommunication = async (subject,body,email) => {
  try {
    return await communication.create({
      type: "email",
      pid: "",
      subject: subject,
      body: body,
      to: email,
      cc: email,
      created: commonService.getUTCDateTime(),
      modified: commonService.getUTCDateTime(),
      status: "send",
      response: " ",
    }, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.createUserCommunication2 = async (subject,body,mobno) => {
  try {
    return await communication.create({
      type: "sms",
      pid: "",
      subject: subject,
      body: body,
      to: mobno,
      cc: mobno,
      created: commonService.getUTCDateTime(),
      modified: commonService.getUTCDateTime(),
      status: "send",
      response: " ",
    }, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getUserList = async (req) => {
  try {
  //const decode = req.user;
     
    let subQuery = "";
    let obj = req.body.search;
    let keys = Object.keys(obj);
    if(keys.length > 0)
    {
      for (var i = 0; i < keys.length; i++) {
        if(obj[keys[i]]!='' && obj[keys[i]] != null)
        {
          if(commonService.getAllowedEncryptedFields().includes(keys[i])) {
            obj[keys[i]] = obj[keys[i]] ? hashingService.encrypt(obj[keys[i]]) : "";
          }
          subQuery = subQuery + " AND clm_user."+keys[i]+" = '"+obj[keys[i]]+"'";
        }
      }
    }
    
    
    let subQueryOrderBy = "";
    let sort = req.body.sort;
    if(sort != null && req.body.sort.key !='' && req.body.sort.value !=''){
      subQueryOrderBy ="ORDER BY "+req.body.sort.key+" "+req.body.sort.value;
    }else{
      subQueryOrderBy ="ORDER BY clm_user.id ASC";
    }

   

    let page = parseInt(req.body.page);
    let size = parseInt(req.body.size);
    let limit_start = ((page*size) - size);
    let limit_end = size;

    const userCount = await getUserDataListCount();
    const totalUserCount = userCount[0].total_count;

    const getUserDataList = await sequelize.query(
      `SELECT 
      clm_user.id_str,
      clm_user.username,
      clm_user.status AS ustatus,
      clm_user.first_name AS first_name,
      clm_user.last_name AS last_name,
      clm_user.email,
      clm_user.mobile,
      clm_role.rolename
      FROM 
      clm_user
      INNER JOIN clm_role
      ON clm_role.id = clm_user.role_id
      WHERE clm_user.deleted = '0' AND clm_user.id != '1'
      `+subQuery+`
      `+subQueryOrderBy+`
       LIMIT `+limit_start+`,`+limit_end+``,
        {
          type: QueryTypes.SELECT,
        });
        let dataRow = [];
        for(const row of getUserDataList){
          let fieldObj = {};
          fieldObj["id_str"] = row.id_str ? row.id_str : '';
          fieldObj["username"] = row.username ? row.username : '';
          fieldObj["ustatus"] = row.ustatus ? row.ustatus : '';
          fieldObj["first_name"] = row.first_name ? row.first_name : '';
          fieldObj["last_name"] = row.last_name ? row.last_name : '';
          fieldObj["email"] = row.email ? row.email : '';
          fieldObj["mobile"] = row.mobile ? row.mobile: "";
          fieldObj["role_id"] = row.rolename ? row.rolename: "";
          fieldObj["action"] = {"create": false,"view": true,"edit": true,"delete":false};
          
          //request json decrypted
          //commonService.getDecryptedJson(fieldObj);
          
          
          dataRow.push(fieldObj);
        }
        return [dataRow,totalUserCount];
        
  } catch (error) {
    throw error;
  }
};


const getUserDataListCount = async () => {
  const userCount = await sequelize.query(
    `SELECT 
    count(clm_user.id) as 'total_count'
    FROM 
    clm_user
    WHERE
    clm_user.deleted = '0' 
    `,
    {
        type: QueryTypes.SELECT,
    });
    return userCount;
};

exports.createUser = async (createData) => {
  try {
    return await user.create(createData, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.createUserClientProgram = async (createData) => {
  try {
    return await userClientProgram.create(createData, {
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getUserClientProgram = async (whereCondition) => {
  try {
    return await userClientProgram.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.deleteUserCliData = async (whereCondition) => {
  try {
    return await userClientProgram
      .destroy({
        where: whereCondition,
        raw: true,
      })
      .then((result) => {
        if (result === 1) {
          return "Record deleted successfully";
        } else {
          return "Record not found";
        }
      });
  } catch (error) {
    throw error;
  }
};