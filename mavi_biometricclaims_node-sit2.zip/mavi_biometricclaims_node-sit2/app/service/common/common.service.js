const db = require("../../model");
const { Op } = require("sequelize");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");
const comments = db.comments;
const claim_Module = db.module;
const utils = require("../../common/utils");
const moment = require("moment");
const claimService = require("../../service/claim/claim.service");
const env = process.env.ENV.toUpperCase();
const templateService = require("../../service/template/template.service");

exports.getNextClaimPhase_ClaimStatus = async(curr_roleid,clm_curr_status,clm_curr_substatus) => {

    let clm_next_status ='';
    if(curr_roleid == 7 && clm_curr_status =='New Case Request' && clm_curr_substatus == 'Document Submitted'){
        clm_next_status = 'L1 Adjudication';
    }else if(curr_roleid == 7 && clm_curr_status =='L1 Adjudication' && clm_curr_substatus == 'Approved'){
        clm_next_status = 'L1 Adjudication';
    }else if(curr_roleid == 5 && clm_curr_status =='L1 Adjudication' && clm_curr_substatus == 'Approved'){
        clm_next_status = 'L2 Adjudication';
    }else if(curr_roleid == 5 && clm_curr_status =='L2 Adjudication' && clm_curr_substatus == 'Approved'){
        clm_next_status = 'Review';
    }else if(curr_roleid == 2 && clm_curr_status =='L2 Adjudication' && clm_curr_substatus == 'Approved'){
      clm_next_status = 'Payment';
    }else if(curr_roleid == 5 && clm_curr_status =='Payment' && clm_curr_substatus == 'Payment Disbursed'){
        clm_next_status = 'Review';
    }else if(curr_roleid == 2 && clm_curr_status =='Payment' && clm_curr_substatus == 'Payment Disbursed'){
        clm_next_status = 'Payment';
    }else if(curr_roleid == 5 && clm_curr_status =='Review' && clm_curr_substatus == 'Review Completed Insured Still Disabled'){
        clm_next_status = 'Review';
    }else if(curr_roleid == 2 && clm_curr_status =='Review' && clm_curr_substatus == 'Review Completed Insured Still Disabled'){
        clm_next_status = 'Payment';
    }else{
        clm_next_status = clm_curr_status;
    }
    return clm_next_status;
}

exports.getSubstatusIdBystatusSubstatus = async(clm_status,clm_substatus) =>{
    let case_sub_status_id = '';
    const subStatusId = await sequelize.query(
        `SELECT 
        clm_claim_sub_status.id AS case_sub_status_id
        FROM 
        clm_claim_sub_status 
        WHERE 
        pname='`+clm_status+`' 
        AND name ='`+clm_substatus+`'
        AND status='active'
        AND deleted = '0'`,
        {
            type: QueryTypes.SELECT,
        });
        if(subStatusId.length>0){
            case_sub_status_id = subStatusId[0]['case_sub_status_id'];
        }
        return case_sub_status_id;
}

exports.getStatusIdBystatus = async(clm_status) =>{
    let case_status_id = '';
    const statusId = await sequelize.query(
        `SELECT 
        clm_claim_status.id AS case_status_id
        FROM 
        clm_claim_status 
        WHERE
        name ='`+clm_status+`'
        AND status='active'
        AND deleted = '0'`,
        {
            type: QueryTypes.SELECT,
        });
        if(statusId.length>0){
            case_status_id = statusId[0]['case_status_id'];
        }
        return case_status_id;
}

exports.getPickListDataByStatusAndSubStatus = async(roleid,case_sub_status_id,client_program_id)=>{
    let picklist_data = {};
    const pickListData = await sequelize.query(
      `SELECT 
      clm_role_status_module_picklist_permission.picklist_data
      FROM 
      clm_role_status_module_picklist_permission
      WHERE 
      client_program_id='`+client_program_id+`'
      AND role_id = '`+roleid+`'
      AND case_sub_status_id = '`+case_sub_status_id+`'
      AND deleted = '0'`,
      {
          type: QueryTypes.SELECT,
      });
      if(pickListData.length >0){
        picklist_data = pickListData[0]['picklist_data'];
      }
      return picklist_data;
  }

exports.getNextAssignTo = async(client_program_id,curr_roleid,case_sub_status_id,assignto_flag) =>{
    let assignedToUser = "";

    if(assignto_flag == null || assignto_flag == '')
    {
        assignto_flag = "NA";
    }
     const assignedTo = await sequelize.query(
        `SELECT 
        clm_user.id
        FROM 
        clm_role_wise_status
        INNER JOIN clm_role
        ON clm_role.id = clm_role_wise_status.assignto_role
        INNER JOIN clm_user
        ON clm_user.id_str = clm_role.default_user_id_str
        WHERE
        clm_role_wise_status.client_program_id='`+client_program_id+`' 
        AND clm_role_wise_status.actionby_role='`+curr_roleid+`' 
        AND clm_role_wise_status.claim_sub_status_id='`+case_sub_status_id+`'
        AND clm_role_wise_status.assignto_flag='`+assignto_flag+`'
        AND clm_role_wise_status.status='active' 
        AND clm_role_wise_status.deleted='0'`,
        {
            type: QueryTypes.SELECT,
        });

        if(assignedTo.length>0){
            assignedToUser = assignedTo[0]['id'];
        }
        return assignedToUser;
  }

  exports.getClaimStatusAndSubStatusWiseEditPermession = async(module_id,roleid, client_program_id,case_sub_status_id) => {
    let write_access = 0;
    const editPermession = await sequelize.query(
        `SELECT 
        clm_role_status_module_write_permission.write_access
        FROM 
        clm_role_status_module_write_permission
        WHERE
        client_program_id='`+client_program_id+`'
        AND module_id = '`+module_id+`' 
        AND role_id = '`+roleid+`' 
        AND case_sub_status_id = '`+case_sub_status_id+`'
        AND deleted='0'`,
        {
            type: QueryTypes.SELECT,
        });
        if(editPermession.length>0){
            write_access = editPermession[0]['write_access'];
        }
        return write_access;
  }

  exports.getRoleModuleWiseModulePermession = async(client_program_id, module_id, roleid) =>{

    const modulePermession = await sequelize.query(
        `SELECT 
        *
        FROM 
        clm_role_module_access
        WHERE 
        module_id='`+module_id+`'
        AND client_program_id='`+client_program_id+`'
        AND role_id = '`+roleid+`' 
        AND deleted='0'`,
        {
            type: QueryTypes.SELECT,
        });
        return modulePermession;
  }

  exports.getRoleWiseModulePermession = async(client_program_id, roleid) =>{
    //client_program_id should be 1,2,3,4,5
    const modulePermession = await sequelize.query(
        `SELECT 
        *
        FROM 
        clm_role_module_access
        WHERE 
        client_program_id IN (`+client_program_id+`)
        AND role_id = '`+roleid+`' 
        AND deleted='0'`,
        {
            type: QueryTypes.SELECT,
        });
        return modulePermession;
  }

exports.getNextPhase = async({claimNumber, currentPhase}) => {
    try {
        let review = await db.reviewSchedule.findOne({
            where: {
                review_due_date: {
                    [Op.eq]: sequelize.literal(`(select min(review_due_date) from clm_review_schedule where review_status = 'Unassigned' and claim_number = '${claimNumber}')`), 
                },
                review_status: 'Unassigned'
            }  
        });
        let payment = await db.paymentSchedule.findOne({
            where: {
                payment_due_date: {
                    [Op.eq]: sequelize.literal(`(select min(payment_due_date) from clm_payment_schedule where payment_status = 'Open' and claim_number = '${claimNumber}')`), 
                },
                payment_status: 'Open'
            }
        });
        if (!utils.isEmpty(review) && !utils.isEmpty(payment)) {
            if (moment(review.review_due_date) <= moment(payment.payment_due_date)) {
                return 'R';
            } else {
                return 'P';
            }
        } else {
            if (!utils.isEmpty(review)) {
                return 'R';
            } else if (!utils.isEmpty(payment)) {
                return 'P';
            } else {
                return currentPhase;
            }
        }
    } catch (error) {
        throw error;
    }
}
  exports.getResendBitlyPermession = async(status,substatus) => {
    if(status == 'New Case Request' && (substatus == 'Draft' || substatus == 'Consent Pending')){
        isBitlyPermession = 1;
    }else{
        isBitlyPermession = 0
    }
    return isBitlyPermession;
  }

  exports.claimStatusBasedEmail = async () => {
    try {
      return await sequelize.query(
        `    
        SELECT 
    cbl.bitly_link, cc.policyholder_full_name, cc.email_id, cc.assigned_to as roleid, cc.id as caseid, cet.body, cet.id as templateID, cc.assigned_to as roleid, 
      cc.plan_name, cc.claim_number
FROM
    clm_claim AS cc
        INNER JOIN
    clm_bitly_link AS cbl ON cbl.ref_id = cc.id
    INNER JOIN
    clm_user AS user ON user.id = cc.assigned_to
        INNER JOIN
    clm_claim_sub_status AS css ON CONVERT( cc.status USING UTF8MB4) = CONVERT( css.pname USING UTF8MB4)
        AND cc.substatus  = css.name 
        INNER JOIN
    clm_email_template AS cet ON cet.case_substatus_id = css.id
    
WHERE
    TIMESTAMPDIFF(HOUR, cc.modified, NOW()) > ${
      process.env["TIME_DIFFERENCE_" + env]
    }
        AND (cc.substatus = 'Consent Pending'
        OR cc.substatus = 'Document Pending')
          `,
        {
          type: QueryTypes.SELECT,
        }
      );
    } catch (error) {
      throw error;
    }
  };

  exports.openStatusSendMail = async (data) => {
    try {
      const claim = await claimService.getClaimData({ id: data.caseid });

      const getPaymentData = await communicationService.getPaymentSchedule(
        claim.claim_number
      );
      const docReqEmailData = await templateService.emailTemplate({
        id: data.templateid,
      });
      let docReqTemplateBody = docReqEmailData?.body;

      const object = {
        POLICY_HOLDER_NAME: data.data.SUBJECT.CUSTOMER_NAME,
      };

      if (data.bitly_url) {
        object["CLAIM_INITIATED_URL"] = data.bitly_url;
      }

      if (data.templateid == 10) {
        object["POLICY_NUMBER"] = claim.policy_no;
        object["CLAIM_AMOUNT"] = claim.claimed_amount;
        object["PAYMENT_SCHEDULED"] = JSON.stringify(getPaymentData[0]);
      }

      if (data.templateid == 11) {
        object["ACCOUNT_NO"] = claim?.account_no;
        object["PAYMENT_DATE"] = getPaymentData[0].payment_date;
        object["UTR_NO"] = getPaymentData[0].utr_no;
      }

      for (const field in object) {
        docReqTemplateBody = docReqTemplateBody
          ? docReqTemplateBody.replace(
              new RegExp(`{${field}}`, "g"),
              `${object[field]}`
            )
          : null;
      }

      await utils.sendMail(
        data.BODY.EMAIL_ID,
        docReqEmailData.subject,
        docReqTemplateBody
      );
      return { subject: docReqEmailData.subject, body: docReqTemplateBody };
    } catch (error) {
      throw error;
    }
  };

  exports.getSubstatus = async (clm_status, clm_substatus) => {
    let case_sub_status = {};
    const subStatus = await sequelize.query(
      `SELECT 
        clm_claim_sub_status.name AS case_sub_status_name
        FROM 
        clm_claim_sub_status 
        WHERE 
        pname='` +
        clm_status +
        `' 
        AND name ='` +
        clm_substatus +
        `'
        AND status='active'
        AND deleted = '0'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (subStatus.length > 0) {
      case_sub_status["case_sub_status_name"] =
        subStatus[0]["case_sub_status_name"];
    }
    return case_sub_status;
  };

  