const db = require("../../model");
const onetimeTokenTable = db.oneTimeToken;

exports.saveToken = async (createOneTimeTokens) => {
  try {
    await onetimeTokenTable.create(createOneTimeTokens);
  } catch (error) {
    throw error;
  }
};

exports.getOneTimeToken = async (whereCondition) => {
  try {
    return await onetimeTokenTable.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};


exports.updateOneTimeToken = async (updateData, whereCondition) => {
  try {
    await onetimeTokenTable.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};