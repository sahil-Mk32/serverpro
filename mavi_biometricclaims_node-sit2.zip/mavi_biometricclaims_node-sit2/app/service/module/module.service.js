const { Op, fn, col } = require("sequelize");
const db = require("../../model");
const sequelize = db.sequelize;

exports.getModuleByName = async (name) => {
  try {
    return await db.module.findOne({
      where: {
        columnWithFunction: sequelize.where(fn('LOWER', col('module')), '=', name),
      }
    });
  } catch (error) {
    throw error;
  }
};
