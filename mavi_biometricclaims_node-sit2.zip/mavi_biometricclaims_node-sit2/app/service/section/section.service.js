const { Op, fn, col } = require("sequelize");
const db = require("../../model");
const sequelize = db.sequelize;

class SectionService {
  constructor() {}

  async getAllSection(whereCondition) {
    try {
      return await db.claimSection.findAll({
        where: whereCondition,
      });
    } catch (error) {
      throw error;
    }
  }
}

exports.SectionService = new SectionService();
