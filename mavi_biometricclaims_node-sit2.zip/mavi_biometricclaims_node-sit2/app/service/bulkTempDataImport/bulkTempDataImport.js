const db = require("../../model");
class BulkTempDataImport {
  constructor() {}

  createBulkTempDataImport = async (data) => {
    try {
      return await db.bulkTempDataImport.create(data);
    } catch (error) {
      throw error;
    }
  };

  getBulkTempDataImportCoundBYJodId = async ({job_id}) => {
    try {
      return await db.bulkTempDataImport.count({
        where: {
          job_id,
        }
      });
    } catch (error) {
      throw error;
    }
  };

  getBulkTempDataImportList = async (whereCondition) => {
    try {
      return await db.bulkTempDataImport.findAll({
        where: whereCondition,
      });
    } catch (error) {
      throw error;
    }
  }

  updateBulkTempImport = async (data, whereCondition) => {
    try {
      return await db.bulkTempDataImport.update(
        data, 
        {
          where: whereCondition,
        }
      );
    } catch (error) {
      throw error;
    }
  }
}

exports.BulkTempDataImport = new BulkTempDataImport();
