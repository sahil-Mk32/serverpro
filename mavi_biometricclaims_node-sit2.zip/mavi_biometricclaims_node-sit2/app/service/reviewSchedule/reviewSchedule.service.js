const { Op } = require("sequelize");
const db = require("../../model");
const moment = require("moment");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");

exports.createReview = async (data) => {
  try {
    return await db.reviewSchedule.create(data);
  } catch (error) {
    throw error;
  }
};

exports.getReviewList = async ({ claimNumber }) => {
  try {
    return await db.reviewSchedule.findAll({
      order: [
        ['id', 'ASC']
      ],
      attributes: [
        "id",
        ["review_number", "review_id"],
        "review_due_date",
        "actual_review_date",
        "review_done_by",
        "tat",
        "review_status",
      ],
      where: {
        claim_number: {
          [Op.eq]: claimNumber,
        },
      },
      include: [
        {
          model: db.picklistReviewMode,
          attributes: [["name", "mode_review"]],
        },
        /* {
          model: db.claimSubStatus,
          attributes: [["name", "status"]],
        }, */
      ],
    });
  } catch (error) {
    throw error;
  }
};

exports.getReviewListCount = async ({ claimNumber }) => {
  try {
    return await db.reviewSchedule.count({
      where: { claim_number: claimNumber },
    });
  } catch (error) {
    throw error;
  }
};

/* exports.getReview= async (whereCondition) => {
  try {
    return await db.reviewSchedule.findOne({
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
}; */

exports.getReview = async ({reviewScheduleAttributes = null, picklistReviewModeAttributes = null, whereCondition = null}) => {
  try {
    let config = {};
    if (reviewScheduleAttributes) {
      config.attributes = reviewScheduleAttributes;
    }
    if (picklistReviewModeAttributes) {
      config.include = {
        model: db.picklistReviewMode,
        required: false,
        attributes: picklistReviewModeAttributes,
      };
    }
    if (whereCondition) {
      config.where = whereCondition;
    }
    return await db.reviewSchedule.findOne(config);    
  } catch (error) {
    throw error;
  } 
}

exports.updateReview = async (data, whereCondition) => {
  try {
    return await db.reviewSchedule.update(
      data, 
      {
        where: whereCondition,
      }
    );
  } catch (error) {
    throw error;
  }
}

exports.getActualNoReview = (req) => {
  let number = 0;
  let reviewInterval = req.body.review_frequency_in_days;
  for (const reviewIntervalKey in reviewInterval) {
    let review_due_date = moment(req.body.claim_approved_date).add(reviewInterval[reviewIntervalKey], "d").format("YYYY-MM-DD") ;
    if(moment(review_due_date) >= moment(req.body.payment_end_date))
    {
      return number;
    }
    number++;
  }
}

exports.getUpcomingReviewSchedule = async (claimNo) => {
  const paymentData = await sequelize.query(
    `SELECT 
    id,review_number,claim_number,review_due_date
    FROM 
    clm_review_schedule
    WHERE
    deleted = '0' AND claim_number IN ('`+claimNo+`') 
    AND review_status NOT IN ('Review Completed Insured Recovered','Review Completed Insured Still Disabled') 
    ORDER BY id ASC LIMIT 1`,
    {
        type: QueryTypes.SELECT,
    });
    return paymentData;
};