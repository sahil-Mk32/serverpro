const { Op, fn, col } = require("sequelize");
const db = require("../../model");
const sequelize = db.sequelize;

class FieldService {
  constructor() {}

  async getFieldsByIds({fieldTableAttributes, uiTableAttributes, sectionFieldIds}) {
    try {
      return await db.field.findAll({
        attributes: fieldTableAttributes,
        order: [
          ['sequence', 'ASC']
      ],
        where: {
          field_id: {
            [Op.in]: sectionFieldIds.split(","),
          },
        },
        include: {
          model: db.uiType,
          required: true,
          attributes: uiTableAttributes,
        },
      });
    } catch (error) {
      throw error;
    }
  }
}

exports.FieldService = new FieldService();
