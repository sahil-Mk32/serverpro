const db = require("../../model");
const sequelize = db.sequelize;
const { Op } = require("sequelize");
const otpLogTable = db.otpLog;

exports.createOTP = async (createData) => {
  try {
    await otpLogTable.create(createData);
  } catch (error) {
    throw error;
  }
};

exports.getExistingOtp = async (whereCondition) => {
  try {
    return await otpLogTable.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.getExistingAllOtp = async (whereCondition) => {
  try {
    return await otpLogTable.findAll({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.updateOtp = async (updateData, whereCondition) => {
  try {
    return await otpLogTable.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};

exports.updateStatus = async (updateData, whereCondition) => {
  try {
    await otpLogTable.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};
