const db = require("../../model");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");

exports.getPickListAllData = async (picklistFieldName, pickilistLimit=1000) => {
    let picklistTablenm = "clm_picklist_"+picklistFieldName;
    let fieldData  = [];
      const pickListData = await sequelize.query(
        `SELECT 
        NAME AS 'key',
        NAME AS 'value',
        FALSE AS 'selected'
        FROM 
        `+picklistTablenm+`
        WHERE STATUS='active' AND deleted=0 limit `+pickilistLimit+``,
            {
                type: QueryTypes.SELECT,
            });
        pickListData.forEach((row) => {
            let fieldObj = {};
            fieldObj["key"] = row.key ? row.key : '';
            fieldObj["value"] = row.value ? row.value : '';
            fieldObj["selected"] = row.selected === 1 ? true : false;
            fieldData.push(fieldObj);
        });
        return fieldData;
  }

  exports.getPickListIcdCodeAllData = async (picklistFieldName,fieldvalue = null) => {
    if(fieldvalue == null){
      SubQuery = "";
    }else{
      SubQuery = "AND name LIKE '%"+fieldvalue+"%'";
    }
    let picklistTablenm = "clm_picklist_"+picklistFieldName;
    let fieldData  = [];
      const pickListData = await sequelize.query(
        `SELECT 
        NAME AS 'key',
        NAME AS 'value',
        FALSE AS 'selected'
        FROM 
        `+picklistTablenm+`
        WHERE STATUS='active' AND deleted=0 `+SubQuery+` ORDER BY name ASC LIMIT 10`,
            {
                type: QueryTypes.SELECT,
            });
        pickListData.forEach((row) => {
            let fieldObj = {};
            fieldObj["key"] = row.key ? row.key : '';
            fieldObj["value"] = row.value ? row.value : '';
            fieldObj["selected"] = row.selected === 1 ? true : false;
            fieldData.push(fieldObj);
        });
        return fieldData;
  }
  
  exports.getPickListSingleData = async (picklistFieldName,fieldvalue = null) => {
    let SubQuery = "AND name = '"+fieldvalue+"'";
    let picklistTablenm = "clm_picklist_"+picklistFieldName;
    const pickListData = await sequelize.query(
      `SELECT 
      *
      FROM 
      `+picklistTablenm+`
      WHERE STATUS='active' AND deleted=0 `+SubQuery+` ORDER BY name ASC LIMIT 1`,
          {
              type: QueryTypes.SELECT,
          });
      return pickListData;
  }

  exports.PlanName = async () => {
    let fieldData  = [];
    
      const pickListData = await sequelize.query(
        `SELECT 
        plan_name AS 'key',
        plan_name AS 'value',
        FALSE AS 'selected'
        FROM 
        clm_sales_plan
        WHERE plan_status='Active' AND deleted=0 `,
            {
                type: QueryTypes.SELECT,
            });
        pickListData.forEach((row) => {
            let fieldObj = {};
            fieldObj["key"] = row.key ? row.key : '';
            fieldObj["value"] = row.value ? row.value : '';
            fieldObj["selected"] = row.selected === 1 ? true : false;
            fieldData.push(fieldObj);
        });
        return fieldData;
  }
  exports.getClaimStatus = async (pid = null, condition = '') => {
    let fieldData  = [];
    
      const pickListData = await sequelize.query(
        `SELECT 
        name AS 'key',
        name AS 'value',
        FALSE AS 'selected'
        FROM 
        clm_claim_status
        WHERE STATUS='active' AND deleted=0 ${condition} GROUP BY name`,
            {
                type: QueryTypes.SELECT,
            });
        pickListData.forEach((row) => {
            let fieldObj = {};
            fieldObj["key"] = row.key ? row.key : '';
            fieldObj["value"] = row.value ? row.value : '';
            fieldObj["selected"] = row.selected === 1 ? true : false;
            fieldData.push(fieldObj);
        });
        return fieldData;
  }
  exports.getClaimSubStatusByCP = async (pid = null, condition = '') => {
    let fieldData  = [];
    
      const pickListData = await sequelize.query(
        `SELECT 
        name AS 'key',
        name AS 'value',
        FALSE AS 'selected'
        FROM 
        clm_claim_sub_status
        WHERE STATUS='active' AND deleted=0 ${condition} GROUP BY name`,
            {
                type: QueryTypes.SELECT,
            });
        pickListData.forEach((row) => {
            let fieldObj = {};
            fieldObj["key"] = row.key ? row.key : '';
            fieldObj["value"] = row.value ? row.value : '';
            fieldObj["selected"] = row.selected === 1 ? true : false;
            fieldData.push(fieldObj);
        });
        return fieldData;
  }

  exports.getRoleList = async () => {
    let fieldData  = [];
      const roleListData = await sequelize.query(
        `SELECT 
        id AS 'key',
        rolename AS 'value',
        FALSE AS 'selected'
        FROM 
        clm_role
        WHERE status='active' AND deleted=0`,
            {
                type: QueryTypes.SELECT,
            });
            roleListData.forEach((row) => {
            let fieldObj = {};
            fieldObj["key"] = row.key ? row.key : '';
            fieldObj["value"] = row.value ? row.value : '';
            fieldObj["selected"] = row.selected === 1 ? true : false;
            fieldData.push(fieldObj);
        });
        return fieldData;
  }

  exports.getClientProgramData = async () => {
    let fieldData  = [];
      const roleListData = await sequelize.query(
        `SELECT 
        id AS 'key',
        program_name AS 'value',
        FALSE AS 'selected'
        FROM 
        clm_sales_clientprogram
        WHERE client_program_status='active' AND deleted=0`,
            {
                type: QueryTypes.SELECT,
            });
            roleListData.forEach((row) => {
            let fieldObj = {};
            fieldObj["key"] = row.key ? row.key : '';
            fieldObj["value"] = row.value ? row.value : '';
            fieldObj["selected"] = row.selected === 1 ? true : false;
            fieldData.push(fieldObj);
        });
        return fieldData;
  }

  exports.getUserAsPickList = async (role_id) => {
    if(role_id == 1 || role_id == 9){
      listQuery = "";
      }else{
        listQuery = " AND clm_user.role_id = '"+role_id+"'";
      }
      let fieldData  = [];
      const roleListData = await sequelize.query(
        `SELECT 
        id AS 'key',
        CONCAT(clm_user.first_name,' ',clm_user.last_name) AS 'value',
        FALSE AS 'selected'
        FROM 
        clm_user
        WHERE deleted=0`+listQuery,
            {
                type: QueryTypes.SELECT,
            });
            roleListData.forEach((row) => {
            let fieldObj = {};
            fieldObj["key"] = row.key ? row.key : '';
            fieldObj["value"] = row.value ? row.value : '';
            fieldObj["selected"] = row.selected === 1 ? true : false;
            fieldData.push(fieldObj);
        });
        return fieldData;
  }

