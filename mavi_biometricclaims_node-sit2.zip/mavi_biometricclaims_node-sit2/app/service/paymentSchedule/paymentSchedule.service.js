const db = require("../../model");
const commonService = require("../../service/common/common.service");
const reviewScheduleService = require("../../service/reviewSchedule/reviewSchedule.service");
const sequelize = db.sequelize;
const { QueryTypes } = require("sequelize");
const paymentSchedule = db.paymentSchedule;
const moment = require("moment");

// to insert data into payment_schedule table
exports.createPayment = async (createData) => {
  try {
    return await paymentSchedule.create(createData);
  } catch(error) {
    throw error
  }
};

// to select data from payment_schedule table
exports.getPaymentList = async (req, claimDetail=null,moduleId=null) => {
  try {
    let claimNo = req.body.id;
    let method = req.body.method;
    let subQuery ="";
    if(method == 'completed_payment'){
      subQuery += " AND payment_status ='Payment Disbursed' ";
    }
    else if(method == 'upcoming_payment'){
      subQuery += " AND payment_status !='Payment Disbursed' ";
    }
    let firstEditable = 1;
    let page = parseInt(req.body.page);
    let size = parseInt(req.body.size);
    let limit_start = ((page*size) - size);
    let limit_end = size;

    // check module edit permission
    //let moduleEditPermission = await commonService.getRoleModuleWiseModulePermession(claimDetail.client_program_id,moduleId,req.user.role_id);
    
    // check status_wise edit permission
    const subStatusId = await commonService.getSubstatusIdBystatusSubstatus(claimDetail.status,claimDetail.substatus); 
    let editPermission = await commonService.getClaimStatusAndSubStatusWiseEditPermession(moduleId,req.user.role_id,claimDetail.client_program_id,subStatusId);
    editPermission = editPermission === 1 ? true : false;
    
    const getUpcomingReview = await reviewScheduleService.getUpcomingReviewSchedule(claimNo);

    const paymentCount = await getPaymentDataListCount(claimNo,subQuery);
    const totalPaymentCount = paymentCount[0].total_count;
    const getPaymentDataList = await sequelize.query(
        `SELECT 
        payment_number,amount,DATE_FORMAT(payment_due_date,'%d %M %Y') AS payment_due_date,
        utr_no, bank_name,tat,DATE_FORMAT(payment_date,'%d %M %Y') AS payment_date,
        payment_status
        FROM 
        clm_payment_schedule
        WHERE
        deleted = '0' 
        AND claim_number  IN ('`+claimNo+`')
        `+subQuery+` ORDER BY id ASC
        LIMIT `+limit_start+`,`+limit_end+``,
        {
          type: QueryTypes.SELECT,
        });
        let dataRow = []
        for(const row of getPaymentDataList){
          let fieldObj = {};
          if(editPermission && row.payment_status != 'Payment Disbursed' && firstEditable == 1){
            fieldObj["action"] = (getUpcomingReview[0]) ? ((moment(getUpcomingReview[0].review_due_date) <= moment(row.payment_due_date)) ? {"edit": false} : {"edit": true}) : {"edit": true}
            firstEditable++
          }
          else{
            fieldObj["action"] = {"edit": false};
          }
          fieldObj["payment_number"] = row.payment_number ? row.payment_number : '';
          fieldObj["amount"] = row.amount ? row.amount : '';
          fieldObj["payment_due_date"] = row.payment_due_date ? row.payment_due_date : '';
          fieldObj["utr_no"] = row.utr_no ? row.utr_no : '';
          fieldObj["bank_name"] = row.bank_name ? row.bank_name : '';
          fieldObj["payment_date"] = row.payment_date ? row.payment_date: "";
          fieldObj["tat"] = (row.payment_status=='Payment Disbursed')?(moment(row.payment_date).diff(row.payment_due_date, "days")) : (moment(row.payment_due_date).diff(moment(), "days")) +' Days';
          fieldObj["status"] = row.payment_status ? row.payment_status: "-";
          dataRow.push(fieldObj);
        }
        return [dataRow,totalPaymentCount];
  } catch (error) {
    throw error;
  }
};
  
const getPaymentDataListCount = async (claimNo,sqlQuery) => {
  const paymentCount = await sequelize.query(
    `SELECT 
    count(1) as 'total_count'
    FROM 
    clm_payment_schedule
    WHERE
    deleted = '0' 
    AND claim_number IN ('`+claimNo+`') `+sqlQuery+``,
    {
        type: QueryTypes.SELECT,
    });
    return paymentCount;
};

exports.getPaymentScheduleData = async (whereCondition) => {
  try {
    return await paymentSchedule.findOne({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};
exports.getAllPaymentScheduleData = async (whereCondition) => {
  try {
    return await paymentSchedule.findAll({
      where: whereCondition,
      raw: true,
    });
  } catch (error) {
    throw error;
  }
};

exports.updatePayment = async (updateData, whereCondition) => {
  try {
     await paymentSchedule.update(updateData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};

exports.getUpcomingPaymentSchedule = async (claimNo) => {
  const paymentData = await sequelize.query(
    `SELECT 
    id,payment_number,claim_number,payment_due_date
    FROM 
    clm_payment_schedule
    WHERE
    deleted = '0' AND claim_number IN ('`+claimNo+`') 
    AND payment_status != 'Payment Disbursed' ORDER BY id ASC LIMIT 1`,
    {
        type: QueryTypes.SELECT,
    });
    return paymentData;
};