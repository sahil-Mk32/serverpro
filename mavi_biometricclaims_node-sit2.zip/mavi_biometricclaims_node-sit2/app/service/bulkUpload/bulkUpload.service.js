const db = require("../../model");
const { QueryTypes } = require("sequelize");
const sequelize = db.sequelize;
const utils = require("../../common/utils");

class BulkUploadService {
  constructor() {}

  getPaymentBulkUploadFormat = async () => {
    try {
      return await db.paymentSchedule.findAll({
        attributes: [
          [db.sequelize.literal("null"), "Claim Number"],
          [db.sequelize.literal("null"), "Payment Number"],
          [db.sequelize.literal("null"), "UTR number"],
          [db.sequelize.literal("null"), "Bank Name"],
          [db.sequelize.literal("null"), "Bank Branch Code"],
          [db.sequelize.literal("null"), "Account Number"],
          [db.sequelize.literal("null"), "Account Holder Name"],
          [db.sequelize.literal("null"), "Payment Date"],
          [db.sequelize.literal("null"), "Amount"],
          [db.sequelize.literal("null"), "Remark"],
        ],
        limit: 1,
      });
    } catch (error) {
      throw error;
    }
  };

  getPaymentBulkUploadFormatWithData = async () => {
    let fieldData  = [];
    const getPaymentData = await sequelize.query(
      `SELECT 
      clm_p.claim_number,
      clm_p.payment_number,
      clm_p.payment_serial,
      clm_p.payment_due_date,
      clm_p.amount,
      clm.account_holder_name,
      clm.updt_account_no,
      clm.updt_bank_name,
      clm.updt_branch_code
      FROM 
      clm_payment_schedule clm_p
      INNER JOIN clm_claim clm
      ON clm_p.claim_number = clm.claim_number
      WHERE LOWER(clm_p.payment_status) != 'payment disbursed'
      ORDER BY clm_p.id ASC LIMIT 1000;`,
      {
          type: QueryTypes.SELECT,
      });

      
      for(const row of getPaymentData)
      {
        let fieldObj = {};
        
        utils.getDecryptedJson(row);

        fieldObj["Claim Number"] = row.claim_number;
        fieldObj["Payment Number"] = row.payment_number;
        fieldObj["Payment Serial"] = row.payment_serial;
        fieldObj["Payment Due Date"] = row.payment_due_date;
        fieldObj["Amount"] = row.amount;
        fieldObj["Account Holder Name"] = row.account_holder_name;
        fieldObj["Bank Account Number"] = row.updt_account_no;
        fieldObj["Bank Name"] = row.updt_bank_name;
        fieldObj["Bank/Branch Code"] = row.updt_branch_code;
        fieldObj["UTR Number"] = '';
        fieldObj["Payment Date"] = '';
        fieldObj["Payment Status"] = '';
        fieldObj["Remarks"] = '';

        fieldData.push(fieldObj);
    };
    return fieldData;
  };
}


exports.BulkUploadService = new BulkUploadService();

