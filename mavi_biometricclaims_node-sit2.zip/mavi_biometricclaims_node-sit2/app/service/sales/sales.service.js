exports.salesMasterUpsert = async (model, upsertData, whereCondition) => {
  try {
    return await model.upsert(upsertData, {
      where: whereCondition,
    });
  } catch (error) {
    throw error;
  }
};
