const headers =  [
  {
    "key": "act",
    "value": "Action",
    "type": "text",
    "align":"left"
  },
  {
    "key": "action_by",
    "value": "Action By",
    "type": "text",
    "align":"left"
  },
  {
    "key": "action_done_on",
    "value": "Action Done On",
    "type": "text",
    "align":"left"
  },
  {
    "key": "action",
    "value": "",
    "type": "dropdown",
    "action": "button",
    "icon": "keyboard_arrow_down",
    "options": [
      {
        "key": "action",
        "type": "details",
        "icon": "keyboard_arrow_down"
      }
    ]
  }
]

const Historycolumns = [
  {
    "key": "field_name",
    "value": "Field Name",
    "type": "text"
  },
  {
    "key": "previous_value",
    "value": "Previous Value",
    "type": "text"
  },
  {
    "key": "current_value",
    "value": "Current Value",
    "type": "text"
  }
]
 
module.exports = {headers, Historycolumns};