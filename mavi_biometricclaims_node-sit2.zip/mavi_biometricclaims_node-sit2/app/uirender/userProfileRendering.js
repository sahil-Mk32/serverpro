
const profileFormStyle = { 
		id: "userDetails",
		class: ["dynmaic-form"]
};

const profileFormGroup = (getprofileDetailPageFields) => [{
  "type": "accordian",
  "title": "Personal Information",
  "name": "personal_information",
  "styles": {
    "css": {
      "backgroundColor": "#FFFFFF;",
      "marginBottom": "15px",
      "fontWeight": "500",
      "fontSize": "14px"
    }
  },
  "disabled": false,
  "hidden": false,
  "hidetoggle": false,
  "expanded": true,
  "is_profile_image": true,
  "profile_image": "",
  "fields": getprofileDetailPageFields
}];

const profileMainHeader = (fields) => [{
  "type": "button",
  "disabled": false,
  "hidden": false,
  "inputType": "popup",
  "name": "change_password",
  "label": "Change Password",
  "icon": "vpn_key",
  "styles": {
    "color": "primary",
    "css": {
      "backgroundColor": "#f1b138"
    }
  },
  "formgroups": {
    "type": "formgroup",
    "inputType": "popupform",
    "displayType": "default",
    "fields": fields,
    "actions": {
      "type": "button",
      "name": "action",
      "inputType": "button",
      "displayType": "default",
      "styles": [],
      "options": [{
        "type": "button",
        "name": "submit_button",
        "inputType": "submit",
        "label": "Submit",
        "icon": "",
        "disabled": false,
        "callbacks": [{
          "method": "user_change_password",
          "action": "api/user/changepassword",
          "type": "submit",
          "fieldData": null
        }],
        "action": "submit",
        "styles": {
          "color": "primary",
          "css": {
            "background": "#39b54a"
          }
        }
      }, {
        "type": "button",
        "name": "cancel_button",
        "inputType": "cancel",
        "label": "Cancel",
        "icon": "",
        "disabled": false,
        "callbacks": [],
        "action": "closeDialog",
        "styles": {
          "color": "primary",
          "css": {
            "background": "#a3a3a3"
          }
        }
      }]
    }
  },
  "callbacks": [],
  "action": "change_password"
}];

const fieldsWithOldPassword = [
  {
    "id": 1,
    "type": "input",
    "inputType": "password",
    "name": "old_password",
    "label": "Password",
    "required": true,
    "value": null,
    "placeholder": "Enter Old Password",
    "minlength": 0,
    "maxlength": 32,
    "readonly": false,
    "disabled": false,
    "hidden": false,
    "pattern": null,
    "isPasswordValidation": false,
    "styles": {
      "appearance": "outline",
      "class": ["full-width", "col1", "input-textbox"]
    },
    "validations": [{
      "name": "required",
      "validator": "required",
      "message": "Password Required"
    }],
    "callbacks": []
  },
  {
    "id": 2,
    "type": "input",
    "inputType": "password",
    "name": "current_password",
    "label": "New Password",
    "required": true,
    "value": null,
    "placeholder": "Enter New Password",
    "minlength": 8,
    "maxlength": 32,
    "readonly": false,
    "disabled": false,
    "hidden": false,
    "pattern": null,
    "isPasswordValidation": true,
    "styles": {
      "appearance": "outline",
      "class": ["full-width", "col1", "input-textbox"]
    },
    "validations": [{
      "name": "required",
      "validator": "required",
      "message": ""
    }, {
      "name": "hasSpace",
      "validator": "hasSpace",
      "message": "Password should not contain space!"
    }, {
      "name": "minlength",
      "validator": "minlength",
      "message": "Password length must be between 8-32 Character!"
    }, {
      "name": "maxlength",
      "validator": "maxlength",
      "message": ""
    }, {
      "name": "hasNumber",
      "validator": "hasNumber",
      "message": "Password must contain at least 1 number!"
    }, {
      "name": "hasCapitalCase",
      "validator": "hasCapitalCase",
      "message": "Password must contain at least 1 in Capital letter!"
    }, {
      "name": "hasSmallCase",
      "validator": "hasSmallCase",
      "message": "Password must contain at least 1 in Small letter!"
    }, {
      "name": "hasSpecialCharacters",
      "validator": "hasSpecialCharacters",
      "message": "Passowrd must contain at least 1 Special Character!"
    }],
    "callbacks": []
  },
  {
    "id": 3,
    "type": "input",
    "inputType": "password",
    "name": "confirm_current_password",
    "label": "Confirm New Password",
    "required": true,
    "value": null,
    "placeholder": "Enter Confirm New Password",
    "minlength": 8,
    "maxlength": 32,
    "readonly": false,
    "disabled": false,
    "hidden": false,
    "pattern": null,
    "isPasswordValidation": false,
    "styles": {
      "appearance": "outline",
      "class": ["full-width", "col1", "input-textbox"]
    },
    "validations": [{
      "name": "required",
      "validator": "required",
      "message": "Confirm New Password is required"
    }, {
      "name": "minlength",
      "validator": "minlength",
      "message": "Password length must be between 8-32 Character!"
    }, {
      "name": "maxlength",
      "validator": "maxlength",
      "message": ""
    }, {
      "name": "mustMatch",
      "validator": "mustMatch",
      "message": "New Password & Confirm New Password not match"
    }],
    "callbacks": []
}];

const fieldsWithoutOldPassword = [
  {
    "id": 2,
    "type": "input",
    "inputType": "password",
    "name": "current_password",
    "label": "New Password",
    "required": true,
    "value": null,
    "placeholder": "Enter New Password",
    "minlength": 8,
    "maxlength": 32,
    "readonly": false,
    "disabled": false,
    "hidden": false,
    "pattern": null,
    "isPasswordValidation": true,
    "styles": {
      "appearance": "outline",
      "class": ["full-width", "col1", "input-textbox"]
    },
    "validations": [{
      "name": "required",
      "validator": "required",
      "message": ""
    }, {
      "name": "hasSpace",
      "validator": "hasSpace",
      "message": "Password should not contain space!"
    }, {
      "name": "minlength",
      "validator": "minlength",
      "message": "Password length must be between 8-32 Character!"
    }, {
      "name": "maxlength",
      "validator": "maxlength",
      "message": ""
    }, {
      "name": "hasNumber",
      "validator": "hasNumber",
      "message": "Password must contain at least 1 number!"
    }, {
      "name": "hasCapitalCase",
      "validator": "hasCapitalCase",
      "message": "Password must contain at least 1 in Capital letter!"
    }, {
      "name": "hasSmallCase",
      "validator": "hasSmallCase",
      "message": "Password must contain at least 1 in Small letter!"
    }, {
      "name": "hasSpecialCharacters",
      "validator": "hasSpecialCharacters",
      "message": "Passowrd must contain at least 1 Special Character!"
    }],
    "callbacks": []
  },
  {
    "id": 3,
    "type": "input",
    "inputType": "password",
    "name": "confirm_current_password",
    "label": "Confirm New Password",
    "required": true,
    "value": null,
    "placeholder": "Enter Confirm New Password",
    "minlength": 8,
    "maxlength": 32,
    "readonly": false,
    "disabled": false,
    "hidden": false,
    "pattern": null,
    "isPasswordValidation": false,
    "styles": {
      "appearance": "outline",
      "class": ["full-width", "col1", "input-textbox"]
    },
    "validations": [{
      "name": "required",
      "validator": "required",
      "message": "Confirm New Password is required"
    }, {
      "name": "minlength",
      "validator": "minlength",
      "message": "Password length must be between 8-32 Character!"
    }, {
      "name": "maxlength",
      "validator": "maxlength",
      "message": ""
    }, {
      "name": "mustMatch",
      "validator": "mustMatch",
      "message": "New Password & Confirm New Password not match"
    }],
    "callbacks": []
}];

module.exports = {
  profileFormStyle,
  profileFormGroup,
  profileMainHeader,
  fieldsWithOldPassword,
  fieldsWithoutOldPassword
};
