let ApprovalHistoryListHeader = [
        {
          "key": "user",
          "value": "User",
          "type": "text",
          "align": "left"
        },
        
        {
          "key": "date",
          "value": " Date",
          "type": "text",
          "align": "left"
        },
        {
          "key": "time",
          "value": "Time",
          "type": "text",
          "align": "left"
        },
        {
          "key": "remarks",
          "value": "Remarks",
          "type": "text",
          "align": "left"
        },
        {
          "key": "action",
          "value": "",
          "align": "right",
          "type": "dropdown",
          "action": "button",
          "icon": "keyboard_arrow_down",
          "options": [
              {
                  "key": "action",
                  "type": "details",
                  "icon": "keyboard_arrow_down"
              }
          ]
        }
      ]

  module.exports = {
    ApprovalHistoryListHeader
    };
    
