const ClaimListRenderHeaderData = [{
			"key": "claim_number",
			"searchKey": "claim_number__search",
			"value": "Claim No.",
			"type": "input",
			"inputType": "text",
			"sticky": false,
			"align": "left",
			"isSearchAvailable": true,
			"isSorting": true
		},{
			"key": "policy_no",
			"searchKey": "policy_no__search",
			"value": "Policy No.",
			"type": "input",
			"inputType": "text",
			"sticky": false,
			"align": "left",
			"isSearchAvailable": true,
			"isSorting": true
		},  {
			"key": "created",
			"searchKey": "created__search",
			"value": " Claim Created Date",
			"type": "date",
			"inputType": "date",
			"sticky": false,
			"align": "left",
			"isSearchAvailable": true,
			"isSorting": true
		}, 
		{
			"key": "modified",
			"searchKey": "modified__search",
			"value": " Claim Modified Date",
			"type": "date",
			"inputType": "date",
			"sticky": false,
			"align": "left",
			"isSearchAvailable": true,
			"isSorting": true
		},		
		{
			"key": "assigned_to",
			"searchKey": "assigned_to__search",
			"value": "Assign to",
			"type": "select",
			"inputType": "select",
			"sticky": false,
			"align": "left",
			"isSearchAvailable": true,
			"isSorting": true,
			"options": [{
				"key": "User",
				"value": "User",
				"selected": true
			}]
		},
		{
			"key": "status",
			"searchKey": "status__search",
			"value": "Status",
			"type": "select",
			"inputType": "select",
			"sticky": false,
			"isSearchAvailable": true,
			"isSorting": true,
			"options": [{
				"key": "All",
				"value": "All",
				"selected": true
			},]
		},
        {
			"key": "substatus",
			"searchKey": "substatus__search",
			"value": "Sub Status",
			"type": "select",
			"inputType": "select",
			"sticky": false,
			"isSearchAvailable": true,
			"isSorting": true,
			"options": [{
				"key": "All",
				"value": "All",
				"selected": true
			}, {
				"key": "Pending",
				"value": "Pending",
				"selected": false
			}, {
				"key": "Approved",
				"value": "Approved",
				"selected": false
			}, {
				"key": "Rejected",
				"value": "Rejected",
				"selected": false
			}]
		}, 
		{
			"key": "planname",
			"searchKey": "planname__search",
			"value": "plan name",
			"type": "select",
			"inputType": "select",
			"sticky": false,
			"isSearchAvailable": true,
			"isSorting": true,
			"options": [{
				"key": "All",
				"value": "All",
				"selected": true
			}]
		},
		{
			"key": "action",
			"searchKey": "action__search",
			"value": "Action",
			"type": "button",
			"inputType": "button",
			"sticky": true,
			"align": "right",
			"isSearchAvailable": true,
			"isSorting": false,
			"options": {
				"create": {
					"title":"",
					"action": "",
					"fieldId": "",
					"fieldData": [],
					"method": "",
					"type": ""
				}, 
				"edit": {
					"title":"Click here to edit Claim",
					"action": "claims/edit",
					"fieldId": "claim_number",
					"fieldData": null,
					"method": "edit_claim",
					"type": "edit"
				},
				"view": {
					"title":"Click here to view Customer",
					"action": "claims/view",
					"fieldId": "claim_number",
					"fieldData": null,
					"method": "view_claim",
					"type": "view"
				},
				"delete": {
					"title":"Click here to delete Customer",
					"action": "api/claims/delete",
					"fieldId": "claim_number",
					"fieldData": null,
					"method": "delete_claim",
					"type": "delete"
				}
			}
		}];

module.exports = {
ClaimListRenderHeaderData
};