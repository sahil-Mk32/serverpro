const dashboardStatusColour = [
  {
    status: "New Case Request",
    colour: "#b8f7e6",
  },
  {
    status: "L1 Adjudication",
    colour: "#c6e1fe",
  },
  {
    status: "L2 Adjudication",
    colour: "#d8d6fd",
  },
  {
    status: "Claim Closed",
    colour: "#eff3f4",
  },
  {
    status: "Verification Pending",
    colour: "#fbded8",
  },
  {
    status: "Verified",
    colour: "#fdc8da",
  },
  {
    status: "Ready for Disbursement",
    colour: "#bec4c4",
  },
  {
    status: "Disbursed",
    colour: "#fee8c3",
  },
  {
    status: "On Hold",
    colour: "#bee9ef",
  },
  {
    status: "Stopped",
    colour: "#c7c4d9",
  },
  {
    status: "Settled",
    colour: "#fdda96",
  },
  {
    status: "Unassigned",
    colour: "#ace5d6",
  },
  {
    status: "Under Review",
    colour: "#cbd0d6",
  },
  {
    status: "On Hold",
    colour: "#9ce2fb",
  },
  {
    status: "Stopped",
    colour: "#d9bcf6",
  },
  {
    status: "Completed",
    colour: "#fed3b1",
  },
  {
    status: "Payment",
    colour: "#fed3b1",
  },
  {
    status: "Review",
    colour: "#fed3b1",
  },
];

const dashboardOnHold = [
  {
    key: "role",
    value: "Role",
    type: "text",
    align: "left",
  },
  {
    key: "name",
    value: "Name",
    type: "text",
    align: "left",
  },
  {
    key: "<=0",
    value: "<=0",
    type: "text",
    align: "center",
  },
  {
    key: ">0 and <=3",
    value: ">0 and <=3",
    type: "text",
    align: "center",
  },
  {
    key: ">3 and <=8",
    value: ">3 and <=8",
    type: "text",
    align: "center",
  },
  {
    key: ">8 and <=16",
    value: ">8 and <=16",
    type: "text",
    align: "center",
  },
  {
    key: ">16 and <=22",
    value: ">16 and <=22",
    type: "text",
    align: "center",
  },
  {
    key: ">22",
    value: ">22",
    type: "text",
    align: "center",
  },
  {
    key: "total_claim",
    value: "Total Claim",
    type: "text",
    align: "center",
  },
  {
    key: "action",
    value: "Action",
    type: "dropdown",
    action: "button",
    icon: "keyboard_arrow_down",
    options: [
      {
        key: "action",
        type: "details",
        icon: "keyboard_arrow_down",
      },
    ],
  },
];

const ageBucket = [
  {
    name: "status",
    label: "Status",
    type: "text",
    align: "left",
  },
  {
    name: "substatus",
    label: "Sub Status",
    type: "text",
    align: "left",
  },
  {
    name: "<=0",
    label: "<=0",
    type: "text",
    align: "center",
  },
  {
    name: ">0 and <=3",
    label: ">0 and <=3",
    type: "text",
    align: "center",
  },
  {
    name: ">3 and <=8",
    label: ">3 and <=8",
    type: "text",
    align: "center",
  },
  {
    name: ">8 and <=16",
    label: ">8 and <=16",
    type: "text",
    align: "center",
  },
  {
    name: ">16 and <=22",
    label: ">16 and <=22",
    type: "text",
    align: "center",
  },
  {
    name: ">22",
    label: ">22",
    type: "text",
    align: "center",
  },
  {
    name: "grand_total",
    label: "Grand Total",
    type: "text",
    align: "center",
  },
];


const pendingClaimDataColumn = [
  {
    key: "claim_no",
    value: "Claim No",
    type: "text",
    style: {
      textAlign: "left",
    },
  },
  {
    key: "policy_holder_name",
    value: "Policy Holder Name",
    type: "text",
    style: {
      textAlign: "left",
    },
  },
  {
    key: "policy_no",
    value: "Policy No",
    type: "text",
    style: {
      textAlign: "left",
    },
  },
  {
    key: "claim_created_date",
    value: "Claim Created Date",
    type: "text",
    style: {
      textAlign: "left",
    },
  },
  {
    key: "assigned_to",
    value: "Assigned To",
    type: "text",
    style: {
      textAlign: "left",
    },
  },
  {
    key: "tat",
    value: "TAT",
    type: "text",
    style: {
      textAlign: "left",
    },
  },
  {
    key: "status",
    value: "Status",
    type: "text",
    style: {
      textAlign: "left",
    },
  },
];

module.exports = { dashboardStatusColour, dashboardOnHold, ageBucket, pendingClaimDataColumn };
