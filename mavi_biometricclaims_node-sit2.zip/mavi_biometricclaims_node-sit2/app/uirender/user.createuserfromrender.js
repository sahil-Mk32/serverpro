const UserCreateFieldRender = [{
	"type": "section",
	"title": "",
	"name": "user_configuration",
	"display_type": "default",
	"display_mode": "default",
	"id": "101",
	"expanded": true,
	"fields": [
{
"id": 1,
"name": "id_str",
"value": "",
"type": "input",
"label": "Unique Id",
"is_editable": false,
"expanded": false,
"icon": "",
"inputType": "text",
"required": false,
"placeholder": "",
"hint": "",
"minlength": 0,
"maxlength": 100,
"readonly": true,
"disabled": true,
"hidden": true,
"pattern": null,
"validations": [],
"styles": {
"class": [
  "full-width",
  "col2",
  "input-textbox"
],
"appearance": "outline"
},
"callbacks": [],
"formgroups": {}
},
{
"id": 2,
"name": "username",
"value": "",
"type": "input",
"label": "User Name",
"is_editable": true,
"expanded": false,
"icon": "",
"inputType": "text",
"required": true,
"placeholder": "",
"hint": "",
"minlength": 0,
"maxlength": 100,
"readonly": false,
"disabled": false,
"hidden": false,
"pattern": null,
"validations": [
{
  "name": "required",
  "validator": "required",
  "message": "User Name is Required"
}
],
"styles": {
"class": [
  "full-width",
  "col2",
  "input-textbox"
],
"appearance": "outline"
},
"callbacks": [{"action":"api/user/usercreationcallback","type":"dependent","method":"method_name","fieldData":null}],
"formgroups": {}
},
{
"id": 3,
"name": "email",
"value": "",
"type": "input",
"label": "Email",
"is_editable": true,
"expanded": false,
"icon": "",
"inputType": "email",
"required": true,
"placeholder": "",
"hint": "",
"minlength": 0,
"maxlength": 100,
"readonly": false,
"disabled": false,
"hidden": false,
"pattern": "[a-z0-9.]+@[a-z]+\.[a-z]{2,3}",
"validations": [
{
  "name": "required",
  "validator": "required",
  "message": "Email is Required"
},
{
  "name": "pattern",
  "validator": "pattern",
  "message": "Email must be valid"
}
],
"styles": {
"class": [
  "full-width",
  "col2",
  "input-textbox"
],
"appearance": "outline"
},
"callbacks": [{"action":"api/user/usercreationcallback","type":"dependent","method":"method_name","fieldData":null}],
"formgroups": {}
},
{
  "id": 4,
  "name": "mobile",
  "value": "",
  "type": "input",
  "label": "Mobile Number",
  "is_editable": true,
  "expanded": false,
  "icon": "",
  "inputType": "text",
  "required": true,
  "placeholder": "",
  "hint": "",
  "minlength": 0,
  "maxlength": 100,
  "readonly": false,
  "disabled": false,
  "hidden": false,
  "pattern": null,
  "validations": [
  {
    "name": "required",
    "validator": "required",
    "message": "Mobile Number is Required"
  }
  ],
  "styles": {
  "class": [
    "full-width",
    "col2",
    "input-textbox"
  ],
  "appearance": "outline"
  },
  "callbacks": [],
  "formgroups": {}
  },
{
"id": 5,
"name": "first_name",
"value": "",
"type": "input",
"label": "First Name",
"is_editable": true,
"expanded": false,
"icon": "",
"inputType": "text",
"required": true,
"placeholder": "",
"hint": "",
"minlength": 0,
"maxlength": 100,
"readonly": false,
"disabled": false,
"hidden": false,
"pattern": null,
"validations": [
{
  "name": "required",
  "validator": "required",
  "message": "First Name is Required"
}
],
"styles": {
"class": [
  "full-width",
  "col2",
  "input-textbox"
],
"appearance": "outline"
},
"callbacks": [],
"formgroups": {}
},
{
"id": 6,
"name": "last_name",
"value": "",
"type": "input",
"label": "Last Name",
"is_editable": true,
"expanded": false,
"icon": "",
"inputType": "text",
"required": true,
"placeholder": "",
"hint": "",
"minlength": 0,
"maxlength": 100,
"readonly": false,
"disabled": false,
"hidden": false,
"pattern": null,
"validations": [
{
  "name": "required",
  "validator": "required",
  "message": "Last Name is Required"
}
],
"styles": {
"class": [
  "full-width",
  "col2",
  "input-textbox"
],
"appearance": "outline"
},
"callbacks": [],
"formgroups": {}
},
{
"id": 7,
"name": "role_id",
"value": "",
"type": "select",
"label": "Role",
"is_editable": true,
"expanded": false,
"icon": "",
"inputType": "select",
"required": true,
"placeholder": "",
"hint": "",
"minlength": 0,
"maxlength": 100,
"readonly": false,
"disabled": false,
"hidden": false,
"pattern": null,
"validations": [
{
  "name": "required",
  "validator": "required",
  "message": "Role is Required"
}
],
"styles": {
"class": [
  "full-width",
  "col2",
  "input-selectbox"
],
"appearance": "outline"
},
"callbacks": [],
"options": [],
"formgroups": {}
},
{
"id": 8,
"name": "status",
"value": "",
"type": "select",
"label": "Status",
"is_editable": true,
"expanded": false,
"icon": "",
"inputType": "text",
"required": true,
"placeholder": "",
"hint": "",
"minlength": 0,
"maxlength": 100,
"readonly": false,
"disabled": false,
"hidden": false,
"pattern": null,
"validations": [
{
  "name": "required",
  "validator": "required",
  "message": "Status is Required"
}
],
"styles": {
"class": [
  "full-width",
  "col2",
  "input-selectbox"
],
"appearance": "outline"
},
"options": [
{
  "key": "active",
  "value": "Active"
},
{
  "key": "inactive",
  "value": "InActive"
}
],
"callbacks": [],
"formgroups": {}
},
{
"id": 9,
"name": "client_program",
"value": "",
"type": "select",
"label": "Client Program",
"is_editable": true,
"expanded": false,
"icon": "",
"inputType": "text",
"required": true,
"placeholder": "",
"hint": "",
"minlength": 0,
"maxlength": 100,
"readonly": false,
"multiple": true,
"disabled": false,
"hidden": false,
"pattern": null,
"validations": [
{
  "name": "required",
  "validator": "required",
  "message": "Client Program is Required"
}
],
"styles": {
"class": [
  "full-width",
  "col2",
  "input-selectbox"
],
"appearance": "outline"
},
"options": [],
"callbacks": [],
"formgroups": {}
},
{
"id": 10,
"name": "current_password",
"value": "",
"type": "input",
"label": "Password",
"icon": "",
"inputType": "password",
"required": true,
"placeholder": "Enter Password",
"minlength": 8,
"maxlength": 16,
"readonly": false,
"disabled": false,
"hidden": false,
"isPasswordValidation": true,
"validations": [
{
  "name": "required",
  "validator": "required",
  "message": "Password is Required"
},
{
  "name": "hasSpace",
  "validator": "hasSpace",
  "message": "Should not contain space!"
},
{
  "name": "minlength",
  "validator": "minlength",
  "message": "Must be at least 8 characters!"
},
{
  "name": "maxlength",
  "validator": "maxlength",
  "message": "Cannot be more that 16 characters!"
},
{
  "name": "hasNumber",
  "validator": "hasNumber",
  "message": "Must contain at least 1 number!"
},
{
  "name": "hasCapitalCase",
  "validator": "hasCapitalCase",
  "message": "Must contain at least 1 in Capital Case!"
},
{
  "name": "hasSmallCase",
  "validator": "hasSmallCase",
  "message": "Must contain at least 1 in Small Case!"
},
{
  "name": "hasSpecialCharacters",
  "validator": "hasSpecialCharacters",
  "message": "Must contain at least 1 Special Character!"
}
],
"styles": {
"class": [
  "full-width",
  "col1",
  "input-textbox"
],
"appearance": "outline"
},
"callbacks": []
}
]
}];

module.exports = {
	UserCreateFieldRender
	};