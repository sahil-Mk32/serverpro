const customerFormRendering = [
    {
        illness:{
			"readonly": true,
			"width": 50,
        },
        have_you_suffered_previuos_illnes_or_injury:{
			"readonly": true,
			"width": 100,
        },
        job_related_injury:{
            "readonly": true
        },
        claim_against_other_party:{
            "readonly": true,
        },
        same_account_details:{
            "readonly": true,
            "width": 100,
        },
        details_the_nature:{
            "width": 100,
            "hidden": false
        },
        accident:{
            "readonly": true,
            "width": 50
        }
    }
]

const actionsButton =
      '{"type":"button","name":"action","inputType":"button","displayType":"default","label":"","styles":"","options":[{"type":"submit","name":"accept","inputType":"accept","label":"Accept","icon":"","disable":false,"callbacks":[{"method":"accept","action":"api/claim/update_subStatus","type":"accept","fieldData":null}],"action":"accept","styles":{"class":["input-buttonbox"],"color":"accent","css":{"background":"#027bb0"}}},{"type":"submit","name":"reject","inputType":"reject","label":"Reject","icon":"","disable":false,"callbacks":[{"method":"reject","action":"api/claim/update_subStatus","type":"reject","fieldData":null}],"action":"reject","styles":{"class":["input-buttonbox"],"color":"accent","css":{"background":"#027bb0"}}}]}';
const docActionsButton =
      '{"type":"button","name":"action","inputType":"button","displayType":"default","label":"","styles":"","options":[{"type":"submit","name":"submit","inputType":"submit","label":"Submit","isConfirmation" : true, "isConfirmationMessage" : "Are you want to submit this document?","icon":"","disable":false,"callbacks":[{"method":"submit","action":"api/claim/update_subStatus","type":"accept","fieldData":null}],"action":"submit","styles":{"class":["input-buttonbox"],"color":"accent","css":{"background":"#027bb0"}}}]}';
module.exports = {customerFormRendering, actionsButton, docActionsButton}
