const router=require("express").Router();

router.post('/log',require('../../controllers/logArchieve/logArchieve'));

module.exports=router;