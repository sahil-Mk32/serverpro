const router = require("express").Router();
const apiLogCtrl = require("../../controllers/apiLog/apiLog.controller");
const middleware = require("../../middleware/verifyToken");

router.post("/detail", middleware.verifyToken, apiLogCtrl.getapiLogDetail);
module.exports = router;