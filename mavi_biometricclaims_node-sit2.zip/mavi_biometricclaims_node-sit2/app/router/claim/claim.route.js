const router = require("express").Router();
const claimCtrl = require("../../controllers/claim/claim.controller");
const claimFormCtrl = require("../../controllers/claim/claimformrender.controller");
const middleware = require("../../middleware/verifyToken");
const middlewareapilog= require("../../middleware/ApilogCration");
const claimCallbackCtrl = require('../../controllers/claim/claimCallback.controller')

router.post("/claimlist",middlewareapilog.cratelogtable, middleware.verifyToken, claimCtrl.getClaimList);
router.post("/create_form",middlewareapilog.cratelogtable, middleware.verifyToken, claimFormCtrl.clmCreateFrmRender);
router.post("/create",middlewareapilog.cratelogtable, middleware.verifyToken,claimCtrl.clmCreateOne);
router.post("/bitlylinkresend",middlewareapilog.cratelogtable, middleware.verifyToken,claimCtrl.resendBitlyLink);
router.post("/bitlylinkverify",middlewareapilog.cratelogtable, claimCtrl.verifyBitlyLink);
router.post("/otpsend",middlewareapilog.cratelogtable, claimCtrl.otpSend);
router.post("/cust_otpverify",middlewareapilog.cratelogtable, claimCtrl.custOtpVerify);
router.post("/customer_form", claimFormCtrl.clmCustomerFrmRender);
router.post("/update_subStatus", claimFormCtrl.approveCustomerForm);
router.post("/status_otp/:token",middlewareapilog.cratelogtable, claimFormCtrl.statusUpdateOtp);
router.post("/getClaim",middlewareapilog.cratelogtable ,middleware.verifyToken, claimFormCtrl.getClaimDetails);
router.post("/claimCallback", claimCallbackCtrl.claimCallbackDeatails);
router.post("/report",middlewareapilog.cratelogtable,middleware.verifyToken, claimFormCtrl.downloadClaimReport);
module.exports = router;