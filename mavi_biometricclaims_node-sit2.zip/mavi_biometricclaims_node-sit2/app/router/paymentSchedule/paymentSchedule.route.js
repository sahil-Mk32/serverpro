const router = require("express").Router();
const paymentScheduleCtrl = require("../../controllers/paymentSchedule/paymentSchedule.controller");
const paymentFormCtrl = require("../../controllers/paymentSchedule/paymentformrender.controller");
const middleware = require("../../middleware/verifyToken");
const middlewareapilog = require("../../middleware/ApilogCration");

router.post("/create",middlewareapilog.cratelogtable , middleware.verifyToken,paymentScheduleCtrl.paymentScheduleCreate);
router.post("/update", middlewareapilog.cratelogtable, middleware.verifyToken,paymentScheduleCtrl.paymentScheduleUpdate);
router.post("/list",middlewareapilog.cratelogtable, middleware.verifyToken,paymentScheduleCtrl.getpaymentScheduleList);
router.post("/detail",middlewareapilog.cratelogtable, middleware.verifyToken,paymentScheduleCtrl.getpaymentScheduleDetail);
router.post("/tab", middlewareapilog.cratelogtable, middleware.verifyToken,paymentScheduleCtrl.getpaymentScheduleTab);
router.post("/createform",middlewareapilog.cratelogtable,  middleware.verifyToken,paymentFormCtrl.paymentCreateFormRender);
router.post("/callBack",middlewareapilog.cratelogtable, middleware.verifyToken,paymentFormCtrl.callback);

module.exports = router;