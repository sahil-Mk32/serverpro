const router = require("express").Router();
const { ReviewScheduleCtrl } = require("../../controllers/reviewSchedule/reviewSchedule.controller");
const { ReviewScheuleFormRender } = require("../../controllers/reviewSchedule/reviewScheduleFormRender.controller");

router.post("/list", ReviewScheduleCtrl.getAllReviewSchedule);
router.post("/create", ReviewScheduleCtrl.createReviewScheduleOne);
router.post("/update", ReviewScheduleCtrl.updateReviewSchedule);
router.post("/create_form", ReviewScheuleFormRender.reviewScheduleCreateFrmRender);
router.post("/details", ReviewScheduleCtrl.getReviewScheduleDetails);
router.post("/callBack", ReviewScheduleCtrl.callback);
module.exports = router;
