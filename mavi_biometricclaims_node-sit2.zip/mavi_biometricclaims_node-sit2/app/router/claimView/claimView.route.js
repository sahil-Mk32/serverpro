const router = require("express").Router();
const claimViewCtrl = require("../../controllers/claimView/claimView.controller");
const claimViewFormCtrl = require("../../controllers/claimView/claimViewfromrender.controller");
const claimViewCallbackCtrl = require("../../controllers/claimView/claimViewCallback.controller");
const middleware = require("../../middleware/verifyToken");
const middlewareapilog= require("../../middleware/ApilogCration");


router.post("/summary",middlewareapilog.cratelogtable, middleware.verifyToken, claimViewCtrl.claimSummaryDetails);
router.post("/details",middlewareapilog.cratelogtable, middleware.verifyToken, claimViewCtrl.claimViewDetails);
router.post("/updateHistory",middlewareapilog.cratelogtable,middleware.verifyToken, claimViewCtrl.claimUpdateHistory);
router.post("/getComments" ,middlewareapilog.cratelogtable,middleware.verifyToken, claimViewCtrl.getClaimComments);
router.post("/addComments" ,middlewareapilog.cratelogtable,middleware.verifyToken, claimViewCtrl.createClaimComments);
router.post("/trackClaim",middlewareapilog.cratelogtable,middleware.verifyToken, claimViewCtrl.trackClaim);
router.post("/view",middlewareapilog.cratelogtable, middleware.verifyToken, claimViewCtrl.claimViewDetail);
router.post("/approvalhistory", middlewareapilog.cratelogtable ,  middleware.verifyToken, claimViewCtrl.claimViewApprovalHistory);
router.post("/approvalhistoryfromrender",middlewareapilog.cratelogtable ,  middleware.verifyToken, claimViewFormCtrl.claimViewApprovalHistoryFromRender);
router.post("/approvalhistorycallback",middlewareapilog.cratelogtable, middleware.verifyToken, claimViewCallbackCtrl.claimViewApprovalHistoryCallBack);
router.post("/approvalhistorysubmit", middlewareapilog.cratelogtable,  middleware.verifyToken, claimViewCtrl.claimViewApprovalHistorySubmit);

module.exports = router;
