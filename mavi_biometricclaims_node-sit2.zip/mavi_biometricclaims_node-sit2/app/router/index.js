"use strict";
exports.setup = function (app) {
  const user = require("./user/user.route");
  const sales = require("./sales/sales.route");
  var contract = require("./contract/contract.route");
  var claim = require("./claim/claim.route");
  var communication = require("./communication/communication.route");
  const claimView= require("./claimView/claimView.route");
  var documents = require("./documents/documents.route");
  const reviewSchedule = require("./reviewSchedule/reviewSchedule.route");
  const paymentSchedule= require("./paymentSchedule/paymentSchedule.route");
  const apiLog= require("./apiLog/apiLog.route");
  const bulkUpload = require("./bulkUpload/bulkUpload.route");
  const { verifyToken } = require("../middleware/verifyToken");
  const dashboard= require("./dashboard/dashboard.route");
  const cron = require("./cron/cron.route");
  const middlewareapilog = require("../middleware/ApilogCration");

  app.use("/api/user/", user);
  app.use("/api/sales/", sales);
  app.use("/api/contract/", contract);
  app.use("/api/claim/", claim);
  app.use("/api/communication/", communication);
  app.use("/api/claimView/", claimView);
  app.use("/api/documents/", documents);
  app.use("/api/reviewSchedule/",middlewareapilog.cratelogtable , verifyToken, reviewSchedule);
  app.use("/api/paymentSchedule/", paymentSchedule);
  app.use("/api/apiLog/", apiLog);
  app.use("/api/bulkUpload/", bulkUpload);
  app.use("/api/dashboard/", dashboard);
  app.use("/cron/", cron);
  app.use("/service/",require("../router/communication/communication.route"));
  app.use("/archieve",require('./logArchieve/logArchieve.route'));

};

module.exports = exports;

