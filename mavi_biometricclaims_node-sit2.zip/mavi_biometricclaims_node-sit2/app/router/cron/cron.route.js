const router = require("express").Router();
const cronCtrl = require("../../controllers/cron/cron.controller");

router.get("/claimClosed", cronCtrl.claimClosed);
router.get("/reminderMail", cronCtrl.reminderMailSend);
router.get("/mailOpenStatus", cronCtrl.mailOnOpenStatus);
module.exports = router;