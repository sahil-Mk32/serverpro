const router = require("express").Router();
const { documentsCtrl } = require("../../controllers/documents/documents.controller");
const documentsFormCtrl = require("../../controllers/documents/documentsformrender.controller");
const { verifyToken } = require("../../middleware/verifyToken");
const middlewareapilog =require("../../middleware/ApilogCration");

router.post("/create",middlewareapilog.cratelogtable, verifyToken, documentsCtrl.documentsCreateOne);
router.post("/create_form",middlewareapilog.cratelogtable, verifyToken, documentsFormCtrl.documentsCreateFrmRender);
router.post("/upload",middlewareapilog.cratelogtable, verifyToken, documentsCtrl.documentsUpload);
router.post("/list",middlewareapilog.cratelogtable, verifyToken, documentsCtrl.documentsList);
router.post("/history",middlewareapilog.cratelogtable, verifyToken, documentsCtrl.documentsHistory);
router.post("/delete",middlewareapilog.cratelogtable, verifyToken, documentsCtrl.documentsDelete);
router.post("/submit",middlewareapilog.cratelogtable, verifyToken, documentsCtrl.documentSubmit);
router.post("/customer_upload", documentsCtrl.customerDocumentsUpload);
router.post("/customer_delete", documentsCtrl.customerDocumentsDelete);
module.exports = router;
