const commonService = require("../common/utils");
const httpStatus = require("http-status");


exports.cratelogtable = async (req, res, next)=>{
    try{
        const saveApiLog = await commonService.createApiLogs(req);
        
        req.dataValues=saveApiLog.dataValues.id;
        next();
    }
    catch(error){
        commonService.dumpError(err);
        return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
        status: message.ERROR,
        msg: errorMsg,
        });
    }
}