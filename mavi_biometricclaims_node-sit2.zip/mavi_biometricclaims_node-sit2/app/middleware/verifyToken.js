const httpStatus = require("http-status");
const message = require("../common/messages");
const { decode } = require("jsonwebtoken");
const userService = require("../service/user/user.service");
const commonService = require("../common/utils");

exports.verifyToken = async (req, res, next) => {
  try {
    //const saveApiLog = await commonService.createApiLogs(req);
    const token = req.headers["x-access-token"];
    if (!token) {
      const response = commonService.response(
        0,
        message.EMPTY_TOKEN,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );
      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }


  const tokenData = await commonService.decodeToken(token);
    if (!tokenData) {
      const response = commonService.response(
        0,
        message.INVALID_TOKEN,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }

    const user = await userService.getUser({
      id_str: tokenData.id_str,
      login_token: tokenData.login_token,
    });

    

    if (!user) {
      const response = commonService.response(
        0,
        message.INVALID_TOKEN,
        null,
        message.ERROR
      );
      await commonService.updateLogsData(
        { status: 'Failed',
          error_type:'Failed'
        },
        { id:req.dataValues }
      );

      await commonService.updateApiLogsData(
        { response: JSON.stringify(response) },
        { id: req.dataValues }
      );
      return res.status(httpStatus.UNAUTHORIZED).json(response);
    }
    await commonService.updateLogsData(
      { user_id: JSON.stringify(tokenData.id)},
      { id:req.dataValues }
    );


    req.user = tokenData
    //console.log(req.user);
    //req.dataValues=saveApiLog.dataValues.id;

    next();
  } catch (err) {
    commonService.dumpError(err);
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).json({
      status: message.ERROR,
      msg: errorMsg,
    });
  }
};
